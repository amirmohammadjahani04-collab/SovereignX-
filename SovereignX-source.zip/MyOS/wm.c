#include "wm.h"


#define MAX_WINDOWS 10


static window_t windows[MAX_WINDOWS];

static int window_count = 0;



void wm_init(void)
{
    window_count = 0;
}



int wm_create_window(
    const char *title,
    int x,
    int y,
    int w,
    int h,
    uint32_t color
)
{

    if(window_count >= MAX_WINDOWS)
        return -1;


    window_create(
        &windows[window_count],
        x,
        y,
        w,
        h,
        color,
        title
    );


    window_count++;


    return window_count-1;
}



void wm_draw_all(void)
{
    for(int i=0;i<window_count;i++)
    {
        window_draw(&windows[i]);
    }
}
