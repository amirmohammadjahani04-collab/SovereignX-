#include "event.h"
#include "font.h"


void open_files()
{
    draw_string(
        50,
        200,
        "File Manager Opening...",
        0xffffff
    );
}


void mouse_click(int x,int y)
{
    // محدوده آیکون Files
    if(x >= 50 && x <= 100 &&
       y >= 80 && y <= 130)
    {
        open_files();
    }


    // محدوده Settings
    if(x >= 150 && x <= 200 &&
       y >= 80 && y <= 130)
    {
        draw_string(
            50,
            220,
            "Settings Opening...",
            0xffffff
        );
    }
}
