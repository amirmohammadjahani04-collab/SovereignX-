#include "desktop.h"
#include "graphics.h"
#include "font.h"


void desktop_init(uint32_t color)
{
    clear_screen(color);
}


void desktop_draw(void)
{
    // پس زمینه
    clear_screen(0x1e3a5f);


    // Taskbar
    fill_rect(
        0,
        440,
        640,
        40,
        0x202020
    );


    // عنوان سیستم
    draw_string(
        20,
        20,
        "bakOS Desktop",
        0xffffff
    );


    // آیکون فایل
    fill_rect(
        50,
        80,
        50,
        50,
        0xffff00
    );

    draw_string(
        45,
        140,
        "Files",
        0xffffff
    );


    // آیکون تنظیمات
    fill_rect(
        150,
        80,
        50,
        50,
        0xaaaaaa
    );

    draw_string(
        140,
        140,
        "Settings",
        0xffffff
    );
}
