#include "fat_dir.h"
#include "disk.h"
#include "font.h"

#include <stdint.h>


typedef struct
{
    char name[11];
    uint8_t attr;
    uint8_t reserved[10];
    uint16_t cluster;
    uint32_t size;

} fat_dir_entry;


void fat_read_root(void)
{
    uint8_t sector[512];


    // فعلاً نمونه:
    // در FAT12 واقعی باید مقدار Root Directory
    // از Boot Sector محاسبه شود

    ata_read_sector(
        19,
        sector
    );


    fat_dir_entry *entry =
        (fat_dir_entry*)sector;


    draw_string(
        10,
        350,
        "Root Directory:",
        0xffffff
    );


    for(int i=0;i<16;i++)
    {
        if(entry[i].name[0]==0)
            break;


        draw_string(
            10,
            370+(i*15),
            entry[i].name,
            0xffffff
        );
    }
}
