#include "scanner.h"

int scan_page(char *code)
{
    char *bad[] =
    {
        "rm -rf",
        "format",
        "keylogger",
        "malware"
    };


    for(int i=0;i<4;i++)
    {
        char *p = code;

        while(*p)
        {
            int j=0;

            while(bad[i][j] && p[j]==bad[i][j])
                j++;

            if(bad[i][j]==0)
                return 0;

            p++;
        }
    }

    return 1;
}
