#ifndef SCANNER_H
#define SCANNER_H

int scan_page(char *code);

#endif
