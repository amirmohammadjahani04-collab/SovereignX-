#include "mouse.h"

void irq12_mouse()
{
    mouse_handler();
}
