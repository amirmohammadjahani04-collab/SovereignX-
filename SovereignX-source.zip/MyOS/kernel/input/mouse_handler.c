#include <stdint.h>

extern void mouse_update(int x,int y);

void mouse_handler()
{
    mouse_update(0,0);
}
