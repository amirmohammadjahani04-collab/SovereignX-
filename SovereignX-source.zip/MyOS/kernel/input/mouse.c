#include "mouse.h"


static int x = 40;
static int y = 12;
static int left = 0;


static unsigned char packet[3];
static int packet_index = 0;



/*
    PS/2 Port I/O
*/

static inline unsigned char inb(unsigned short port)
{
    unsigned char ret;

    asm volatile(
        "inb %%dx, %%al"
        : "=a"(ret)
        : "d"(port)
    );

    return ret;
}


static inline void outb(
    unsigned short port,
    unsigned char value
)
{
    asm volatile(
        "outb %%al, %%dx"
        :
        : "a"(value),
          "d"(port)
    );
}



/*
    Mouse Init
*/

void mouse_init(void)
{
    x = 40;
    y = 12;
    left = 0;
    packet_index = 0;


    /* Enable PS/2 mouse */
    outb(
        0x64,
        0xA8
    );


    /* Read controller status */
    outb(
        0x64,
        0x20
    );

    unsigned char status =
        inb(0x60);


    /* Write controller command */
    outb(
        0x64,
        0x60
    );

    outb(
        0x60,
        status | 2
    );


    /* Send command to mouse */
    outb(
        0x64,
        0xD4
    );

    outb(
        0x60,
        0xF4
    );


    inb(0x60);
}



/*
    IRQ12 Handler
*/

void mouse_input_handler(void)
{
    unsigned char data =
        inb(0x60);


    packet[packet_index++] =
        data;


    if(packet_index == 3)
    {
        packet_index = 0;


        left =
            packet[0] & 1;


        x +=
            (signed char)packet[1];


        y -=
            (signed char)packet[2];


        if(x < 0)
            x = 0;

        if(y < 0)
            y = 0;
    }
}



/*
    IRQ Wrapper
    مورد نیاز mouse_irq.c
*/

void mouse_handler(void)
{
    mouse_input_handler();
}



/*
    Desktop Access
*/

int mouse_x(void)
{
    return x;
}


int mouse_y(void)
{
    return y;
}


int mouse_left(void)
{
    return left;
}
