#include "keyboard_irq.h"


static char buffer[128];
static int head = 0;


static inline unsigned char inb(
    unsigned short port
)
{
    unsigned char value;

    asm volatile(
        "inb %1,%0"
        :"=a"(value)
        :"Nd"(port)
    );

    return value;
}


static inline void outb(
    unsigned short port,
    unsigned char value
)
{
    asm volatile(
        "outb %0,%1"
        :
        :"a"(value),"Nd"(port)
    );
}


/*
 IRQ1 Keyboard Interrupt
*/
void keyboard_irq_handler()
{
    unsigned char scan =
        inb(0x60);


    if(head < 127)
    {
        buffer[head++] =
            scan;
    }


    /*
      End Of Interrupt
    */
    outb(
        0x20,
        0x20
    );
}



void keyboard_irq_init()
{
    head = 0;


    /*
      فعال کردن IRQ1 در PIC

      Master PIC
      Keyboard = IRQ1
    */

    unsigned char mask =
        inb(0x21);


    mask &= ~(1 << 1);


    outb(
        0x21,
        mask
    );
}



char keyboard_read()
{
    if(head == 0)
        return 0;


    char c =
        buffer[0];


    for(
        int i=0;
        i<head-1;
        i++
    )
    {
        buffer[i]=buffer[i+1];
    }


    head--;

    return c;
}
