#ifndef MOUSE_H
#define MOUSE_H

void mouse_init();
void mouse_handler();

int mouse_x();
int mouse_y();
int mouse_left();

#endif
