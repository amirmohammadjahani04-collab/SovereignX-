#include "keyboard.h"

static unsigned char last_key = 0;

void keyboard_init(void)
{
    last_key = 0;
}

void keyboard_handle_scancode(unsigned char scancode)
{
    last_key = scancode;
}

char keyboard_get(void)
{
    return 0;
}
