#ifndef KEYBOARD_IRQ_H
#define KEYBOARD_IRQ_H

void keyboard_irq_init();

void keyboard_irq_handler();

char keyboard_read();

#endif
