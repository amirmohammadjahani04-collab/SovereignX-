#ifndef MOUSE_IRQ_H
#define MOUSE_IRQ_H

void irq12_mouse();

#endif
