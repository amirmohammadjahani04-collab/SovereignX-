#ifndef RFS_H
#define RFS_H

void rfs_init(void);
int rfs_write_file(const char *name, const char *content);
int rfs_read_file(const char *name, char *out, int max_len);
int rfs_delete_file(const char *name);
int rfs_file_count(void);
const char *rfs_file_name(int index);

#endif
