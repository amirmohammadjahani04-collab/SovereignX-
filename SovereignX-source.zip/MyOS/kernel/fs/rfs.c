#include "rfs.h"
#include "../drivers/disk/ata.h"

#define RFS_SB_LBA 60000
#define RFS_TABLE_LBA 60001
#define RFS_TABLE_SECTORS 4
#define RFS_DATA_LBA 60010
#define RFS_MAX_FILES 32
#define RFS_NAME_LEN 32
#define RFS_CONTENT_LEN 256
#define RFS_ENTRY_SIZE 64
#define RFS_MAGIC 0x52465331u

typedef struct {
    char name[RFS_NAME_LEN];
    int used;
} RfsEntry;

static RfsEntry table[RFS_MAX_FILES];

static int str_eq(const char *a, const char *b)
{
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static void load_table(void)
{
    uint8_t buf[512];
    int entry_index = 0;
    for (int s = 0; s < RFS_TABLE_SECTORS; s++)
    {
        ata_read_sector(RFS_TABLE_LBA + s, buf);
        for (int off = 0; off < 512; off += RFS_ENTRY_SIZE)
        {
            if (entry_index >= RFS_MAX_FILES) break;
            RfsEntry *e = &table[entry_index];
            for (int i = 0; i < RFS_NAME_LEN; i++)
                e->name[i] = (char)buf[off + i];
            e->used = buf[off + RFS_NAME_LEN];
            entry_index++;
        }
    }
}

static void save_table(void)
{
    uint8_t buf[512];
    int entry_index = 0;
    for (int s = 0; s < RFS_TABLE_SECTORS; s++)
    {
        for (int i = 0; i < 512; i++) buf[i] = 0;
        for (int off = 0; off < 512; off += RFS_ENTRY_SIZE)
        {
            if (entry_index >= RFS_MAX_FILES) break;
            RfsEntry *e = &table[entry_index];
            for (int j = 0; j < RFS_NAME_LEN; j++)
                buf[off + j] = (uint8_t)e->name[j];
            buf[off + RFS_NAME_LEN] = (uint8_t)e->used;
            entry_index++;
        }
        ata_write_sector(RFS_TABLE_LBA + s, buf);
    }
}

static void write_superblock(void)
{
    uint8_t buf[512];
    for (int i = 0; i < 512; i++) buf[i] = 0;
    buf[0] = (RFS_MAGIC >> 24) & 0xFF;
    buf[1] = (RFS_MAGIC >> 16) & 0xFF;
    buf[2] = (RFS_MAGIC >> 8) & 0xFF;
    buf[3] = RFS_MAGIC & 0xFF;
    ata_write_sector(RFS_SB_LBA, buf);
}

static int superblock_valid(void)
{
    uint8_t buf[512];
    ata_read_sector(RFS_SB_LBA, buf);
    uint32_t magic = ((uint32_t)buf[0] << 24) | ((uint32_t)buf[1] << 16) |
                      ((uint32_t)buf[2] << 8) | buf[3];
    return magic == RFS_MAGIC;
}

void rfs_init(void)
{
    if (superblock_valid())
    {
        load_table();
    }
    else
    {
        for (int i = 0; i < RFS_MAX_FILES; i++)
        {
            table[i].name[0] = 0;
            table[i].used = 0;
        }
        write_superblock();
        save_table();
    }
}

static int find_entry(const char *name)
{
    for (int i = 0; i < RFS_MAX_FILES; i++)
        if (table[i].used && str_eq(table[i].name, name))
            return i;
    return -1;
}

static int alloc_entry(const char *name)
{
    for (int i = 0; i < RFS_MAX_FILES; i++)
    {
        if (!table[i].used)
        {
            int j = 0;
            while (name[j] && j < RFS_NAME_LEN - 1) { table[i].name[j] = name[j]; j++; }
            table[i].name[j] = 0;
            table[i].used = 1;
            return i;
        }
    }
    return -1;
}

int rfs_write_file(const char *name, const char *content)
{
    int idx = find_entry(name);
    if (idx < 0) idx = alloc_entry(name);
    if (idx < 0) return 0;

    save_table();

    uint8_t buf[512];
    for (int i = 0; i < 512; i++) buf[i] = 0;
    int i = 0;
    while (content[i] && i < RFS_CONTENT_LEN - 1) { buf[i] = (uint8_t)content[i]; i++; }
    buf[i] = 0;

    ata_write_sector(RFS_DATA_LBA + idx, buf);
    return 1;
}

int rfs_read_file(const char *name, char *out, int max_len)
{
    int idx = find_entry(name);
    if (idx < 0) { out[0] = 0; return 0; }

    uint8_t buf[512];
    ata_read_sector(RFS_DATA_LBA + idx, buf);

    int i = 0;
    while (buf[i] && i < max_len - 1) { out[i] = (char)buf[i]; i++; }
    out[i] = 0;
    return 1;
}

int rfs_delete_file(const char *name)
{
    int idx = find_entry(name);
    if (idx < 0) return 0;
    table[idx].used = 0;
    save_table();
    return 1;
}

int rfs_file_count(void)
{
    int c = 0;
    for (int i = 0; i < RFS_MAX_FILES; i++) if (table[i].used) c++;
    return c;
}

const char *rfs_file_name(int index)
{
    int c = 0;
    for (int i = 0; i < RFS_MAX_FILES; i++)
    {
        if (table[i].used)
        {
            if (c == index) return table[i].name;
            c++;
        }
    }
    return "";
}
