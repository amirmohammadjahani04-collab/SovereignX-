#ifndef TASKBAR_H
#define TASKBAR_H

void taskbar_draw(void);

#endif
