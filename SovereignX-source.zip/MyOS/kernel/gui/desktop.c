#include "desktop.h"
#include "background.h"
#include "taskbar.h"
#include "icons.h"
#include "cursor.h"
#include "wm.h"
#include "custom_icons.h"
#include "../fb.h"
#include "../graphics.h"
#include "../text_render.h"
#include "../apps/terminal/terminal_window.h"
#include "../apps/file_manager_window.h"
#include "../apps/settings_window.h"
#include "../apps/sysinfo_window.h"
#include "../apps/games.h"
#include "../apps/mc_lang.h"
#include "../apps/terminal_commands.h"
#include "../apps/code_editor.h"
#include "../apps/dev_shell.h"
#include "../apps/run_window.h"

#define TERM_X 40
#define TERM_Y 40
#define TERM_W 400
#define TERM_H 300

#define FILES_X 480
#define FILES_Y 40
#define FILES_W 300
#define FILES_H 350

#define SETTINGS_X 200
#define SETTINGS_Y 420
#define SETTINGS_W 400
#define SETTINGS_H 200

#define SYSINFO_X 160
#define SYSINFO_Y 120

#define START_BTN_X 6
#define START_BTN_W 90
#define START_BTN_H 32

#define MENU_W 200
#define MENU_ITEM_H 40
#define MENU_ITEMS 4

#define ICON_X 24
#define ICON_START_Y 24
#define ICON_SPACING 88
#define ICON_SIZE 48

#define TASKBTN_SIZE 26
#define TASKBTN_STEP 32
#define TASKBTN_COUNT 4
#define TASKBTN_Y_OFFSET 11

static int terminal_open = 0;
static int files_open = 0;
static int settings_open = 0;
static int sysinfo_open = 0;
static int start_menu_open = 0;
static int system_halted = 0;
static int desktop_active = 0;
static int bgcolor_cycle_index = 0;

static int hovered_valid = 0;
static int hovered_cx = 0;
static int hovered_cy = 0;
static int hovered_icon_x = 0;
static int hovered_icon_y = 0;

static const uint32_t bgcolor_presets[] = {
    0x12121F,
    0x1A1A2E,
    0x0000AA,
    0x101014,
    0x001A00,
    0x0D3B3E,
    0x550000,
    0x2E4A2E
};
#define BGCOLOR_PRESET_COUNT (sizeof(bgcolor_presets) / sizeof(bgcolor_presets[0]))

static const char *menu_labels[MENU_ITEMS] = {
    "Terminal",
    "Files",
    "Settings",
    "Shutdown"
};

static int point_in_close_button(int win_x, int win_y, int mx, int my)
{
    int cx = win_x + 16;
    int cy = win_y + 14;
    int dx = mx - cx;
    int dy = my - cy;
    return (dx * dx + dy * dy) <= (10 * 10);
}

static int point_in_icon(int index, int mx, int my)
{
    int iy = ICON_START_Y + ICON_SPACING * index;
    return (mx >= ICON_X && mx <= ICON_X + ICON_SIZE &&
            my >= iy && my <= iy + ICON_SIZE);
}

static int point_in_taskbtn(int index, int mx, int my)
{
    Framebuffer *fb = get_fb();
    uint32_t bar_y = fb->height - 48;
    int qx = fb->width - 4 - (TASKBTN_SIZE + 6) * TASKBTN_COUNT;
    int bx = qx + index * TASKBTN_STEP;
    int by = bar_y + TASKBTN_Y_OFFSET;
    return (mx >= bx && mx <= bx + TASKBTN_SIZE &&
            (uint32_t)my >= by && (uint32_t)my <= by + TASKBTN_SIZE);
}

static int total_icon_count(void)
{
    int gcount = game_installed_count();
    int ccount = custom_icon_count();
    return 6 + gcount + ccount;
}

static void update_hover(void)
{
    int cx = cursor_get_x();
    int cy = cursor_get_y();
    int total = total_icon_count();

    hovered_valid = 0;
    for (int i = 0; i < total; i++)
    {
        if (point_in_icon(i, cx, cy))
        {
            hovered_valid = 1;
            hovered_icon_x = ICON_X;
            hovered_icon_y = ICON_START_Y + ICON_SPACING * i;
            hovered_cx = ICON_X + ICON_SIZE / 2;
            hovered_cy = hovered_icon_y + ICON_SIZE / 2;
            break;
        }
    }
}

static void draw_start_menu(void)
{
    Framebuffer *fb = get_fb();
    uint32_t bar_y = fb->height - 48;
    uint32_t menu_h = MENU_ITEMS * MENU_ITEM_H;
    uint32_t menu_y = bar_y - menu_h;
    uint32_t menu_x = START_BTN_X;

    draw_rect(fb, menu_x, menu_y, MENU_W, menu_h, 0x2D1B4E);
    draw_rect(fb, menu_x, menu_y, MENU_W, 2, 0x9B3BE0);
    draw_rect(fb, menu_x, menu_y, 2, menu_h, 0x9B3BE0);
    draw_rect(fb, menu_x + MENU_W - 2, menu_y, 2, menu_h, 0x9B3BE0);

    for (int i = 0; i < MENU_ITEMS; i++)
    {
        uint32_t item_y = menu_y + i * MENU_ITEM_H;
        draw_rect(fb, menu_x, item_y, MENU_W, 1, 0x3D2B5E);
        draw_string(menu_x + 16, item_y + 14, menu_labels[i], 0xFFFFFF);
    }
}

static void power_off(void)
{
    Framebuffer *fb = get_fb();
    clear_screen(fb, 0x000000);
    draw_string(fb->width / 2 - 150, fb->height / 2,
                "SovereignX system halted.", 0xFFFFFF);
    draw_string(fb->width / 2 - 150, fb->height / 2 + 16,
                "You can now turn off your device.", 0xAAAAAA);
    system_halted = 1;
    fb_present();
}

void desktop_trigger_shutdown(void) { power_off(); }
void desktop_activate(void)         { desktop_active = 1; }
int  desktop_is_active(void)        { return desktop_active; }
int  desktop_is_terminal_open(void) { return terminal_open; }
void desktop_run_icon_script(const char *s) { mc_run_script_from_vfs(s); }

void desktop_emergency_reset(void)
{
    terminal_open   = 0;
    files_open      = 0;
    settings_open   = 0;
    sysinfo_open    = 0;
    start_menu_open = 0;
    desktop_redraw();
}

void desktop_cycle_bgcolor(void)
{
    bgcolor_cycle_index = (bgcolor_cycle_index + 1) % BGCOLOR_PRESET_COUNT;
    background_set_color(bgcolor_presets[bgcolor_cycle_index]);
    desktop_redraw();
}

void desktop_show_help(void)
{
    terminal_open   = 1;
    start_menu_open = 0;
    terminal_print("=== SovereignX Keyboard Shortcuts ===\n");
    terminal_print("Ctrl+Alt+T = Terminal\n");
    terminal_print("Ctrl+Alt+F = Files\n");
    terminal_print("Ctrl+Alt+S = Settings\n");
    terminal_print("Ctrl+Alt+I = SysInfo\n");
    terminal_print("Ctrl+Alt+L = Shutdown\n");
    terminal_print("Ctrl+Alt+R = Reboot\n");
    terminal_print("Ctrl+Alt+X = Emergency reset\n");
    terminal_print("Ctrl+Alt+G = Cycle bg color\n");
    terminal_print("Ctrl+Alt+D = Dev Shell\n");
    terminal_print("Win+R      = Run window\n");
    terminal_print("Win+S      = Dev Shell\n");
    terminal_print("F5         = Apply Dev Shell changes\n");
    terminal_print("F10        = Exit Dev Shell\n");
    desktop_redraw();
}

void desktop_activate_hovered(void)
{
    if (!hovered_valid) return;
    desktop_handle_click(hovered_cx, hovered_cy);
}

void desktop_redraw_terminal_fast(void)
{
    if (system_halted) return;

    if (!desktop_active)
    {
        terminal_window_draw_text();
        cursor_redraw();
        fb_present();
        return;
    }

    if (terminal_open)
    {
        terminal_window_draw_text();
        cursor_redraw();
        fb_present();
    }
    else
    {
        desktop_redraw();
    }
}

void desktop_redraw(void)
{
    if (system_halted) return;

    if (dev_shell_is_open())
    {
        dev_shell_draw();
        return;
    }

    Framebuffer *fb = get_fb();

    if (!desktop_active)
    {
        clear_screen(fb, 0x000000);
        terminal_window_draw();
        cursor_redraw();
        fb_present();
        return;
    }

    background_draw();
    icons_draw();
    taskbar_draw();

    update_hover();
    if (hovered_valid)
    {
        draw_rect(fb, hovered_icon_x - 3, hovered_icon_y - 3,
                  ICON_SIZE + 6, 2, 0xFFFFFF);
        draw_rect(fb, hovered_icon_x - 3, hovered_icon_y + ICON_SIZE + 1,
                  ICON_SIZE + 6, 2, 0xFFFFFF);
        draw_rect(fb, hovered_icon_x - 3, hovered_icon_y - 3,
                  2, ICON_SIZE + 6, 0xFFFFFF);
        draw_rect(fb, hovered_icon_x + ICON_SIZE + 1, hovered_icon_y - 3,
                  2, ICON_SIZE + 6, 0xFFFFFF);
    }

    if (terminal_open)  terminal_window_draw();
    if (files_open)     file_manager_window_draw();
    if (settings_open)  settings_window_draw();
    if (sysinfo_open)   sysinfo_window_draw();

    if (editor_is_active())
        editor_window_draw();

    if (run_window_is_open())
        run_window_draw();

    if (start_menu_open)
        draw_start_menu();

    cursor_redraw();
    fb_present();
}

void desktop_handle_click(int mx, int my)
{
    if (system_halted || !desktop_active) return;
    if (dev_shell_is_open()) return;

    if (editor_is_active())
    {
        editor_handle_click(mx, my);
        return;
    }

    Framebuffer *fb = get_fb();
    uint32_t bar_y = fb->height - 48;

    if (mx >= START_BTN_X && mx <= START_BTN_X + START_BTN_W &&
        (uint32_t)my >= bar_y + 8 &&
        (uint32_t)my <= bar_y + 8 + START_BTN_H)
    {
        start_menu_open = !start_menu_open;
        return;
    }

    if (point_in_taskbtn(0, mx, my)) { desktop_toggle_terminal(); return; }
    if (point_in_taskbtn(1, mx, my)) { desktop_toggle_files();    return; }
    if (point_in_taskbtn(2, mx, my)) { desktop_toggle_settings(); return; }
    if (point_in_taskbtn(3, mx, my)) { desktop_toggle_sysinfo();  return; }

    if (start_menu_open)
    {
        uint32_t menu_h = MENU_ITEMS * MENU_ITEM_H;
        uint32_t menu_y = bar_y - menu_h;

        if (mx >= START_BTN_X && mx <= START_BTN_X + MENU_W &&
            (uint32_t)my >= menu_y && (uint32_t)my <= menu_y + menu_h)
        {
            int index = (my - menu_y) / MENU_ITEM_H;
            if      (index == 0) terminal_open = 1;
            else if (index == 1) files_open    = 1;
            else if (index == 2) settings_open = 1;
            else if (index == 3) { power_off(); return; }
            start_menu_open = 0;
            return;
        }
        start_menu_open = 0;
        return;
    }

    if (point_in_icon(0, mx, my)) { desktop_open_files();     return; }
    if (point_in_icon(1, mx, my)) { return; }
    if (point_in_icon(2, mx, my)) { desktop_toggle_sysinfo(); return; }
    if (point_in_icon(3, mx, my)) { power_off();              return; }
    if (point_in_icon(4, mx, my)) { desktop_open_settings();  return; }
    if (point_in_icon(5, mx, my)) { desktop_toggle_sysinfo(); return; }

    {
        int gcount = game_installed_count();
        for (int i = 0; i < gcount; i++)
        {
            if (point_in_icon(6 + i, mx, my))
            {
                editor_open_existing(game_installed_name(i), 1);
                return;
            }
        }

        int ccount = custom_icon_count();
        for (int i = 0; i < ccount; i++)
        {
            if (point_in_icon(6 + gcount + i, mx, my))
            {
                const char *script = custom_icon_script(i);
                if (script[0] != 0)
                    editor_open_existing(script, 0);
                return;
            }
        }
    }

    if (terminal_open && point_in_close_button(TERM_X, TERM_Y, mx, my))
    { terminal_open = 0; return; }
    if (files_open && point_in_close_button(FILES_X, FILES_Y, mx, my))
    { files_open = 0; return; }
    if (settings_open && point_in_close_button(SETTINGS_X, SETTINGS_Y, mx, my))
    { settings_open = 0; return; }
    if (sysinfo_open && point_in_close_button(SYSINFO_X, SYSINFO_Y, mx, my))
    { sysinfo_open = 0; return; }
}

void desktop_open_terminal(void)  { terminal_open   = 1; start_menu_open = 0; }
void desktop_open_files(void)     { files_open      = 1; start_menu_open = 0; }
void desktop_open_settings(void)  { settings_open   = 1; start_menu_open = 0; }
void desktop_toggle_terminal(void){ terminal_open   = !terminal_open;   start_menu_open = 0; }
void desktop_toggle_files(void)   { files_open      = !files_open;      start_menu_open = 0; }
void desktop_toggle_settings(void){ settings_open   = !settings_open;   start_menu_open = 0; }
void desktop_toggle_sysinfo(void) { sysinfo_open    = !sysinfo_open;    start_menu_open = 0; }
void desktop_close_start_menu(void){ start_menu_open = 0; }
void desktop_toggle_start_menu(void){ start_menu_open = !start_menu_open; desktop_redraw(); }

void desktop_init(void)
{
    wm_init();
    desktop_redraw();
}
