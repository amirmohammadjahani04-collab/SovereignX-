#include "keybind.h"
#include "desktop.h"
#include "../apps/games.h"
#include "../apps/mc_lang.h"
#include "../apps/terminal_commands.h"

#define MAX_BINDS 16
#define NAME_LEN 32

typedef struct {
    uint8_t scancode;
    int is_game;
    char name[NAME_LEN];
    int used;
} KeyBind;

static KeyBind binds[MAX_BINDS];

static int str_eq(const char *a, const char *b)
{
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

/* جدول ساده‌ی تبدیل حرف به scancode (فقط حروف کوچک a-z و اعداد 0-9) */
static uint8_t char_to_scancode(char c)
{
    static const char letters[] = "qwertyuiopasdfghjklzxcvbnm";
    static const uint8_t letter_codes[] = {
        0x10,0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,
        0x1E,0x1F,0x20,0x21,0x22,0x23,0x24,0x25,0x26,
        0x2C,0x2D,0x2E,0x2F,0x30,0x31,0x32
    };
    static const char digits[] = "1234567890";
    static const uint8_t digit_codes[] = {
        0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B
    };

    for (int i = 0; letters[i]; i++)
        if (letters[i] == c) return letter_codes[i];

    for (int i = 0; digits[i]; i++)
        if (digits[i] == c) return digit_codes[i];

    return 0;
}

void keybind_init(void)
{
    for (int i = 0; i < MAX_BINDS; i++) binds[i].used = 0;
}

int keybind_add(char key_char, int is_game, const char *name)
{
    uint8_t sc = char_to_scancode(key_char);
    if (sc == 0) return 0;

    for (int i = 0; i < MAX_BINDS; i++)
    {
        if (binds[i].used && binds[i].scancode == sc)
        {
            binds[i].is_game = is_game;
            int j = 0;
            while (name[j] && j < NAME_LEN - 1) { binds[i].name[j] = name[j]; j++; }
            binds[i].name[j] = 0;
            return 1;
        }
    }

    for (int i = 0; i < MAX_BINDS; i++)
    {
        if (!binds[i].used)
        {
            binds[i].scancode = sc;
            binds[i].is_game = is_game;
            int j = 0;
            while (name[j] && j < NAME_LEN - 1) { binds[i].name[j] = name[j]; j++; }
            binds[i].name[j] = 0;
            binds[i].used = 1;
            return 1;
        }
    }
    return 0;
}

void keybind_handle_alt_key(uint8_t scancode)
{
    for (int i = 0; i < MAX_BINDS; i++)
    {
        if (binds[i].used && binds[i].scancode == scancode)
        {
            desktop_open_terminal();
            if (binds[i].is_game)
            {
                int gcount = game_installed_count();
                for (int g = 0; g < gcount; g++)
                {
                    if (str_eq(game_installed_name(g), binds[i].name))
                    {
                        game_replay_installed(g);
                        break;
                    }
                }
            }
            else
            {
                mc_run_script_from_vfs(binds[i].name);
            }
            desktop_redraw();
            return;
        }
    }
}

void keybind_list(void)
{
    int any = 0;
    for (int i = 0; i < MAX_BINDS; i++)
    {
        if (binds[i].used)
        {
            terminal_print(binds[i].is_game ? "[game] " : "[app]  ");
            terminal_print(binds[i].name);
            terminal_print("\n");
            any = 1;
        }
    }
    if (!any) terminal_print("(no keybinds set)\n");
}
