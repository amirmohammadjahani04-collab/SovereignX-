#ifndef BACKGROUND_H
#define BACKGROUND_H

#include <stdint.h>

void background_draw(void);
void background_set_color(uint32_t color);
void background_reset(void);
uint32_t background_get_color(void);

#endif
