#include "background.h"
#include "../fb.h"
#include "../graphics.h"

#define PRO_DARK 0x1A1A2E

static uint32_t bg_color = PRO_DARK;

static uint32_t clamp_channel(int v)
{
    if (v < 0) return 0;
    if (v > 255) return 255;
    return (uint32_t)v;
}

static uint32_t lighten(uint32_t color, int amount)
{
    int r = (int)((color >> 16) & 0xFF) + amount;
    int g = (int)((color >> 8) & 0xFF) + amount;
    int b = (int)(color & 0xFF) + amount;
    return (clamp_channel(r) << 16) | (clamp_channel(g) << 8) | clamp_channel(b);
}

void background_draw(void)
{
    Framebuffer *fb = get_fb();
    uint32_t stride = fb->pitch / 4;

    uint32_t top = lighten(bg_color, 12);
    uint32_t bottom = bg_color;

    for (uint32_t y = 0; y < fb->height; y++)
    {
        uint32_t color = (y < fb->height / 2) ? top : bottom;
        uint32_t row_offset = y * stride;
        for (uint32_t x = 0; x < fb->width; x++)
        {
            fb->buffer[row_offset + x] = color;
        }
    }
}

void background_set_color(uint32_t color)
{
    bg_color = color;
}

void background_reset(void)
{
    bg_color = PRO_DARK;
}

uint32_t background_get_color(void)
{
    return bg_color;
}
