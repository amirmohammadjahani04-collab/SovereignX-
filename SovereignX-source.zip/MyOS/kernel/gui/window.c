#include "window.h"


static volatile unsigned short *vga =
    (unsigned short*)0xb8000;


static void put_char(
    int x,
    int y,
    char c
)
{
    vga[y * 80 + x] =
        c | 0x1700;
}


void window_init()
{
}


void window_create(
    int x,
    int y,
    int w,
    int h,
    char *title
)
{

    int i;


    // بالا
    for(i=0;i<w;i++)
    {
        put_char(x+i,y,'-');
    }


    // پایین
    for(i=0;i<w;i++)
    {
        put_char(x+i,y+h,'-');
    }


    // چپ و راست
    for(i=0;i<h;i++)
    {
        put_char(x,y+i,'|');
        put_char(x+w,y+i,'|');
    }


    // عنوان
    for(i=0;title[i];i++)
    {
        put_char(
            x+2+i,
            y,
            title[i]
        );
    }


    // دکمه بستن
    put_char(
        x+w-1,
        y,
        'X'
    );
}
