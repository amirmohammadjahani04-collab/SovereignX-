#ifndef CURSOR_H
#define CURSOR_H

void cursor_draw(int x, int y);
void cursor_move(int dx, int dy);
void cursor_redraw(void);
int cursor_get_x(void);
int cursor_get_y(void);

#endif
