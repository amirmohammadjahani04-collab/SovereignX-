#ifndef WM_H
#define WM_H

void wm_init(void);
void wm_draw_window(int x,int y,int w,int h,const char *title);

#endif
