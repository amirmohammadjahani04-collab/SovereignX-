#include "wm.h"
#include "../fb.h"
#include "../graphics.h"
#include "../text_render.h"

void wm_init(void)
{
}

void wm_draw_window(int x, int y, int w, int h, const char *title)
{
    Framebuffer *fb = get_fb();

    uint32_t shadow  = 0x000000;
    uint32_t border  = 0x555F6E;
    uint32_t bg      = 0x2B2F38;
    uint32_t titlebar= 0x1C2733;
    int corner       = 8;

    draw_rect(fb, x + 6, y + 6, w, h, shadow);
    draw_rect(fb, x, y, w, h, bg);
    draw_rect(fb, x, y, w, 28, titlebar);

    draw_rect(fb, x, y, w, 2, border);
    draw_rect(fb, x, y + h - 2, w, 2, border);
    draw_rect(fb, x, y, 2, h, border);
    draw_rect(fb, x + w - 2, y, 2, h, border);

    uint32_t cut = 0x1F3A5C;
    draw_rect(fb, x, y, corner, corner, cut);
    draw_rect(fb, x + w - corner, y, corner, corner, cut);
    draw_rect(fb, x, y + h - corner, corner, corner, cut);
    draw_rect(fb, x + w - corner, y + h - corner, corner, corner, cut);

    draw_circle(fb, x + 16, y + 14, 6, 0xFF5F56);
    draw_circle(fb, x + 36, y + 14, 6, 0xFFBD2E);
    draw_circle(fb, x + 56, y + 14, 6, 0x27C93F);

    draw_string(x + 75, y + 10, title, 0xCCCCCC);
}
