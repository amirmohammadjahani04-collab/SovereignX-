#ifndef WINDOW_H
#define WINDOW_H

void window_init();

void window_create(
    int x,
    int y,
    int w,
    int h,
    char *title
);

#endif
