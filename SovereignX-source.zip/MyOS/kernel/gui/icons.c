#include "icons.h"
#include "../fb.h"
#include "../graphics.h"
#include "../text_render.h"
#include "../apps/games.h"
#include "custom_icons.h"

static uint32_t icon_colors[5] = {
    0x4A6FE8,
    0xE84A4A,
    0xE8B84A,
    0x4AE86F,
    0x8A4AE8
};

void icons_set_color(int index, uint32_t color)
{
    if (index >= 0 && index < 5)
        icon_colors[index] = color;
}

static void draw_icon(Framebuffer *fb, int x, int y, uint32_t color, const char *label)
{
    draw_rect(fb, x - 2, y - 2, 52, 52, 0x0D0D17);
    draw_rect(fb, x, y, 48, 48, color);
    draw_string(x, y + 54, label, 0xCFCFCF);
}

void icons_draw(void)
{
    Framebuffer *fb = get_fb();

    int x = 24;
    int start_y = 24;
    int spacing = 88;

    draw_icon(fb, x, start_y + spacing * 0, icon_colors[0], "Files");
    draw_icon(fb, x, start_y + spacing * 1, icon_colors[1], "Trash");
    draw_icon(fb, x, start_y + spacing * 2, icon_colors[2], "SysInfo");
    draw_icon(fb, x, start_y + spacing * 3, icon_colors[3], "Logout");
    draw_icon(fb, x, start_y + spacing * 4, icon_colors[4], "Settings");

    int gcount = game_installed_count();
    for (int i = 0; i < gcount; i++)
    {
        draw_icon(fb, x, start_y + spacing * (5 + i), 0x4AE0E8, game_installed_name(i));
    }

    int ccount = custom_icon_count();
    for (int i = 0; i < ccount; i++)
    {
        draw_icon(fb, x, start_y + spacing * (5 + gcount + i), custom_icon_color(i), custom_icon_name(i));
    }
}
