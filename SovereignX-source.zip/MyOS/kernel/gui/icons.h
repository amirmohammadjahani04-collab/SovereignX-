#ifndef ICONS_H
#define ICONS_H

#include <stdint.h>

void icons_draw(void);
void icons_set_color(int index, uint32_t color);

#endif
