#include "taskbar.h"
#include "../fb.h"
#include "../graphics.h"
#include "../text_render.h"

#define BAR_BG      0x14141F
#define BAR_ACCENT  0x4A6FE8
#define BTN_CYAN    0x4AE0E8
#define BTN_YELLOW  0xE8D84A
#define BTN_BLUE    0x4A6FE8
#define BTN_WHITE   0xE8E8E8

static void draw_task_button(Framebuffer *fb, int x, int y, uint32_t color, const char *label)
{
    draw_rect(fb, x, y, 26, 26, 0x0D0D14);
    draw_rect(fb, x + 1, y + 1, 24, 24, color);
    draw_string(x + 9, y + 9, label, 0x0D0D14);
}

void taskbar_draw(void)
{
    Framebuffer *fb = get_fb();
    uint32_t bar_height = 48;
    uint32_t bar_y = fb->height - bar_height;

    draw_rect(fb, 0, bar_y, fb->width, bar_height, BAR_BG);
    draw_rect(fb, 0, bar_y, fb->width, 2, BAR_ACCENT);

    /* دکمه‌ی Start مسطح مدرن */
    draw_rect(fb, 6, bar_y + 7, 90, 32, 0x0D0D14);
    draw_rect(fb, 7, bar_y + 8, 88, 30, BAR_ACCENT);
    draw_string(22, bar_y + 18, "Start", 0xFFFFFF);

    /* برچسب برند سمت راست */
    draw_rect(fb, fb->width - 190, bar_y + 11, 80, 24, 0x0D0D14);
    draw_rect(fb, fb->width - 189, bar_y + 12, 78, 22, 0x22223A);
    draw_string(fb->width - 178, bar_y + 18, "SovereignX", BTN_CYAN);

    int qx = fb->width - 4 - (26 + 6) * 4;
    draw_task_button(fb, qx + 0 * 32, bar_y + 10, BTN_CYAN, "T");
    draw_task_button(fb, qx + 1 * 32, bar_y + 10, BTN_YELLOW, "F");
    draw_task_button(fb, qx + 2 * 32, bar_y + 10, BTN_BLUE, "S");
    draw_task_button(fb, qx + 3 * 32, bar_y + 10, BTN_WHITE, "I");
}
