#ifndef CUSTOM_ICONS_H
#define CUSTOM_ICONS_H

#include <stdint.h>

void custom_icon_add(const char *name, uint32_t color);
void custom_icon_add_app(const char *name, uint32_t color, const char *script);
void custom_icon_remove(const char *name);
int custom_icon_count(void);
const char *custom_icon_name(int index);
uint32_t custom_icon_color(int index);
const char *custom_icon_script(int index);
void custom_icon_clear_all(void);

#endif
