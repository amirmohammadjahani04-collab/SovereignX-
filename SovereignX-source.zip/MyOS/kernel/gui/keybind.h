#ifndef KEYBIND_H
#define KEYBIND_H

#include <stdint.h>

void keybind_init(void);
int keybind_add(char key_char, int is_game, const char *name);
void keybind_handle_alt_key(uint8_t scancode);
void keybind_list(void);

#endif
