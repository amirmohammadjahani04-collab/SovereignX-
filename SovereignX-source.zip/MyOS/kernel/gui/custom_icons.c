#include "custom_icons.h"

#define MAX_CUSTOM 5
#define NAME_LEN 16
#define SCRIPT_LEN 32

typedef struct {
    char name[NAME_LEN];
    uint32_t color;
    char script[SCRIPT_LEN];
    int used;
} CIcon;

static CIcon icons[MAX_CUSTOM];

static int str_eq(const char *a, const char *b)
{
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static void copy_str(char *dst, const char *src, int max_len)
{
    int j = 0;
    while (src[j] && j < max_len - 1) { dst[j] = src[j]; j++; }
    dst[j] = 0;
}

void custom_icon_add(const char *name, uint32_t color)
{
    for (int i = 0; i < MAX_CUSTOM; i++)
    {
        if (icons[i].used && str_eq(icons[i].name, name))
        {
            icons[i].color = color;
            icons[i].script[0] = 0;
            return;
        }
    }
    for (int i = 0; i < MAX_CUSTOM; i++)
    {
        if (!icons[i].used)
        {
            copy_str(icons[i].name, name, NAME_LEN);
            icons[i].color = color;
            icons[i].script[0] = 0;
            icons[i].used = 1;
            return;
        }
    }
}

void custom_icon_add_app(const char *name, uint32_t color, const char *script)
{
    for (int i = 0; i < MAX_CUSTOM; i++)
    {
        if (icons[i].used && str_eq(icons[i].name, name))
        {
            icons[i].color = color;
            copy_str(icons[i].script, script, SCRIPT_LEN);
            return;
        }
    }
    for (int i = 0; i < MAX_CUSTOM; i++)
    {
        if (!icons[i].used)
        {
            copy_str(icons[i].name, name, NAME_LEN);
            icons[i].color = color;
            copy_str(icons[i].script, script, SCRIPT_LEN);
            icons[i].used = 1;
            return;
        }
    }
}

void custom_icon_remove(const char *name)
{
    for (int i = 0; i < MAX_CUSTOM; i++)
    {
        if (icons[i].used && str_eq(icons[i].name, name))
        {
            icons[i].used = 0;
            return;
        }
    }
}

int custom_icon_count(void)
{
    int c = 0;
    for (int i = 0; i < MAX_CUSTOM; i++) if (icons[i].used) c++;
    return c;
}

static int nth_index(int n)
{
    int c = 0;
    for (int i = 0; i < MAX_CUSTOM; i++)
    {
        if (icons[i].used)
        {
            if (c == n) return i;
            c++;
        }
    }
    return -1;
}

const char *custom_icon_name(int index)
{
    int idx = nth_index(index);
    return idx >= 0 ? icons[idx].name : "";
}

uint32_t custom_icon_color(int index)
{
    int idx = nth_index(index);
    return idx >= 0 ? icons[idx].color : 0xFFFFFF;
}

const char *custom_icon_script(int index)
{
    int idx = nth_index(index);
    return idx >= 0 ? icons[idx].script : "";
}

void custom_icon_clear_all(void)
{
    for (int i = 0; i < MAX_CUSTOM; i++) icons[i].used = 0;
}
