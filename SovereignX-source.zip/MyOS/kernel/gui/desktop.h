#ifndef DESKTOP_H
#define DESKTOP_H

void desktop_init(void);
void desktop_redraw(void);
void desktop_handle_click(int mx, int my);
void desktop_open_terminal(void);
void desktop_open_files(void);
void desktop_open_settings(void);
void desktop_close_start_menu(void);
void desktop_toggle_start_menu(void);
void desktop_trigger_shutdown(void);
void desktop_toggle_terminal(void);
void desktop_toggle_files(void);
void desktop_toggle_settings(void);
void desktop_toggle_sysinfo(void);
void desktop_activate(void);
int desktop_is_active(void);
void desktop_run_icon_script(const char *script_name);
void desktop_emergency_reset(void);
void desktop_cycle_bgcolor(void);
void desktop_show_help(void);
int desktop_is_terminal_open(void);
void desktop_activate_hovered(void);

#endif
