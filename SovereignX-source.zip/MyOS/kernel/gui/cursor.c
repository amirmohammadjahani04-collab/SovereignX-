#include "cursor.h"
#include "../fb.h"
#include "../graphics.h"

static int cur_x = 40;
static int cur_y = 12;

static const char *arrow_shape[] = {
    "X...........",
    "XX..........",
    "XoX.........",
    "XooX........",
    "XoooX.......",
    "XooooX......",
    "XoooooX.....",
    "XooooooX....",
    "XoooooooX...",
    "XooooooooX..",
    "XoooooXXXXX.",
    "XooXooX.....",
    "XoX.XooX....",
    "XX..XooX....",
    "X....XooX...",
    ".....XooX...",
    "......XX....",
};
#define ARROW_ROWS 17
#define ARROW_COLS 13

static void draw_arrow_cursor(Framebuffer *fb, int x, int y)
{
    uint32_t stride = fb->pitch / 4;

    for (int row = 0; row < ARROW_ROWS; row++)
    {
        for (int col = 0; col < ARROW_COLS; col++)
        {
            char c = arrow_shape[row][col];
            if (c == '.')
                continue;

            uint32_t color = (c == 'X') ? 0x000000 : 0xFFFFFF;

            int px = x + col;
            int py = y + row;

            if (px >= 0 && py >= 0 && (uint32_t)px < fb->width && (uint32_t)py < fb->height)
                fb->buffer[py * stride + px] = color;
        }
    }
}

void cursor_draw(int x, int y)
{
    cur_x = x;
    cur_y = y;
}

void cursor_redraw(void)
{
    Framebuffer *fb = get_fb();
    draw_arrow_cursor(fb, cur_x, cur_y);
}

/* محدود کردن حداکثر جهش هر بسته‌ی موس برای حرکت نرم‌تر و بدون پرش ناگهانی */
#define MAX_STEP 12

static int clamp_step(int v)
{
    if (v > MAX_STEP) return MAX_STEP;
    if (v < -MAX_STEP) return -MAX_STEP;
    return v;
}

void cursor_move(int dx, int dy)
{
    Framebuffer *fb = get_fb();

    dx = clamp_step(dx);
    dy = clamp_step(dy);

    int nx = cur_x + dx;
    int ny = cur_y + dy;

    if (nx < 0) nx = 0;
    if (ny < 0) ny = 0;
    if ((uint32_t)nx > fb->width - 20) nx = fb->width - 20;
    if ((uint32_t)ny > fb->height - 20) ny = fb->height - 20;

    cur_x = nx;
    cur_y = ny;
}

int cursor_get_x(void) { return cur_x; }
int cursor_get_y(void) { return cur_y; }
