#include <stdint.h>

static volatile int quick_boot_flag = 0;
static volatile int auto_boot_counter = 0;

static inline unsigned char inb(unsigned short port)
{
    unsigned char val;
    asm volatile ("inb %1, %0" : "=a"(val) : "Nd"(port));
    return val;
}

int keyboard_quick_boot_requested(void)
{
    /* چک مستقیم PS/2 */
    if (inb(0x64) & 1)
    {
        unsigned char sc = inb(0x60);
        /* N = 0x31، Ctrl+N هم همینه چون Ctrl قبلاً خونده شده */
        if (sc == 0x31 || sc == 0x25)
        {
            quick_boot_flag = 1;
        }
    }

    if (quick_boot_flag)
    {
        quick_boot_flag = 0;
        return 1;
    }

    /* auto boot: بعد از ۵ ثانیه خودکار میره */
    auto_boot_counter++;
    if (auto_boot_counter > 15000000)
    {
        auto_boot_counter = 0;
        return 1;
    }

    return 0;
}

void keyboard_set_quick_boot(int v)
{
    quick_boot_flag = v;
}
