#include "terminal_commands.h"
#include "pkg_manager.h"

#define MAX_INSTALLED 64
#define NAME_LEN 32

static char installed[MAX_INSTALLED][NAME_LEN];
static int installed_count = 0;

static int xorg_installed = 0;
static int wm_installed = 0;
static char wm_name[NAME_LEN] = "";

static int str_eq(const char *a, const char *b)
{
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static const char *wm_list[] = {
    "i3", "gnome", "kde", "xfce", "openbox", "dwm", "fluxbox", "mate",
    "awesome", "bspwm", "cinnamon", "lxde", "lxqt", "enlightenment",
    "sway", "ratpoison", "wmaker", "twm", "icewm"
};
#define WM_COUNT (sizeof(wm_list) / sizeof(wm_list[0]))

static int is_wm(const char *name)
{
    for (unsigned i = 0; i < WM_COUNT; i++)
        if (str_eq(name, wm_list[i])) return 1;
    return 0;
}

static int already_installed(const char *name)
{
    for (int i = 0; i < installed_count; i++)
        if (str_eq(installed[i], name)) return 1;
    return 0;
}

static void add_installed(const char *name)
{
    if (installed_count >= MAX_INSTALLED) return;
    int j = 0;
    while (name[j] && j < NAME_LEN - 1) { installed[installed_count][j] = name[j]; j++; }
    installed[installed_count][j] = 0;
    installed_count++;
}

int pkg_install(const char *name)
{
    if (name[0] == 0)
    {
        terminal_print("Usage: pkg install <name>\n");
        return 0;
    }

    if (already_installed(name))
    {
        terminal_print("Package '");
        terminal_print(name);
        terminal_print("' is already installed.\n");
        return 1;
    }

    if (str_eq(name, "xorg"))
    {
        terminal_print("Fetching xorg-server ................. OK\n");
        terminal_print("Fetching xorg-drivers ................ OK\n");
        terminal_print("Installing xorg ...................... OK\n");
        xorg_installed = 1;
        add_installed(name);
        terminal_print("xorg installed successfully.\n");
        return 1;
    }

    if (is_wm(name))
    {
        if (!xorg_installed)
        {
            terminal_print("Error: xorg is required first.\n");
            terminal_print("Run: pkg install xorg\n");
            return 0;
        }

        terminal_print("Fetching ");
        terminal_print(name);
        terminal_print("-core .................... OK\n");
        terminal_print("Installing ");
        terminal_print(name);
        terminal_print(" ......................... OK\n");

        wm_installed = 1;
        int j = 0;
        while (name[j] && j < NAME_LEN - 1) { wm_name[j] = name[j]; j++; }
        wm_name[j] = 0;

        add_installed(name);
        terminal_print(name);
        terminal_print(" installed successfully.\n");
        terminal_print("Run 'open desktop' to start your desktop.\n");
        return 1;
    }

    terminal_print("Resolving dependencies for '");
    terminal_print(name);
    terminal_print("'...\n");
    terminal_print("Fetching ");
    terminal_print(name);
    terminal_print(" ......................... OK\n");
    terminal_print("Installing ");
    terminal_print(name);
    terminal_print(" ........................ OK\n");
    add_installed(name);
    terminal_print(name);
    terminal_print(" installed successfully.\n");
    return 1;
}

int pkg_xorg_installed(void) { return xorg_installed; }
int pkg_wm_installed(void) { return wm_installed; }
const char *pkg_wm_name(void) { return wm_name; }

void pkg_list(void)
{
    terminal_print("Installed packages:\n");
    if (installed_count == 0)
    {
        terminal_print("  (none)\n");
        return;
    }
    for (int i = 0; i < installed_count; i++)
    {
        terminal_print("  ");
        terminal_print(installed[i]);
        terminal_print("\n");
    }
}

static const char *cat_desktop[] = {
    "xorg", "i3", "gnome", "kde", "xfce", "openbox", "dwm", "fluxbox",
    "mate", "awesome", "bspwm", "cinnamon", "lxde", "lxqt",
    "enlightenment", "sway", "ratpoison", "wmaker", "twm", "icewm",
    "polybar", "rofi", "dmenu", "picom", "feh", "nitrogen", "lightdm"
};

static const char *cat_editors[] = {
    "vim", "neovim", "emacs", "nano", "micro", "kate", "gedit",
    "code-oss", "helix", "joe", "ne"
};

static const char *cat_shells[] = {
    "bash", "zsh", "fish", "tcsh", "ksh", "dash", "elvish"
};

static const char *cat_devtools[] = {
    "gcc", "clang", "llvm", "gdb", "lldb", "make", "cmake", "ninja",
    "python3", "nodejs", "rust", "go", "git", "mercurial", "subversion",
    "valgrind", "strace", "ltrace", "autoconf", "automake", "pkgconf"
};

static const char *cat_network[] = {
    "curl", "wget", "openssh", "nmap", "wireshark", "tcpdump",
    "netcat", "socat", "iperf3", "bind-tools", "openvpn", "wireguard",
    "rsync", "ftp", "samba", "nfs-utils"
};

static const char *cat_sysutils[] = {
    "htop", "btop", "tmux", "screen", "fzf", "ripgrep", "fd", "bat",
    "tree", "lsof", "sysstat", "smartmontools", "gpart", "zfs-utils",
    "cronie", "syslog-ng", "sudo", "doas"
};

static const char *cat_media[] = {
    "mpv", "vlc", "ffmpeg", "imagemagick", "gimp", "inkscape",
    "audacity", "obs-studio", "sox", "mpd", "ncmpcpp"
};

static const char *cat_fonts[] = {
    "dejavu", "liberation-fonts", "noto", "font-awesome",
    "jetbrains-mono", "fira-code", "hack-font", "terminus-font"
};

static const char *cat_games[] = {
    "chocolate-doom", "freeciv", "0ad", "supertuxkart", "xonotic",
    "openttd", "wesnoth", "stella"
};

static void print_category(const char *title, const char **items, unsigned count)
{
    terminal_print(title);
    terminal_print(":\n  ");
    for (unsigned i = 0; i < count; i++)
    {
        terminal_print(items[i]);
        terminal_print(i < count - 1 ? ", " : "\n");
    }
}

void pkg_avail(void)
{
    terminal_print("SovereignX package catalog (sample browse view):\n\n");
    print_category("Desktop/WM", cat_desktop, sizeof(cat_desktop)/sizeof(cat_desktop[0]));
    print_category("Editors", cat_editors, sizeof(cat_editors)/sizeof(cat_editors[0]));
    print_category("Shells", cat_shells, sizeof(cat_shells)/sizeof(cat_shells[0]));
    print_category("Dev tools", cat_devtools, sizeof(cat_devtools)/sizeof(cat_devtools[0]));
    print_category("Network", cat_network, sizeof(cat_network)/sizeof(cat_network[0]));
    print_category("Sysutils", cat_sysutils, sizeof(cat_sysutils)/sizeof(cat_sysutils[0]));
    print_category("Media", cat_media, sizeof(cat_media)/sizeof(cat_media[0]));
    print_category("Fonts", cat_fonts, sizeof(cat_fonts)/sizeof(cat_fonts[0]));
    print_category("Games", cat_games, sizeof(cat_games)/sizeof(cat_games[0]));
    terminal_print("\nNote: pkg install accepts ANY package name, not just this list.\n");
}
