#ifndef DEV_SHELL_H
#define DEV_SHELL_H

void dev_shell_open(void);
void dev_shell_close(void);
int dev_shell_is_open(void);
void dev_shell_key(char c);
void dev_shell_draw(void);
void dev_shell_f5(void);

#endif
