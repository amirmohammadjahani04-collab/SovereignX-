#include "terminal_commands.h"
#include "mc_lang.h"
#include "../fb.h"
#include "../graphics.h"
#include "../text_render.h"

#define MC_MAX_VARS 16
#define MC_NAME_LEN 16

typedef struct {
    char name[MC_NAME_LEN];
    int value;
    int used;
} MCVar;

static MCVar vars[MC_MAX_VARS];

static char *out_buffer = 0;
static int out_max_len = 0;
static int out_pos = 0;

static void mc_output(const char *s)
{
    if (out_buffer)
    {
        int i = 0;
        while (s[i] && out_pos < out_max_len - 1)
        {
            out_buffer[out_pos++] = s[i++];
        }
        out_buffer[out_pos] = 0;
    }
    else
    {
        terminal_print(s);
    }
}

static int mc_str_eq(const char *a, const char *b)
{
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static int mc_is_digit(char c) { return c >= '0' && c <= '9'; }
static int mc_is_hex(char c)
{
    return mc_is_digit(c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
}

static int mc_str_to_int(const char *s)
{
    int neg = 0;
    int result = 0;
    if (*s == '-') { neg = 1; s++; }
    while (mc_is_digit(*s)) { result = result * 10 + (*s - '0'); s++; }
    return neg ? -result : result;
}

static uint32_t mc_hex_to_uint(const char *s)
{
    uint32_t result = 0;
    while (*s)
    {
        char c = *s;
        uint32_t val;
        if (c >= '0' && c <= '9') val = c - '0';
        else if (c >= 'a' && c <= 'f') val = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') val = c - 'A' + 10;
        else break;
        result = (result << 4) | val;
        s++;
    }
    return result;
}

static void mc_int_to_str(int val, char *out)
{
    char tmp[16];
    int i = 0;
    int neg = 0;
    if (val < 0) { neg = 1; val = -val; }
    if (val == 0) tmp[i++] = '0';
    while (val > 0) { tmp[i++] = '0' + (val % 10); val /= 10; }
    int j = 0;
    if (neg) out[j++] = '-';
    while (i > 0) out[j++] = tmp[--i];
    out[j] = 0;
}

static MCVar *mc_find_var(const char *name)
{
    for (int i = 0; i < MC_MAX_VARS; i++)
        if (vars[i].used && mc_str_eq(vars[i].name, name))
            return &vars[i];
    return 0;
}

static void mc_set_var(const char *name, int value)
{
    MCVar *v = mc_find_var(name);
    if (!v)
    {
        for (int i = 0; i < MC_MAX_VARS; i++)
        {
            if (!vars[i].used)
            {
                int j = 0;
                while (name[j] && j < MC_NAME_LEN - 1) { vars[i].name[j] = name[j]; j++; }
                vars[i].name[j] = 0;
                vars[i].used = 1;
                v = &vars[i];
                break;
            }
        }
    }
    if (v) v->value = value;
}

static int mc_resolve(const char *token)
{
    MCVar *v = mc_find_var(token);
    if (v) return v->value;
    return mc_str_to_int(token);
}

static uint32_t mc_resolve_color(const char *token)
{
    int all_hex = 1;
    int len = 0;
    for (int i = 0; token[i]; i++)
    {
        len++;
        if (!mc_is_hex(token[i])) { all_hex = 0; break; }
    }
    if (all_hex && len == 6)
        return mc_hex_to_uint(token);

    return (uint32_t)mc_resolve(token);
}

static int mc_split(char *line, char *tokens[], int max_tokens)
{
    int count = 0;
    int i = 0;
    while (line[i] && count < max_tokens)
    {
        while (line[i] == ' ') i++;
        if (!line[i]) break;
        tokens[count++] = &line[i];
        while (line[i] && line[i] != ' ') i++;
        if (line[i] == ' ') { line[i] = 0; i++; }
    }
    return count;
}

static void mc_run_line(char *line)
{
    char *tokens[8];
    int count = mc_split(line, tokens, 8);
    if (count == 0) return;

    if (mc_str_eq(tokens[0], "print"))
    {
        if (count < 2) { mc_output("\n"); return; }
        MCVar *v = mc_find_var(tokens[1]);
        if (v && count == 2)
        {
            char buf[16];
            mc_int_to_str(v->value, buf);
            mc_output(buf);
            mc_output("\n");
        }
        else
        {
            for (int i = 1; i < count; i++)
            {
                mc_output(tokens[i]);
                if (i < count - 1) mc_output(" ");
            }
            mc_output("\n");
        }
        return;
    }

    if (mc_str_eq(tokens[0], "set") && count >= 3)
    {
        mc_set_var(tokens[1], mc_resolve(tokens[2]));
        return;
    }

    if (mc_str_eq(tokens[0], "add") && count >= 4)
    {
        int a = mc_resolve(tokens[2]);
        int b = mc_resolve(tokens[3]);
        mc_set_var(tokens[1], a + b);
        return;
    }

    if (mc_str_eq(tokens[0], "sub") && count >= 4)
    {
        int a = mc_resolve(tokens[2]);
        int b = mc_resolve(tokens[3]);
        mc_set_var(tokens[1], a - b);
        return;
    }

    if (mc_str_eq(tokens[0], "clear") && count >= 2)
    {
        Framebuffer *fb = get_fb();
        uint32_t color = mc_resolve_color(tokens[1]);
        clear_screen(fb, color);
        return;
    }

    if (mc_str_eq(tokens[0], "rect") && count >= 6)
    {
        Framebuffer *fb = get_fb();
        int x = mc_resolve(tokens[1]);
        int y = mc_resolve(tokens[2]);
        int w = mc_resolve(tokens[3]);
        int h = mc_resolve(tokens[4]);
        uint32_t color = mc_resolve_color(tokens[5]);
        draw_rect(fb, x, y, w, h, color);
        return;
    }

    if (mc_str_eq(tokens[0], "pixel") && count >= 4)
    {
        Framebuffer *fb = get_fb();
        int x = mc_resolve(tokens[1]);
        int y = mc_resolve(tokens[2]);
        uint32_t color = mc_resolve_color(tokens[3]);
        draw_rect(fb, x, y, 1, 1, color);
        return;
    }

    if (mc_str_eq(tokens[0], "text") && count >= 4)
    {
        int x = mc_resolve(tokens[1]);
        int y = mc_resolve(tokens[2]);
        uint32_t color = (count >= 5) ? mc_resolve_color(tokens[4]) : 0xFFFFFF;
        draw_string(x, y, tokens[3], color);
        return;
    }

    mc_output("MC error: unknown statement -> ");
    mc_output(tokens[0]);
    mc_output("\n");
}

void mc_run_script(const char *script)
{
    char buffer[512];
    int i = 0;
    while (script[i] && i < 511)
    {
        buffer[i] = script[i];
        i++;
    }
    buffer[i] = 0;

    int start = 0;
    for (int p = 0; p <= i; p++)
    {
        if (buffer[p] == '\n' || buffer[p] == 0)
        {
            buffer[p] = 0;
            if (p > start)
                mc_run_line(&buffer[start]);
            start = p + 1;
        }
    }
}

void mc_run_script_from_vfs(const char *filename)
{
    char buffer[256];
    if (vfs_read_file(filename, buffer, 256))
    {
        mc_run_script(buffer);
    }
    else
    {
        mc_output("App script not found: ");
        mc_output(filename);
        mc_output("\n");
    }
}

void mc_run_script_to_buffer(const char *script, char *out, int max_len)
{
    out_buffer = out;
    out_max_len = max_len;
    out_pos = 0;
    out[0] = 0;

    mc_run_script(script);

    out_buffer = 0;
    out_max_len = 0;
    out_pos = 0;
}
