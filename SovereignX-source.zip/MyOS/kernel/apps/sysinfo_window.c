#include "sysinfo_window.h"
#include "../gui/cursor.h"
#include "../gui/background.h"
#include "../fb.h"
#include "../graphics.h"
#include "../text_render.h"
#include "../network/arp.h"

#define SYSINFO_X 160
#define SYSINFO_Y 120
#define SYSINFO_W 380
#define SYSINFO_H 260

static void int_to_str_local(int val, char *out)
{
    char tmp[16];
    int i = 0;
    int neg = 0;
    if (val < 0) { neg = 1; val = -val; }
    if (val == 0) tmp[i++] = '0';
    while (val > 0) { tmp[i++] = '0' + (val % 10); val /= 10; }
    int j = 0;
    if (neg) out[j++] = '-';
    while (i > 0) out[j++] = tmp[--i];
    out[j] = 0;
}

static void draw_row(int x, int y, const char *label, const char *value)
{
    draw_string(x, y, label, 0xAAAAAA);
    draw_string(x + 140, y, value, 0xFFFFFF);
}

void sysinfo_window_draw(void)
{
    Framebuffer *fb = get_fb();

    draw_rect(fb, SYSINFO_X, SYSINFO_Y, SYSINFO_W, SYSINFO_H, 0x000055);
    draw_rect(fb, SYSINFO_X, SYSINFO_Y, SYSINFO_W, 28, 0x0000AA);
    draw_circle(fb, SYSINFO_X + 16, SYSINFO_Y + 14, 8, 0xFF5555);
    draw_string(SYSINFO_X + 34, SYSINFO_Y + 9, "SYS INFO", 0xFFFFFF);

    int x = SYSINFO_X + 16;
    int y = SYSINFO_Y + 44;
    char buf[16];

    draw_row(x, y, "SovereignX Version", "v0.1"); y += 22;

    int_to_str_local((int)fb->width, buf);
    draw_row(x, y, "Resolution W", buf); y += 22;
    int_to_str_local((int)fb->height, buf);
    draw_row(x, y, "Resolution H", buf); y += 22;

    int_to_str_local(cursor_get_x(), buf);
    draw_row(x, y, "Mouse X", buf); y += 22;
    int_to_str_local(cursor_get_y(), buf);
    draw_row(x, y, "Mouse Y", buf); y += 22;

    unsigned char *ip = arp_get_my_ip();
    char ipbuf[20];
    int p = 0;
    for (int i = 0; i < 4; i++)
    {
        char n[8];
        int_to_str_local(ip[i], n);
        int k = 0;
        while (n[k]) ipbuf[p++] = n[k++];
        if (i < 3) ipbuf[p++] = '.';
    }
    ipbuf[p] = 0;
    draw_row(x, y, "IP Address", ipbuf); y += 22;

    uint32_t bg = background_get_color();
    char hexbuf[10];
    const char *hexchars = "0123456789ABCDEF";
    hexbuf[0] = '0';
    hexbuf[1] = 'x';
    for (int i = 0; i < 6; i++)
        hexbuf[2 + i] = hexchars[(bg >> ((5 - i) * 4)) & 0xF];
    hexbuf[8] = 0;
    draw_row(x, y, "BG Color", hexbuf); y += 22;
}
