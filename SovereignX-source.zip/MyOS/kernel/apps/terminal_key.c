#include "terminal.h"
#include "terminal_commands.h"
#include "code_editor.h"
#include "dev_shell.h"
#include "../network/dns.h"

static char buffer[TERMINAL_ROWS][TERMINAL_COLS];
static int cur_row = 0;
static int cur_col = 0;

static char cmdline[TERMINAL_COLS];
static int cmd_len = 0;

static void print_string(const char *s)
{
    while (*s)
    {
        if (*s == '\n')
        {
            cur_col = 0;
            cur_row++;
        }
        else
        {
            if (cur_col >= TERMINAL_COLS)
            {
                cur_col = 0;
                cur_row++;
            }
            if (cur_row >= TERMINAL_ROWS)
            {
                for (int r = 1; r < TERMINAL_ROWS; r++)
                    for (int c = 0; c < TERMINAL_COLS; c++)
                        buffer[r - 1][c] = buffer[r][c];
                for (int c = 0; c < TERMINAL_COLS; c++)
                    buffer[TERMINAL_ROWS - 1][c] = 0;
                cur_row = TERMINAL_ROWS - 1;
            }
            buffer[cur_row][cur_col] = *s;
            cur_col++;
        }
        s++;
    }
}

void terminal_print(const char *s)
{
    print_string(s);
}

static void new_line(void)
{
    cur_col = 0;
    cur_row++;
    if (cur_row >= TERMINAL_ROWS)
    {
        for (int r = 1; r < TERMINAL_ROWS; r++)
            for (int c = 0; c < TERMINAL_COLS; c++)
                buffer[r - 1][c] = buffer[r][c];
        for (int c = 0; c < TERMINAL_COLS; c++)
            buffer[TERMINAL_ROWS - 1][c] = 0;
        cur_row = TERMINAL_ROWS - 1;
    }
}

static void clear_terminal(void)
{
    for (int r = 0; r < TERMINAL_ROWS; r++)
        for (int c = 0; c < TERMINAL_COLS; c++)
            buffer[r][c] = 0;
    cur_row = 0;
    cur_col = 0;
}

static int str_eq(const char *a, const char *b)
{
    while (*a && *b)
    {
        if (*a != *b) return 0;
        a++; b++;
    }
    return *a == *b;
}

static int str_starts_with(const char *s, const char *prefix)
{
    while (*prefix)
    {
        if (*s != *prefix) return 0;
        s++; prefix++;
    }
    return 1;
}

static void run_command(const char *cmd)
{
    if (cmd[0] == 0)
        return;

    if (str_starts_with(cmd, "play game "))
    {
        editor_open(cmd + 10, 1);
        return;
    }

    if (str_starts_with(cmd, "play app "))
    {
        editor_open(cmd + 9, 0);
        return;
    }

    if (str_eq(cmd, "devshell") || str_eq(cmd, "dev shell"))
    {
        dev_shell_open();
        return;
    }

    if (terminal_handle_system_command(cmd))
    {
        return;
    }

    if (str_starts_with(cmd, "resolve "))
    {
        dns_query(cmd + 8);
        print_string("Query sent. Type 'dns_status' in a second to check.\n");
        return;
    }

    if (str_eq(cmd, "dns_status"))
    {
        if (dns_is_ready())
        {
            unsigned char *ip = dns_get_result();
            char buf[24];
            int p = 0;
            for (int seg = 0; seg < 4; seg++)
            {
                int v = ip[seg];
                if (v >= 100) buf[p++] = '0' + (v / 100);
                if (v >= 10)  buf[p++] = '0' + ((v / 10) % 10);
                buf[p++] = '0' + (v % 10);
                if (seg < 3) buf[p++] = '.';
            }
            buf[p] = 0;
            print_string("Resolved: ");
            print_string(buf);
            print_string("\n");
        }
        else
        {
            print_string("Not ready yet. Try 'resolve <host>' again.\n");
        }
        return;
    }

    if (str_eq(cmd, "help"))
    {
        print_string("Local: help, clear, about, echo <text>, uname, uname -a\n");
        print_string("Colors: color <name>, bgcolor <hex>, bgreset, colors\n");
        print_string("Windows: open files/settings/terminal, shutdown\n");
        print_string("Info: sysinfo, version, whoami, uptime, changelog\n");
        print_string("Math: add <a> <b>, sub <a> <b>\n");
        print_string("Files: touch, ls, cat, rm, write <file> <text>\n");
        print_string("Code: play game <name> / play app <name>\n");
        print_string("Network: resolve <host>, dns_status\n");
        print_string("Dev: devshell\n");
        print_string("Keybinds: bind game/app <name> <key>, bind list\n");
        print_string("Desktop: theme <name>, icon add/remove, layout save/load\n");
    }
    else if (str_eq(cmd, "clear"))
    {
        clear_terminal();
        return;
    }
    else if (str_eq(cmd, "about"))
    {
        print_string("SovereignX - a hobby operating system.\n");
    }
    else if (str_eq(cmd, "uname"))
    {
        print_string("SovereignX\n");
    }
    else if (str_eq(cmd, "uname -a"))
    {
        print_string("SovereignX 0.6-RELEASE SovereignX amd64\n");
    }
    else if (str_starts_with(cmd, "echo "))
    {
        print_string(cmd + 5);
        print_string("\n");
    }
    else
    {
        print_string("Unknown command: ");
        print_string(cmd);
        print_string("\n");
    }
}

void terminal_init(void)
{
    clear_terminal();
    cmd_len = 0;
    print_string("amir@sovereignx:~ # ");
}

void terminal_key(char c)
{
    if (editor_is_active())
    {
        editor_key(c);
        return;
    }

    if (c == '\n')
    {
        cmdline[cmd_len] = 0;
        new_line();
        run_command(cmdline);
        if (!editor_is_active())
            print_string("amir@sovereignx:~ # ");
        cmd_len = 0;
        return;
    }

    if (c == '\b')
    {
        if (cmd_len > 0)
        {
            cmd_len--;
            if (cur_col > 0)
            {
                cur_col--;
                buffer[cur_row][cur_col] = 0;
            }
        }
        return;
    }

    if (cmd_len < TERMINAL_COLS - 1)
    {
        cmdline[cmd_len++] = c;

        if (cur_col >= TERMINAL_COLS)
            new_line();

        buffer[cur_row][cur_col] = c;
        cur_col++;
    }
}

char terminal_get_char(int row, int col)
{
    if (row < 0 || row >= TERMINAL_ROWS || col < 0 || col >= TERMINAL_COLS)
        return 0;
    return buffer[row][col];
}

int terminal_get_cursor_row(void) { return cur_row; }
int terminal_get_cursor_col(void) { return cur_col; }
