#ifndef SETTINGS_WINDOW_H
#define SETTINGS_WINDOW_H

void settings_window_draw(void);

#endif
