#include "boot_config.h"
#include "../fb.h"
#include "../graphics.h"
#include "../text_render.h"
#include "../gui/desktop.h"
#include "../gui/background.h"

static void bc_delay(void)
{
    for (volatile int i = 0; i < 6000000; i++);
}

static void bc_short(void)
{
    for (volatile int i = 0; i < 1000000; i++);
}

static inline unsigned char inb(unsigned short port)
{
    unsigned char val;
    asm volatile ("inb %1, %0" : "=a"(val) : "Nd"(port));
    return val;
}

static const char sc_ascii[128] = {
    0,27,'1','2','3','4','5','6','7','8','9','0','-','=','\b',
    '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',
    0,'a','s','d','f','g','h','j','k','l',';','\'','`',
    0,'\\','z','x','c','v','b','n','m',',','.','/',0,
    '*',0,' ',0,
};

static unsigned char read_sc(void)
{
    while (!(inb(0x64) & 1));
    return inb(0x60);
}

static char read_key(unsigned char *sc_out)
{
    unsigned char sc;
    while (1)
    {
        sc = read_sc();
        if (sc & 0x80) continue;
        if (sc_out) *sc_out = sc;
        if (sc < 128) return sc_ascii[sc];
        return 0;
    }
}

static void fill_blue(Framebuffer *fb)
{
    uint32_t pixels = fb->height * (fb->pitch / 4);
    for (uint32_t i = 0; i < pixels; i++)
        fb->buffer[i] = 0x000080;
}

/* ========== تنظیمات ========== */
static int cfg_videomode   = 0;
static int cfg_disks       = 0;
static int cfg_debug       = 0;
static int cfg_launcher    = 1;
static int cfg_boot_device = 0;

static const char *videomodes[]   = { "800x600x32", "1024x768x32", "640x480x32" };
static const char *boot_devices[] = { "ISO/CDROM", "Hard Drive", "USB Drive" };

/* ========== Bootloader Builder ========== */
#define BL_ROWS 32
#define BL_COLS 76
#define BL_CMD  128

static char bl_screen[BL_ROWS][BL_COLS];
static int bl_row = 0;
static int bl_col = 0;
static char bl_cmd[BL_CMD];
static int bl_cmd_len = 0;
static int bl_active = 0;

static char bl_name[32]   = "MyBootloader";
static char bl_entry[32]  = "0x7C00";
static char bl_stack[32]  = "0x9000";
static char bl_msg[64]    = "Loading SovereignX...";
static char bl_target[32] = "kernel.bin";
static int  bl_bios_int   = 1;
static int  bl_uefi       = 0;
static int  bl_mbr        = 1;

static void bl_scroll(void)
{
    for (int r=1;r<BL_ROWS;r++)
        for (int c=0;c<BL_COLS;c++)
            bl_screen[r-1][c]=bl_screen[r][c];
    for (int c=0;c<BL_COLS;c++) bl_screen[BL_ROWS-1][c]=0;
    bl_row=BL_ROWS-1;
}

static void bl_nl(void)
{
    bl_col=0; bl_row++;
    if(bl_row>=BL_ROWS) bl_scroll();
}

static void bl_print(const char *s)
{
    while(*s){
        if(*s=='\n'){bl_nl();}
        else{
            if(bl_col>=BL_COLS) bl_nl();
            if(bl_row>=BL_ROWS) bl_scroll();
            bl_screen[bl_row][bl_col++]=*s;
        }
        s++;
    }
}

static void bl_render(void)
{
    Framebuffer *fb = get_fb();
    fill_blue(fb);

    draw_rect(fb, 0, 0, fb->width, 16, 0x000080);
    draw_string(4, 2, "SovereignX Bootloader Builder v1.0", 0xFFFFFF);
    draw_string(fb->width - 160, 2, "SovereignX OS", 0xFFFFFF);
    draw_rect(fb, 0, 16, fb->width, 1, 0xAAAAAA);

    for (int r=0;r<BL_ROWS;r++)
    {
        char line[BL_COLS+1];
        for(int c=0;c<BL_COLS;c++){
            char ch=bl_screen[r][c];
            line[c]=ch?ch:' ';
        }
        line[BL_COLS]=0;

        uint32_t color=0xFFFFFF;
        if(line[0]=='='&&line[1]=='=') color=0xFFFF55;
        else if(line[0]==' '&&line[1]==' ') color=0x55FF55;
        else if(line[0]=='[') color=0x55FFFF;
        else if(line[0]=='>') color=0xFFFF55;

        draw_string(4, 20+r*13, line, color);
    }

    draw_rect(fb, 0, fb->height-20, fb->width, 20, 0x000080);
    draw_rect(fb, 0, fb->height-20, fb->width, 1, 0xAAAAAA);
    draw_string(4, fb->height-14, "F5=Build | F10=Exit | Type commands below", 0xFFFFFF);

    fb_present();
}

static void bl_str_copy(char *dst, const char *src, int max)
{
    int i=0;
    while(src[i]&&i<max-1){dst[i]=src[i];i++;}
    dst[i]=0;
}

static int bl_str_eq(const char *a, const char *b)
{
    while(*a&&*b){if(*a!=*b)return 0;a++;b++;}
    return *a==*b;
}

static int bl_starts(const char *s, const char *p)
{
    while(*p){if(*s!=*p)return 0;s++;p++;}
    return 1;
}

static void bl_build(void)
{
    bl_print("\n=== Building Bootloader ===\n");
    bl_render(); bc_short();
    bl_print("  Name:    "); bl_print(bl_name);   bl_print("\n");
    bl_render(); bc_short();
    bl_print("  Entry:   "); bl_print(bl_entry);  bl_print("\n");
    bl_render(); bc_short();
    bl_print("  Stack:   "); bl_print(bl_stack);  bl_print("\n");
    bl_render(); bc_short();
    bl_print("  Message: "); bl_print(bl_msg);    bl_print("\n");
    bl_render(); bc_short();
    bl_print("  Target:  "); bl_print(bl_target); bl_print("\n");
    bl_render(); bc_delay();

    bl_print("[Generating MBR stub...]\n");
    bl_render(); bc_delay();
    bl_print("[Writing boot signature 0xAA55...]\n");
    bl_render(); bc_delay();
    bl_print("[Linking entry point ");
    bl_print(bl_entry); bl_print("...]\n");
    bl_render(); bc_delay();
    bl_print("[Setting stack to ");
    bl_print(bl_stack); bl_print("...]\n");
    bl_render(); bc_delay();
    if(bl_bios_int){
        bl_print("[Adding BIOS INT 0x13 disk read...]\n");
        bl_render(); bc_delay();
    }
    if(bl_uefi){
        bl_print("[Adding UEFI EFI stub...]\n");
        bl_render(); bc_delay();
    }
    bl_print("[Embedding message: \"");
    bl_print(bl_msg); bl_print("\"...]\n");
    bl_render(); bc_delay();
    bl_print("[Writing target: ");
    bl_print(bl_target); bl_print("...]\n");
    bl_render(); bc_delay();
    bl_print("\n> Build complete!\n");
    bl_print("> Bootloader: "); bl_print(bl_name); bl_print(".bin\n");
    bl_print("> Size: 512 bytes (1 sector)\n");
    bl_render();
}

static void bl_run_cmd(const char *cmd)
{
    if(cmd[0]==0) return;

    if(bl_str_eq(cmd,"help")){
        bl_print("=== Bootloader Builder ===\n");
        bl_print("  show           - show config\n");
        bl_print("  set name <x>   - bootloader name\n");
        bl_print("  set entry <x>  - entry point (0x7C00)\n");
        bl_print("  set stack <x>  - stack (0x9000)\n");
        bl_print("  set msg <text> - boot message\n");
        bl_print("  set target <x> - target file\n");
        bl_print("  set bios on/off\n");
        bl_print("  set uefi on/off\n");
        bl_print("  set mbr on/off\n");
        bl_print("  build  - build bootloader\n");
        bl_print("  clear  - clear screen\n");
        bl_print("  exit   - exit builder\n");
        return;
    }
    if(bl_str_eq(cmd,"show")||bl_str_eq(cmd,"config")){
        bl_print("=== Current Config ===\n");
        bl_print("  name=");    bl_print(bl_name);   bl_print("\n");
        bl_print("  entry=");   bl_print(bl_entry);  bl_print("\n");
        bl_print("  stack=");   bl_print(bl_stack);  bl_print("\n");
        bl_print("  message="); bl_print(bl_msg);    bl_print("\n");
        bl_print("  target=");  bl_print(bl_target); bl_print("\n");
        bl_print(bl_bios_int?"  bios_int=on\n":"  bios_int=off\n");
        bl_print(bl_uefi?"  uefi=on\n":"  uefi=off\n");
        bl_print(bl_mbr?"  mbr=on\n":"  mbr=off\n");
        return;
    }
    if(bl_str_eq(cmd,"build")){ bl_build(); return; }
    if(bl_str_eq(cmd,"clear")){
        for(int r=0;r<BL_ROWS;r++)
            for(int c=0;c<BL_COLS;c++)
                bl_screen[r][c]=0;
        bl_row=0; bl_col=0; return;
    }
    if(bl_str_eq(cmd,"exit")||bl_str_eq(cmd,"quit")){
        bl_active=0; return;
    }
    if(bl_starts(cmd,"set name "))
    { bl_str_copy(bl_name,cmd+9,32); bl_print("name set.\n"); return; }
    if(bl_starts(cmd,"set entry "))
    { bl_str_copy(bl_entry,cmd+10,32); bl_print("entry set.\n"); return; }
    if(bl_starts(cmd,"set stack "))
    { bl_str_copy(bl_stack,cmd+10,32); bl_print("stack set.\n"); return; }
    if(bl_starts(cmd,"set msg "))
    { bl_str_copy(bl_msg,cmd+8,64); bl_print("message set.\n"); return; }
    if(bl_starts(cmd,"set target "))
    { bl_str_copy(bl_target,cmd+11,32); bl_print("target set.\n"); return; }
    if(bl_str_eq(cmd,"set bios on")) { bl_bios_int=1; bl_print("bios=on\n"); return; }
    if(bl_str_eq(cmd,"set bios off")){ bl_bios_int=0; bl_print("bios=off\n"); return; }
    if(bl_str_eq(cmd,"set uefi on")) { bl_uefi=1; bl_print("uefi=on\n"); return; }
    if(bl_str_eq(cmd,"set uefi off")){ bl_uefi=0; bl_print("uefi=off\n"); return; }
    if(bl_str_eq(cmd,"set mbr on"))  { bl_mbr=1; bl_print("mbr=on\n"); return; }
    if(bl_str_eq(cmd,"set mbr off")) { bl_mbr=0; bl_print("mbr=off\n"); return; }

    bl_print("Unknown: "); bl_print(cmd); bl_print("\nType 'help'\n");
}

static void run_bootloader_builder(void)
{
    for(int r=0;r<BL_ROWS;r++)
        for(int c=0;c<BL_COLS;c++)
            bl_screen[r][c]=0;
    bl_row=0; bl_col=0; bl_cmd_len=0;
    bl_active=1;

    bl_print("SovereignX Bootloader Builder\n");
    bl_print("Type 'help' for commands. F5=Build F10=Exit\n");
    bl_print("================================\n\n");
    bl_print("builder@sovereignx:~$ ");
    bl_render();

    while(bl_active)
    {
        unsigned char sc;
        char c = read_key(&sc);

        if(sc==0x3F){ /* F5=build */
            bl_cmd[bl_cmd_len]=0; bl_nl();
            bl_build(); bl_cmd_len=0;
            if(bl_active) bl_print("builder@sovereignx:~$ ");
            bl_render(); continue;
        }
        if(sc==0x44){ bl_active=0; break; } /* F10 */

        if(c=='\n'){
            bl_cmd[bl_cmd_len]=0; bl_nl();
            bl_run_cmd(bl_cmd); bl_cmd_len=0;
            if(bl_active) bl_print("builder@sovereignx:~$ ");
            bl_render(); continue;
        }
        if(c=='\b'){
            if(bl_cmd_len>0){
                bl_cmd_len--;
                if(bl_col>0){bl_col--;bl_screen[bl_row][bl_col]=0;}
                bl_render();
            }
            continue;
        }
        if(c>=32&&c<127&&bl_cmd_len<BL_CMD-1){
            bl_cmd[bl_cmd_len++]=c;
            if(bl_col>=BL_COLS) bl_nl();
            bl_screen[bl_row][bl_col++]=c;
            bl_render();
        }
    }
}

/* ========== Boot Config Screen ========== */
static void draw_boot_config(void)
{
    Framebuffer *fb = get_fb();
    fill_blue(fb);

    draw_rect(fb, 0, 0, fb->width, 16, 0x000080);
    draw_string(4, 2, "SovereignX v0.6-RELEASE", 0xFFFFFF);
    draw_string(fb->width - 120, 2, "Boot Config", 0xFFFFFF);
    draw_rect(fb, 0, 16, fb->width, 1, 0xAAAAAA);

    int y = 26;
    draw_string(4, y, "SovereignX Boot Configuration", 0xFFFFFF); y+=18;
    draw_string(4, y, "Press key [a-e] to toggle. Enter=Boot. Esc=Desktop. P=Builder.", 0xFFFF55); y+=18;
    draw_string(4, y, "================================================================", 0x888888); y+=14;
    draw_string(4, y, "Current settings:", 0xFFFFFF); y+=16;

    draw_string(4, y, " [a] Videomode: ", 0xFFFFFF);
    draw_string(4+8*16, y, videomodes[cfg_videomode], 0x55FF55);
    y+=14;

    draw_string(4, y, " [b] Add disks visible by BIOS: ", 0xFFFFFF);
    draw_string(4+8*32, y, cfg_disks?"on ":"off", cfg_disks?0x55FF55:0xFF5555);
    y+=14;

    draw_string(4, y, " [c] Duplicate debug output to screen: ", 0xFFFFFF);
    draw_string(4+8*39, y, cfg_debug?"on ":"off", cfg_debug?0x55FF55:0xFF5555);
    y+=14;

    draw_string(4, y, " [d] Start LAUNCHER after kernel loaded: ", 0xFFFFFF);
    draw_string(4+8*41, y, cfg_launcher?"on ":"off", cfg_launcher?0x55FF55:0xFF5555);
    y+=14;

    draw_string(4, y, " [e] Boot device: ", 0xFFFFFF);
    draw_string(4+8*18, y, boot_devices[cfg_boot_device], 0x55FFFF);
    y+=18;

    draw_string(4, y, " [p] Bootloader Builder - build your custom bootloader", 0x55FF55);
    y+=20;

    draw_string(4, y, "================================================================", 0x888888); y+=14;
    draw_string(4, y, "Press Enter to boot with current settings", 0xFFFFFF); y+=14;
    draw_string(4, y, "Press Escape to return to SovereignX desktop", 0xAAAAAA);

    draw_rect(fb, 0, fb->height-20, fb->width, 20, 0x000080);
    draw_rect(fb, 0, fb->height-20, fb->width, 1, 0xAAAAAA);
    draw_string(4, fb->height-14,
        "SovereignX comes with ABSOLUTELY NO WARRANTY. Open Source Project.",
        0xAAAAAA);

    fb_present();
}

void boot_config_run(void)
{
    draw_boot_config();

    while(1)
    {
        unsigned char sc;
        char c = read_key(&sc);

        if(sc==0x01){ desktop_redraw(); return; } /* ESC */
        if(c=='\n') { desktop_redraw(); return; } /* Enter */

        if(c=='a'||c=='A')
        { cfg_videomode=(cfg_videomode+1)%3; draw_boot_config(); continue; }

        if(c=='b'||c=='B')
        { cfg_disks=!cfg_disks; draw_boot_config(); continue; }

        if(c=='c'||c=='C')
        { cfg_debug=!cfg_debug; draw_boot_config(); continue; }

        if(c=='d'||c=='D')
        { cfg_launcher=!cfg_launcher; draw_boot_config(); continue; }

        if(c=='e'||c=='E')
        { cfg_boot_device=(cfg_boot_device+1)%3; draw_boot_config(); continue; }

        if(c=='p'||c=='P')
        { run_bootloader_builder(); draw_boot_config(); continue; }
    }
}
