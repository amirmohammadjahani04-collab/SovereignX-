#ifndef HTTP_CLIENT_H
#define HTTP_CLIENT_H

void http_get(unsigned char *dest_ip, unsigned short port, const char *path);

#endif
