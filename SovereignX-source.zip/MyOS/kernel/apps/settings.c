#include "settings.h"

static volatile unsigned short *vga =
    (unsigned short*)0xb8000;


static void write_text(int pos,char *s)
{
    int i=0;

    while(s[i])
    {
        vga[pos+i] =
            s[i] | 0x0700;
        i++;
    }
}


void settings_init()
{
}


void settings_show()
{
    write_text(
        80,
        "SovereignX Settings"
    );

    write_text(
        160,
        "Display: 1024x768"
    );

    write_text(
        240,
        "Theme: Default"
    );

    write_text(
        320,
        "System: SovereignX"
    );
}
