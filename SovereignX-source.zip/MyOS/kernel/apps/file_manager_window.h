#ifndef FILE_MANAGER_WINDOW_H
#define FILE_MANAGER_WINDOW_H

void file_manager_window_draw(void);
void file_manager_new_file(void);
void file_manager_rename_last(void);
void file_manager_copy(void);
void file_manager_paste(void);

#endif
