#ifndef PKG_MANAGER_H
#define PKG_MANAGER_H

int pkg_install(const char *name);
int pkg_xorg_installed(void);
int pkg_wm_installed(void);
const char *pkg_wm_name(void);
void pkg_list(void);
void pkg_avail(void);

#endif
