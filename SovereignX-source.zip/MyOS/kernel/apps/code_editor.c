#include "code_editor.h"
#include "terminal_commands.h"
#include "mc_lang.h"
#include "games.h"
#include "../gui/wm.h"
#include "../fb.h"
#include "../graphics.h"
#include "../text_render.h"

#define BUF_LEN 1024
#define NAME_LEN 32
#define OUT_LEN 512

#define CC_X 60
#define CC_Y 60
#define CC_W 420
#define CC_H 420

#define RUN_BTN_X (CC_X + 16)
#define RUN_BTN_Y (CC_Y + CC_H - 34)
#define RUN_BTN_W 70
#define RUN_BTN_H 22

static char code_buffer[BUF_LEN];
static int buf_len = 0;
static int active = 0;
static int is_game_mode = 0;
static int is_studio_mode = 0;
static char editor_name[NAME_LEN];
static char status_line[64] = "";

static char run_output[OUT_LEN];
static int has_output = 0;

static void set_status(const char *s)
{
    int i = 0;
    while (s[i] && i < 63) { status_line[i] = s[i]; i++; }
    status_line[i] = 0;
}

void editor_open(const char *name, int is_game)
{
    int i = 0;
    while (name[i] && i < NAME_LEN - 1) { editor_name[i] = name[i]; i++; }
    editor_name[i] = 0;

    is_game_mode = is_game;
    is_studio_mode = 0;
    buf_len = 0;
    code_buffer[0] = 0;
    active = 1;
    has_output = 0;
    set_status("New file. Type M.C code below.");
}

void editor_open_existing(const char *name, int is_game)
{
    int i = 0;
    while (name[i] && i < NAME_LEN - 1) { editor_name[i] = name[i]; i++; }
    editor_name[i] = 0;

    is_game_mode = is_game;
    is_studio_mode = 0;
    has_output = 0;

    if (vfs_read_file(name, code_buffer, BUF_LEN))
    {
        buf_len = 0;
        while (code_buffer[buf_len]) buf_len++;
        set_status("Loaded existing code.");
    }
    else
    {
        buf_len = 0;
        code_buffer[0] = 0;
        set_status("No saved code found.");
    }

    active = 1;
}

void editor_open_studio(void)
{
    int i = 0;
    const char *name = "MC Studio";
    while (name[i] && i < NAME_LEN - 1) { editor_name[i] = name[i]; i++; }
    editor_name[i] = 0;

    is_game_mode = 0;
    is_studio_mode = 1;
    has_output = 0;

    if (!vfs_read_file("studio_last.mc", code_buffer, BUF_LEN))
    {
        buf_len = 0;
        code_buffer[0] = 0;
    }
    else
    {
        buf_len = 0;
        while (code_buffer[buf_len]) buf_len++;
    }

    active = 1;
    set_status("M.C Studio: free code. Ctrl+R=Run, Ctrl+Alt+X=Exit");
}

int editor_is_active(void)
{
    return active;
}

void editor_key(char c)
{
    if (!active) return;

    if (c == '\n')
    {
        if (buf_len < BUF_LEN - 1)
        {
            code_buffer[buf_len++] = '\n';
            code_buffer[buf_len] = 0;
        }
        return;
    }

    if (c == '\b')
    {
        if (buf_len > 0)
        {
            buf_len--;
            code_buffer[buf_len] = 0;
        }
        return;
    }

    if (buf_len < BUF_LEN - 1)
    {
        code_buffer[buf_len++] = c;
        code_buffer[buf_len] = 0;
    }
}

void editor_run(void)
{
    if (!active) return;
    set_status("Executed. Output below:");
    mc_run_script_to_buffer(code_buffer, run_output, OUT_LEN);
    has_output = 1;
    fb_present();

    if (is_studio_mode)
    {
        vfs_write_file("studio_last.mc", code_buffer);
    }
}

void editor_exit(void)
{
    if (!active) return;
    active = 0;

    if (is_studio_mode)
    {
        vfs_write_file("studio_last.mc", code_buffer);
        return;
    }

    vfs_write_file(editor_name, code_buffer);

    if (is_game_mode)
    {
        game_confirm_save(1);
    }
}

static int point_in_run_button(int mx, int my)
{
    return (mx >= RUN_BTN_X && mx <= RUN_BTN_X + RUN_BTN_W &&
            my >= RUN_BTN_Y && my <= RUN_BTN_Y + RUN_BTN_H);
}

static int point_in_close_button(int mx, int my)
{
    int cx = CC_X + 16;
    int cy = CC_Y + 14;
    int dx = mx - cx;
    int dy = my - cy;
    return (dx * dx + dy * dy) <= (10 * 10);
}

void editor_handle_click(int mx, int my)
{
    if (!active) return;

    if (point_in_close_button(mx, my))
    {
        editor_exit();
        return;
    }

    if (point_in_run_button(mx, my))
    {
        editor_run();
        return;
    }
}

void editor_window_draw(void)
{
    if (!active) return;

    const char *title = is_studio_mode ? "M.C Studio" : "CodeCraft";
    wm_draw_window(CC_X, CC_Y, CC_W, CC_H, title);

    Framebuffer *fb = get_fb();

    draw_string(CC_X + 16, CC_Y + 30, editor_name, 0x55FFFF);

    int x = CC_X + 16;
    int y = CC_Y + 50;
    int code_max_y = has_output ? (CC_Y + 190) : (CC_Y + CC_H - 60);

    int line_start = 0;
    for (int i = 0; i <= buf_len && y < code_max_y; i++)
    {
        if (code_buffer[i] == '\n' || code_buffer[i] == 0)
        {
            char line[80];
            int len = i - line_start;
            if (len > 78) len = 78;
            for (int k = 0; k < len; k++) line[k] = code_buffer[line_start + k];
            line[len] = 0;
            draw_string(x, y, line, 0xE0E0E0);
            y += 14;
            line_start = i + 1;
            if (code_buffer[i] == 0) break;
        }
    }

    draw_rect(fb, x, y, 8, 12, 0x55FFFF);

    if (has_output)
    {
        int oy = CC_Y + 200;
        draw_rect(fb, CC_X + 10, oy - 6, CC_W - 20, 1, 0x444444);
        draw_string(x, oy, "Output:", 0x55FF88);
        oy += 16;

        int max_oy = CC_Y + CC_H - 60;
        int ostart = 0;
        int olen = 0;
        while (run_output[olen]) olen++;

        for (int i = 0; i <= olen && oy < max_oy; i++)
        {
            if (run_output[i] == '\n' || run_output[i] == 0)
            {
                char line[80];
                int len = i - ostart;
                if (len > 78) len = 78;
                for (int k = 0; k < len; k++) line[k] = run_output[ostart + k];
                line[len] = 0;
                draw_string(x, oy, line, 0xFFFF88);
                oy += 14;
                ostart = i + 1;
                if (run_output[i] == 0) break;
            }
        }
    }

    draw_rect(fb, RUN_BTN_X, RUN_BTN_Y, RUN_BTN_W, RUN_BTN_H, 0x4AE86F);
    draw_string(RUN_BTN_X + 18, RUN_BTN_Y + 6, "RUN", 0x000000);

    draw_string(RUN_BTN_X + RUN_BTN_W + 14, RUN_BTN_Y + 6, "Ctrl+R = Run", 0x888888);

    draw_string(CC_X + 16, CC_Y + CC_H - 14, status_line, 0xAAAAAA);
}
