#ifndef BOOT_CONFIG_H
#define BOOT_CONFIG_H

void boot_config_run(void);

#endif
