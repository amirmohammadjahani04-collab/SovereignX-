#ifndef FILE_MANAGER_H
#define FILE_MANAGER_H

void file_manager_init();
void file_manager_show();

#endif
