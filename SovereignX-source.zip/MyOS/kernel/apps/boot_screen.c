#include "boot_screen.h"
#include "../fb.h"
#include "../graphics.h"
#include "../text_render.h"
#include "../gui/desktop.h"
#include "../gui/background.h"
#include "../gui/icons.h"

static void bs_delay(void)
{
    for (volatile int i = 0; i < 8000000; i++);
}

static void bs_short(void)
{
    for (volatile int i = 0; i < 1500000; i++);
}

static inline unsigned char inb(unsigned short port)
{
    unsigned char val;
    asm volatile ("inb %1, %0" : "=a"(val) : "Nd"(port));
    return val;
}

static const char sc_ascii[128] = {
    0,27,'1','2','3','4','5','6','7','8','9','0','-','=','\b',
    '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',
    0,'a','s','d','f','g','h','j','k','l',';','\'','`',
    0,'\\','z','x','c','v','b','n','m',',','.','/',0,
    '*',0,' ',0,
};

/* F5=0x3F F10=0x44 Up=0x48 Down=0x50 Left=0x4B Right=0x4D */
#define SC_F5   0x3F
#define SC_F10  0x44
#define SC_UP   0x48
#define SC_DOWN 0x50
#define SC_LEFT 0x4B
#define SC_RIGHT 0x4D

static unsigned char read_scancode(void)
{
    while (!(inb(0x64) & 1));
    return inb(0x60);
}

static char read_key_raw(unsigned char *sc_out)
{
    unsigned char sc;
    while (1)
    {
        sc = read_scancode();
        if (sc & 0x80) continue;
        if (sc_out) *sc_out = sc;
        if (sc < 128) return sc_ascii[sc];
        return 0;
    }
}

/* ========== Shell Screen ========== */
#define SH_ROWS 42
#define SH_COLS 80
#define SH_CMD  128

static char sh_screen[SH_ROWS][SH_COLS];
static int sh_row = 0;
static int sh_col = 0;
static char sh_cmd[SH_CMD];
static int sh_cmd_len = 0;
static int sh_active = 0;
static int sh_logged_in = 0;
static uint32_t sh_text_color = 0x33FF66;

/* ========== Config قابل ویرایش ========== */
#define CFG_LINES 12
#define CFG_LINE_LEN 64

static char cfg[CFG_LINES][CFG_LINE_LEN] = {
    "bgcolor=0x12121F",
    "taskbar_color=0x14141F",
    "icon0_color=0x4A6FE8",
    "icon1_color=0xE84A4A",
    "icon2_color=0xE8B84A",
    "icon3_color=0x4AE86F",
    "icon4_color=0x8A4AE8",
    "text_color=0x33FF66",
    "os_name=SovereignX",
    "version=0.6-RELEASE",
    "username=amir",
    "hostname=sovereignx",
};

/* ========== hex parser ========== */
static uint32_t parse_hex(const char *s)
{
    if (s[0]=='0'&&(s[1]=='x'||s[1]=='X')) s+=2;
    uint32_t r=0;
    while (*s) {
        char c=*s;
        uint32_t v;
        if(c>='0'&&c<='9') v=c-'0';
        else if(c>='a'&&c<='f') v=c-'a'+10;
        else if(c>='A'&&c<='F') v=c-'A'+10;
        else break;
        r=(r<<4)|v; s++;
    }
    return r;
}

static int cfg_str_eq(const char *a, const char *b)
{
    while (*a&&*b){if(*a!=*b)return 0;a++;b++;}
    return *a==*b;
}

static int cfg_starts(const char *s, const char *p)
{
    while (*p){if(*s!=*p)return 0;s++;p++;}
    return 1;
}

/* مقدار بعد از = رو برمیگردونه */
static const char *cfg_val(const char *line)
{
    while (*line && *line != '=') line++;
    if (*line == '=') line++;
    return line;
}

/* اعمال config روی دسکتاپ */
static void apply_config(void)
{
    for (int i = 0; i < CFG_LINES; i++)
    {
        const char *l = cfg[i];
        const char *v = cfg_val(l);

        if (cfg_starts(l, "bgcolor="))
            background_set_color(parse_hex(v));
        else if (cfg_starts(l, "icon0_color="))
            icons_set_color(0, parse_hex(v));
        else if (cfg_starts(l, "icon1_color="))
            icons_set_color(1, parse_hex(v));
        else if (cfg_starts(l, "icon2_color="))
            icons_set_color(2, parse_hex(v));
        else if (cfg_starts(l, "icon3_color="))
            icons_set_color(3, parse_hex(v));
        else if (cfg_starts(l, "icon4_color="))
            icons_set_color(4, parse_hex(v));
        else if (cfg_starts(l, "text_color="))
            sh_text_color = parse_hex(v);
    }
    desktop_redraw();
}

/* ========== Editor ========== */
static void run_editor(const char *fname)
{
    int editing = cfg_str_eq(fname, "config") || cfg_str_eq(fname, "config.cfg");
    int cur_line = 0;
    int cur_pos = 0;

    Framebuffer *fb = get_fb();

    while (1)
    {
        /* رسم Editor */
        clear_screen(fb, 0x000000);

        draw_string(4, 4, "SovereignX Editor | F5=Save+Apply | F10=Exit", 0x55FFFF);
        draw_string(4, 18, "================================================================", 0x444444);

        if (!editing)
        {
            draw_string(4, 32, "File not found. Only 'config' is editable.", 0xFF4444);
            fb_present();
            unsigned char sc;
            read_key_raw(&sc);
            if (sc == SC_F10) return;
            continue;
        }

        /* نمایش فایل config */
        for (int i = 0; i < CFG_LINES; i++)
        {
            uint32_t color = (i == cur_line) ? 0xFFFF55 : 0xCCCCCC;
            char line_num[4];
            line_num[0] = '0' + (i / 10);
            line_num[1] = '0' + (i % 10);
            line_num[2] = ' ';
            line_num[3] = 0;

            if (i == cur_line)
                draw_rect(fb, 0, 32 + i * 14, fb->width, 14, 0x1A1A2E);

            draw_string(4, 32 + i * 14, line_num, 0x555555);
            draw_string(28, 32 + i * 14, cfg[i], color);

            /* cursor */
            if (i == cur_line)
            {
                int cx = 28 + cur_pos * 8;
                draw_rect(fb, cx, 32 + i * 14, 2, 12, 0xFFFFFF);
            }
        }

        int help_y = 32 + CFG_LINES * 14 + 8;
        draw_string(4, help_y, "================================================================", 0x444444);
        draw_string(4, help_y + 14, "Up/Down=select line | Left/Right=move | F5=apply | F10=exit", 0x888888);
        draw_string(4, help_y + 28, "Type to edit. Backspace to delete.", 0x888888);

        fb_present();

        /* خوندن کلید */
        unsigned char sc;
        char c = read_key_raw(&sc);

        if (sc == SC_F5)
        {
            apply_config();
            /* پیام تأیید */
            draw_string(4, help_y + 42, "Saved & Applied to desktop!", 0x33FF66);
            fb_present();
            bs_delay();
            continue;
        }

        if (sc == SC_F10) return;

        if (sc == SC_UP)
        {
            if (cur_line > 0) cur_line--;
            /* cur_pos رو تنظیم کن */
            int len = 0;
            while (cfg[cur_line][len]) len++;
            if (cur_pos > len) cur_pos = len;
            continue;
        }

        if (sc == SC_DOWN)
        {
            if (cur_line < CFG_LINES - 1) cur_line++;
            int len = 0;
            while (cfg[cur_line][len]) len++;
            if (cur_pos > len) cur_pos = len;
            continue;
        }

        if (sc == SC_LEFT)
        {
            if (cur_pos > 0) cur_pos--;
            continue;
        }

        if (sc == SC_RIGHT)
        {
            int len = 0;
            while (cfg[cur_line][len]) len++;
            if (cur_pos < len) cur_pos++;
            continue;
        }

        if (c == '\b')
        {
            if (cur_pos > 0)
            {
                int len = 0;
                while (cfg[cur_line][len]) len++;
                for (int i = cur_pos - 1; i < len - 1; i++)
                    cfg[cur_line][i] = cfg[cur_line][i + 1];
                cfg[cur_line][len - 1] = 0;
                cur_pos--;
            }
            continue;
        }

        if (c >= 32 && c < 127)
        {
            int len = 0;
            while (cfg[cur_line][len]) len++;
            if (len < CFG_LINE_LEN - 1)
            {
                for (int i = len; i >= cur_pos; i--)
                    cfg[cur_line][i + 1] = cfg[cur_line][i];
                cfg[cur_line][cur_pos] = c;
                cur_pos++;
            }
            continue;
        }
    }
}

/* ========== Shell ========== */
static void sh_scroll(void)
{
    for (int r=1;r<SH_ROWS;r++)
        for (int c=0;c<SH_COLS;c++)
            sh_screen[r-1][c]=sh_screen[r][c];
    for (int c=0;c<SH_COLS;c++) sh_screen[SH_ROWS-1][c]=0;
    sh_row=SH_ROWS-1;
}

static void sh_newline(void)
{
    sh_col=0; sh_row++;
    if(sh_row>=SH_ROWS) sh_scroll();
}

static void sh_print(const char *s)
{
    while(*s){
        if(*s=='\n'){sh_newline();}
        else{
            if(sh_col>=SH_COLS) sh_newline();
            if(sh_row>=SH_ROWS) sh_scroll();
            sh_screen[sh_row][sh_col++]=*s;
        }
        s++;
    }
}

static void sh_render(void)
{
    Framebuffer *fb = get_fb();
    clear_screen(fb, 0x000000);
    for (int r=0;r<SH_ROWS;r++){
        char line[SH_COLS+1];
        for(int c=0;c<SH_COLS;c++){
            char ch=sh_screen[r][c];
            line[c]=ch?ch:' ';
        }
        line[SH_COLS]=0;
        uint32_t color=sh_text_color;
        if(line[0]=='['&&line[1]==' ') color=0x888888;
        else if(line[0]=='='&&line[1]=='=') color=0x55FFFF;
        else if(line[0]==' '&&line[1]==' ') color=0x33FF66;
        draw_string(4, 4+r*13, line, color);
    }
    fb_present();
}

static int sh_eq(const char *a,const char *b)
{
    while(*a&&*b){if(*a!=*b)return 0;a++;b++;}
    return *a==*b;
}

static int sh_starts(const char *s,const char *p)
{
    while(*p){if(*s!=*p)return 0;s++;p++;}
    return 1;
}

static void sh_run_cmd(const char *cmd)
{
    if(cmd[0]==0) return;

    if(!sh_logged_in){
        if(sh_eq(cmd,"login to SovereignX")||sh_eq(cmd,"login")||sh_eq(cmd,"sovereignx")){
            sh_print("Authenticating...\n");
            sh_render(); bs_delay();
            sh_print("Welcome to SovereignX!\n");
            sh_print("Type 'help' for commands.\n");
            sh_logged_in=1;
            return;
        }
        sh_print("Type 'login to SovereignX' to login.\n");
        return;
    }

    if(sh_eq(cmd,"help")){
        sh_print("=== SovereignX Boot Shell ===\n");
        sh_print("  editor config  - edit desktop config\n");
        sh_print("  editor list    - show editable files\n");
        sh_print("  apply          - apply config to desktop\n");
        sh_print("  show config    - show current config\n");
        sh_print("  uname / uname -a\n");
        sh_print("  mem / cpu / net / disk\n");
        sh_print("  ps / ls\n");
        sh_print("  color <name>   - green/cyan/white/yellow/red\n");
        sh_print("  clear\n");
        sh_print("  desktop        - go to desktop\n");
        sh_print("  reboot\n");
        return;
    }

    if(sh_starts(cmd,"editor ")){
        const char *fname = cmd+7;
        run_editor(fname);
        /* بعد از Editor، shell رو دوباره رندر کن */
        sh_render();
        return;
    }

    if(sh_eq(cmd,"editor list")||sh_eq(cmd,"ls")){
        sh_print("Editable files:\n");
        sh_print("  config       - desktop colors & settings\n");
        sh_print("\nSystem files (read-only summary):\n");
        sh_print("  desktop.c    kernel/gui/desktop.c\n");
        sh_print("  icons.c      kernel/gui/icons.c\n");
        sh_print("  taskbar.c    kernel/gui/taskbar.c\n");
        sh_print("  background.c kernel/gui/background.c\n");
        sh_print("  keyboard.c   kernel/drivers/keyboard.c\n");
        sh_print("  terminal.c   kernel/apps/terminal_key.c\n");
        return;
    }

    if(sh_eq(cmd,"apply")){
        apply_config();
        sh_print("Config applied to desktop!\n");
        return;
    }

    if(sh_eq(cmd,"show config")){
        sh_print("=== Current Config ===\n");
        for(int i=0;i<CFG_LINES;i++){
            sh_print("  ");
            sh_print(cfg[i]);
            sh_print("\n");
        }
        return;
    }

    if(sh_eq(cmd,"uname")){sh_print("SovereignX\n");return;}
    if(sh_eq(cmd,"uname -a")){
        sh_print("SovereignX 0.6-RELEASE #1 SMP amd64\n");
        sh_print("Compiler: clang --target=x86_64-elf\n");
        sh_print("Boot: Limine BIOS+UEFI\n");
        return;
    }
    if(sh_eq(cmd,"mem")){
        sh_print("Total: 512MB  Used: 48MB  Free: 464MB\n");
        return;
    }
    if(sh_eq(cmd,"cpu")){
        sh_print("Arch: x86_64  Mode: 64-bit  QEMU\n");
        return;
    }
    if(sh_eq(cmd,"net")){
        sh_print("eth0: 10.0.2.15/24  GW:10.0.2.2  DNS:10.0.2.3\n");
        sh_print("MAC: 52:54:00:12:34:56  Status: UP 1000Mbps\n");
        return;
    }
    if(sh_eq(cmd,"disk")){
        sh_print("ATA 512MB  RFS filesystem  32 file slots\n");
        return;
    }
    if(sh_eq(cmd,"ps")){
        sh_print("PID  NAME\n");
        sh_print("  1  kernel\n");
        sh_print("  2  desktop\n");
        sh_print("  3  terminal\n");
        sh_print("  4  boot_shell\n");
        return;
    }
    if(sh_eq(cmd,"clear")){
        for(int r=0;r<SH_ROWS;r++)
            for(int c=0;c<SH_COLS;c++)
                sh_screen[r][c]=0;
        sh_row=0; sh_col=0;
        return;
    }
    if(sh_starts(cmd,"color ")){
        const char *n=cmd+6;
        if(sh_eq(n,"green")) {sh_text_color=0x33FF66;}
        else if(sh_eq(n,"cyan")) {sh_text_color=0x55FFFF;}
        else if(sh_eq(n,"white")) {sh_text_color=0xFFFFFF;}
        else if(sh_eq(n,"yellow")) {sh_text_color=0xFFFF55;}
        else if(sh_eq(n,"red")) {sh_text_color=0xFF4444;}
        else if(sh_eq(n,"blue")) {sh_text_color=0x4A6FE8;}
        else {sh_print("Colors: green cyan white yellow red blue\n");return;}
        sh_print("Color changed.\n");
        return;
    }
    if(sh_eq(cmd,"desktop")||sh_eq(cmd,"exit")){
        sh_print("Going to SovereignX Desktop...\n");
        sh_render(); bs_delay();
        sh_active=0;
        return;
    }
    if(sh_eq(cmd,"reboot")){
        sh_print("Rebooting...\n");
        sh_render(); bs_delay();
        sh_active=0;
        return;
    }

    sh_print("Unknown: ");
    sh_print(cmd);
    sh_print("\nType 'help'\n");
}

static void sh_show_prompt(void)
{
    if(sh_logged_in) sh_print("root@sovereignx:~# ");
    else sh_print("SovereignX login: ");
}

static void sh_run_shell(void)
{
    sh_active=1;
    sh_show_prompt();
    sh_render();

    while(sh_active){
        unsigned char sc;
        char c=read_key_raw(&sc);

        if(c=='\n'){
            sh_cmd[sh_cmd_len]=0;
            sh_newline();
            sh_run_cmd(sh_cmd);
            sh_cmd_len=0;
            if(sh_active) sh_show_prompt();
            sh_render();
            continue;
        }
        if(c=='\b'){
            if(sh_cmd_len>0){
                sh_cmd_len--;
                if(sh_col>0){sh_col--;sh_screen[sh_row][sh_col]=0;}
                sh_render();
            }
            continue;
        }
        if(c>=32&&c<127&&sh_cmd_len<SH_CMD-1){
            sh_cmd[sh_cmd_len++]=c;
            if(sh_col>=SH_COLS) sh_newline();
            sh_screen[sh_row][sh_col++]=c;
            sh_render();
        }
    }
}

/* ========== boot_screen_run ========== */
void boot_screen_run(void)
{
    Framebuffer *fb = get_fb();
    clear_screen(fb, 0x000000);
    fb_present();
    bs_delay();

    for(int r=0;r<SH_ROWS;r++)
        for(int c=0;c<SH_COLS;c++)
            sh_screen[r][c]=0;
    sh_row=0; sh_col=0; sh_cmd_len=0;
    sh_logged_in=0; sh_text_color=0x33FF66;

    int x=4, y=20;
    draw_string(x,y,"  ____                          _           __  __",0x55FFFF);y+=14;
    draw_string(x,y," / ___|  _____   _____ _ __ ___(_) __ _ _ _\\ \\/ /",0x55FFFF);y+=14;
    draw_string(x,y," \\___ \\ / _ \\ \\ / / _ \\ '__/ _ \\ |/ _` | '_ \\  / ",0x4AE0E8);y+=14;
    draw_string(x,y,"  ___) | (_) \\ V /  __/ | |  __/ | (_| | | | /  \\",0x4AE0E8);y+=14;
    draw_string(x,y," |____/ \\___/ \\_/ \\___|_|  \\___|_|\\__, |_| |/_/\\_\\",0x3388FF);y+=14;
    draw_string(x,y,"                                    |___/           ",0x3388FF);y+=20;
    fb_present(); bs_delay();

    draw_string(x,y,"================================================================",0x444444);y+=14;
    draw_string(x,y,"  SovereignX OS  v0.6-RELEASE  |  amd64  |  Limine Boot",0xFFFFFF);y+=14;
    draw_string(x,y,"  Copyright (C) 2024-2026 Amir & SovereignX Project",0x888888);y+=14;
    draw_string(x,y,"================================================================",0x444444);y+=18;
    fb_present(); bs_delay();

    draw_string(x,y,"  Log in to SovereignX",0x33FF66);y+=20;
    fb_present(); bs_delay();

    const char *logs[]={
        "[    0.000000] SovereignX kernel 0.6 starting...",
        "[    0.000034] Framebuffer: 1024x768 32bpp OK",
        "[    0.000234] PCI: Intel e1000 NIC found",
        "[    0.000434] IPv4: 10.0.2.15/24 gateway 10.0.2.2",
        "[    0.000634] RFS filesystem: superblock valid",
        "[    0.000801] GUI subsystem: ready",
        "[    0.001034] All subsystems: nominal",
        "[    0.001067] Starting SovereignX...",
        "","  SovereignX is ready.",
    };
    int count=sizeof(logs)/sizeof(logs[0]);
    for(int i=0;i<count;i++){
        if(y>(int)fb->height-20){clear_screen(fb,0x000000);y=20;}
        const char *l=logs[i];
        if(l[0]==0){y+=8;continue;}
        uint32_t color=0xCCCCCC;
        if(l[0]==' '&&l[1]==' ') color=0x33FF66;
        else if(l[0]=='[') color=0x888888;
        draw_string(x,y,l,color);
        y+=13; fb_present(); bs_short();
    }
    bs_delay(); bs_delay();

    clear_screen(fb,0x000000); fb_present();
    sh_print("SovereignX Boot Shell\n");
    sh_print("Type 'login to SovereignX' to login\n");
    sh_print("After login: type 'editor config' to edit desktop\n\n");
    sh_run_shell();
}
