#include "terminal_commands.h"
#include "games.h"

#define MAX_NAME 32
#define MAX_INSTALLED 8

static char current_name[MAX_NAME];
static int active = 0;
static int secret = 0;
static int attempts = 0;
static int pending_save = 0;

static char installed_names[MAX_INSTALLED][MAX_NAME];
static int installed_count = 0;

static unsigned int rng_state = 12345;

static unsigned int next_rand(unsigned int max)
{
    rng_state = rng_state * 1103515245u + 12345u;
    unsigned int val = (rng_state >> 16) & 0x7FFF;
    return (val % max) + 1;
}

static void copy_name(char *dst, const char *src)
{
    int i = 0;
    while (src[i] && i < MAX_NAME - 1) { dst[i] = src[i]; i++; }
    dst[i] = 0;
}

static void int_to_str_local(int val, char *out)
{
    char tmp[16];
    int i = 0;
    if (val == 0) tmp[i++] = '0';
    while (val > 0) { tmp[i++] = '0' + (val % 10); val /= 10; }
    int j = 0;
    while (i > 0) out[j++] = tmp[--i];
    out[j] = 0;
}

void game_start(const char *name)
{
    copy_name(current_name, name);
    secret = next_rand(100);
    attempts = 0;
    active = 1;
    pending_save = 0;

    terminal_print("=== ");
    terminal_print(current_name);
    terminal_print(" ===\n");
    terminal_print("I'm thinking of a number between 1 and 100.\n");
    terminal_print("Type: guess <number>\n");
}

void app_create(const char *name)
{
    copy_name(current_name, name);
    active = 0;
    pending_save = 1;

    terminal_print("=== ");
    terminal_print(current_name);
    terminal_print(" ===\n");
    terminal_print("App created.\n");
    terminal_print("Save '");
    terminal_print(current_name);
    terminal_print("' to your desktop? (y/n)\n");
}

int game_is_active(void) { return active; }
int game_pending_save(void) { return pending_save; }

void game_guess(int value)
{
    if (!active) return;
    attempts++;

    if (value < secret)
    {
        terminal_print("Higher!\n");
    }
    else if (value > secret)
    {
        terminal_print("Lower!\n");
    }
    else
    {
        char buf[8];
        terminal_print("Correct! You got it in ");
        int_to_str_local(attempts, buf);
        terminal_print(buf);
        terminal_print(" tries.\n");
        active = 0;
        pending_save = 1;
        terminal_print("Save '");
        terminal_print(current_name);
        terminal_print("' to your desktop? (y/n)\n");
    }
}

void game_confirm_save(int yes)
{
    pending_save = 0;
    if (yes)
    {
        if (installed_count < MAX_INSTALLED)
        {
            copy_name(installed_names[installed_count], current_name);
            installed_count++;
            terminal_print("Saved to desktop!\n");
        }
        else
        {
            terminal_print("Desktop slots full (max 8).\n");
        }
    }
    else
    {
        terminal_print("Closed without saving.\n");
    }
}

int game_installed_count(void) { return installed_count; }

const char *game_installed_name(int index)
{
    if (index < 0 || index >= installed_count) return "";
    return installed_names[index];
}

void game_replay_installed(int index)
{
    if (index < 0 || index >= installed_count) return;
    game_start(installed_names[index]);
}
