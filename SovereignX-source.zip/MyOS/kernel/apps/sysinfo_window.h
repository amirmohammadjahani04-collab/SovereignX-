#ifndef SYSINFO_WINDOW_H
#define SYSINFO_WINDOW_H

void sysinfo_window_draw(void);

#endif
