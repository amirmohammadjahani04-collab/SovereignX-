#ifndef SETTINGS_H
#define SETTINGS_H

void settings_init();
void settings_show();

#endif
