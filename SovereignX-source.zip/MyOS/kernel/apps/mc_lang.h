#ifndef MC_LANG_H
#define MC_LANG_H

void mc_run_script(const char *script);
void mc_run_script_from_vfs(const char *filename);
void mc_run_script_to_buffer(const char *script, char *out, int max_len);

#endif
