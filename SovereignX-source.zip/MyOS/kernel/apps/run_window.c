#include "run_window.h"
#include "../gui/wm.h"
#include "../gui/desktop.h"
#include "../fb.h"
#include "../graphics.h"
#include "../text_render.h"
#include "../reboot.h"
#include "terminal.h"
#include "dev_shell.h"
#include "boot_screen.h"
#include "boot_config.h"

#define RW_X 160
#define RW_Y 180
#define RW_W 420
#define RW_H 250

static int active = 0;
static char input[64];
static int input_len = 0;
static char status[64] = "";

static int rw_str_eq(const char *a, const char *b)
{
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static void set_status(const char *s)
{
    int i = 0;
    while (s[i] && i < 63) { status[i] = s[i]; i++; }
    status[i] = 0;
}

static void run_command(void)
{
    if (rw_str_eq(input, "terminal") || rw_str_eq(input, "Terminal"))
    {
        run_window_close();
        desktop_open_terminal();
        desktop_redraw();
        return;
    }

    if (rw_str_eq(input, "reboot") || rw_str_eq(input, "Reboot"))
    {
        run_window_close();
        system_reboot();
        return;
    }

    if (rw_str_eq(input, "reset") || rw_str_eq(input, "Reset"))
    {
        run_window_close();
        boot_screen_run();
        desktop_emergency_reset();
        desktop_redraw();
        return;
    }

    if (rw_str_eq(input, "shell boot") || rw_str_eq(input, "Shell boot"))
    {
        run_window_close();
        dev_shell_open();
        desktop_redraw();
        return;
    }

    if (rw_str_eq(input, "bootscreen") || rw_str_eq(input, "Boot Screen") || rw_str_eq(input, "bootconfig"))
    {
        run_window_close();
        boot_config_run();
        desktop_redraw();
        return;
    }

    set_status("Unknown command.");
}

void run_window_open(void)
{
    active = 1;
    input_len = 0;
    input[0] = 0;
    status[0] = 0;
}

void run_window_close(void)
{
    active = 0;
    input_len = 0;
    input[0] = 0;
    status[0] = 0;
}

int run_window_is_open(void) { return active; }

void run_window_key(char c)
{
    if (!active) return;

    if (c == '\n')
    {
        run_command();
        return;
    }

    if (c == '\b')
    {
        if (input_len > 0)
        {
            input_len--;
            input[input_len] = 0;
        }
        return;
    }

    if (input_len < 63 && c >= 32 && c < 127)
    {
        input[input_len++] = c;
        input[input_len] = 0;
    }
}

void run_window_draw(void)
{
    if (!active) return;

    Framebuffer *fb = get_fb();

    wm_draw_window(RW_X, RW_Y, RW_W, RW_H, "Run - SovereignX");

    draw_string(RW_X + 20, RW_Y + 40, "Type a command and press Enter:", 0xAAAAAA);

    draw_rect(fb, RW_X + 16, RW_Y + 62, RW_W - 32, 28, 0x0D1117);
    draw_rect(fb, RW_X + 16, RW_Y + 62, RW_W - 32, 1, 0x55FFFF);
    draw_rect(fb, RW_X + 16, RW_Y + 89, RW_W - 32, 1, 0x55FFFF);
    draw_rect(fb, RW_X + 16, RW_Y + 62, 1, 28, 0x55FFFF);
    draw_rect(fb, RW_X + RW_W - 17, RW_Y + 62, 1, 28, 0x55FFFF);

    draw_string(RW_X + 24, RW_Y + 70, input, 0xFFFFFF);

    int cursor_x = RW_X + 24 + input_len * 8;
    draw_rect(fb, cursor_x, RW_Y + 70, 2, 12, 0x55FFFF);

    draw_string(RW_X + 20, RW_Y + 102, "Commands:", 0x55FFFF);
    draw_string(RW_X + 20, RW_Y + 116, "  terminal   - open terminal", 0xCCCCCC);
    draw_string(RW_X + 20, RW_Y + 130, "  reboot     - restart system", 0xCCCCCC);
    draw_string(RW_X + 20, RW_Y + 144, "  reset      - boot screen + reset", 0xCCCCCC);
    draw_string(RW_X + 20, RW_Y + 158, "  shell boot - open dev shell", 0xCCCCCC);
    draw_string(RW_X + 20, RW_Y + 172, "  bootscreen - boot config screen", 0x55FF55);

    if (status[0])
        draw_string(RW_X + 20, RW_Y + 210, status, 0xFF4444);

    fb_present();
}
