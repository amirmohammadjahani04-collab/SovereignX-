#include "terminal.h"


static volatile unsigned short *vga =
    (unsigned short*)0xb8000;


void terminal_init()
{
}


void terminal_run()
{
    char *msg =
        "SovereignX Terminal>";

    for(int i=0; msg[i]; i++)
    {
        vga[600+i] =
            msg[i] | 0x0700;
    }
}
