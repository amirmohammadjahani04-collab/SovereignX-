#ifndef TERMINAL_H
#define TERMINAL_H

#define TERMINAL_COLS 60
#define TERMINAL_ROWS 20

void terminal_init(void);
void terminal_key(char c);
char terminal_get_char(int row, int col);
int terminal_get_cursor_row(void);
int terminal_get_cursor_col(void);

#endif
