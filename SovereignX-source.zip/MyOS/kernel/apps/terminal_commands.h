#ifndef TERMINAL_COMMANDS_H
#define TERMINAL_COMMANDS_H

int terminal_handle_system_command(const char *cmd);
void terminal_print(const char *s);
int vfs_write_file(const char *name, const char *content);
int vfs_read_file(const char *name, char *out, int max_len);
int vfs_file_count(void);
const char *vfs_file_name_at(int index);

#endif
