#ifndef SOURCE_SHELL_H
#define SOURCE_SHELL_H

void source_shell_open(void);
int source_shell_is_active(void);
void source_shell_key(char c);
void source_shell_window_draw(void);

#endif
