#include "embedded_source.h"

static int str_eq(const char *a, const char *b)
{
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static const char *src_reboot_h =
"#ifndef REBOOT_H\n"
"#define REBOOT_H\n"
"\n"
"void system_reboot(void);\n"
"\n"
"#endif\n";

static const char *src_reboot_c =
"#include \"reboot.h\"\n"
"#include <stdint.h>\n"
"\n"
"static inline void outb(uint16_t port, uint8_t val)\n"
"{\n"
"    asm volatile (\"outb %0, %1\" : : \"a\"(val), \"Nd\"(port));\n"
"}\n"
"\n"
"static inline uint8_t inb(uint16_t port)\n"
"{\n"
"    uint8_t ret;\n"
"    asm volatile (\"inb %1, %0\" : \"=a\"(ret) : \"Nd\"(port));\n"
"    return ret;\n"
"}\n"
"\n"
"void system_reboot(void)\n"
"{\n"
"    uint8_t status;\n"
"    do {\n"
"        status = inb(0x64);\n"
"    } while (status & 0x02);\n"
"\n"
"    outb(0x64, 0xFE);\n"
"\n"
"    for (;;)\n"
"    {\n"
"        asm volatile (\"hlt\");\n"
"    }\n"
"}\n";

typedef struct {
    const char *name;
    const char *content;
} SourceEntry;

static const SourceEntry sources[] = {
    { "reboot.h", 0 },
    { "reboot.c", 0 },
};
#define SOURCE_COUNT (sizeof(sources) / sizeof(sources[0]))

int source_file_count(void)
{
    return SOURCE_COUNT;
}

const char *source_file_name(int index)
{
    if (index < 0 || index >= (int)SOURCE_COUNT) return "";
    return sources[index].name;
}

const char *source_file_content(const char *name)
{
    if (str_eq(name, "reboot.h")) return src_reboot_h;
    if (str_eq(name, "reboot.c")) return src_reboot_c;
    return "";
}
