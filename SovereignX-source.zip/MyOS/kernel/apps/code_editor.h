#ifndef CODE_EDITOR_H
#define CODE_EDITOR_H

void editor_open(const char *name, int is_game);
void editor_open_existing(const char *name, int is_game);
void editor_open_studio(void);
int editor_is_active(void);
void editor_key(char c);
void editor_run(void);
void editor_exit(void);
void editor_window_draw(void);
void editor_handle_click(int mx, int my);

#endif
