#include "../gui/desktop.h"
#include "../gui/background.h"
#include "../gui/custom_icons.h"
#include "../gui/keybind.h"
#include "../text_render.h"
#include "../network/arp.h"
#include "../network/icmp.h"
#include "../network/tcp.h"
#include "../installer.h"
#include "../reboot.h"
#include "../drivers/disk/ata.h"
#include "../fs/rfs.h"
#include "http_client.h"
#include "terminal_commands.h"
#include "mc_lang.h"
#include "games.h"
#include "pkg_manager.h"

static int str_eq(const char *a, const char *b)
{
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static int str_starts_with(const char *s, const char *prefix)
{
    while (*prefix) { if (*s != *prefix) return 0; s++; prefix++; }
    return 1;
}

static uint32_t hex_to_uint(const char *s)
{
    uint32_t result = 0;
    while (*s)
    {
        char c = *s;
        uint32_t val;
        if (c >= '0' && c <= '9') val = c - '0';
        else if (c >= 'a' && c <= 'f') val = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') val = c - 'A' + 10;
        else break;
        result = (result << 4) | val;
        s++;
    }
    return result;
}

static void int_to_str(int val, char *out)
{
    char tmp[16];
    int i = 0;
    int neg = 0;
    if (val < 0) { neg = 1; val = -val; }
    if (val == 0) tmp[i++] = '0';
    while (val > 0) { tmp[i++] = '0' + (val % 10); val /= 10; }
    int j = 0;
    if (neg) out[j++] = '-';
    while (i > 0) out[j++] = tmp[--i];
    out[j] = 0;
}

typedef struct { const char *name; uint32_t hex; } ColorEntry;

static const ColorEntry color_table[] = {
    {"red",     0xE84A4A}, {"green",   0x4AE86F}, {"blue",    0x4A6FE8},
    {"yellow",  0xE8D84A}, {"orange",  0xE8B84A}, {"purple",  0x8A4AE8},
    {"pink",    0xE84AC0}, {"cyan",    0x4AE0E8}, {"teal",    0x0D3B3E},
    {"black",   0x000000}, {"white",   0xFFFFFF}, {"gray",    0x808080},
    {"darkgray",0x2B2B2B}, {"lightgray",0xC0C0C0},{"navy",    0x1C2733},
    {"maroon",  0x7A1F1F}, {"lime",    0x32E832}, {"olive",   0x7A7A1F},
    {"brown",   0x5C3A21}, {"gold",    0xE8C04A}, {"silver",  0xB8B8B8},
    {"indigo",  0x4B0082}, {"violet",  0xB84AE8}, {"magenta", 0xE84AE8},
    {"turquoise",0x4AE8C0},{"coral",   0xE86F4A}, {"salmon",  0xE87A6F},
    {"crimson", 0xB8203A}, {"beige",   0xE8DCC0}, {"chocolate",0x9C5A2E},
};
#define COLOR_COUNT (sizeof(color_table) / sizeof(ColorEntry))

#define MAX_FILES 32
#define MAX_NAME 32
#define MAX_CONTENT 256

typedef struct {
    char name[MAX_NAME];
    char content[MAX_CONTENT];
    int used;
    int system;
} VFile;

static VFile vfs[MAX_FILES];

static VFile *vfs_find(const char *name)
{
    for (int i = 0; i < MAX_FILES; i++)
        if (vfs[i].used && str_eq(vfs[i].name, name))
            return &vfs[i];
    return 0;
}

static VFile *vfs_alloc(const char *name)
{
    for (int i = 0; i < MAX_FILES; i++)
    {
        if (!vfs[i].used)
        {
            int j = 0;
            while (name[j] && j < MAX_NAME - 1) { vfs[i].name[j] = name[j]; j++; }
            vfs[i].name[j] = 0;
            vfs[i].content[0] = 0;
            vfs[i].used = 1;
            vfs[i].system = str_starts_with(name, "sys/") ? 1 : 0;
            return &vfs[i];
        }
    }
    return 0;
}

static int decode_newlines(const char *in, char *out, int max_len)
{
    int i = 0, j = 0;
    while (in[i] && j < max_len - 1)
    {
        if (in[i] == '\\' && in[i + 1] == 'n')
        {
            out[j++] = '\n';
            i += 2;
        }
        else
        {
            out[j++] = in[i++];
        }
    }
    out[j] = 0;
    return j;
}

int vfs_write_file(const char *name, const char *content)
{
    VFile *f = vfs_find(name);
    if (!f) f = vfs_alloc(name);
    if (!f) return 0;

    int i = 0;
    while (content[i] && i < MAX_CONTENT - 1) { f->content[i] = content[i]; i++; }
    f->content[i] = 0;
    return 1;
}

int vfs_read_file(const char *name, char *out, int max_len)
{
    VFile *f = vfs_find(name);
    if (!f) { out[0] = 0; return 0; }

    int i = 0;
    while (f->content[i] && i < max_len - 1) { out[i] = f->content[i]; i++; }
    out[i] = 0;
    return 1;
}

int vfs_file_count(void)
{
    int c = 0;
    for (int i = 0; i < MAX_FILES; i++)
        if (vfs[i].used) c++;
    return c;
}

const char *vfs_file_name_at(int index)
{
    int c = 0;
    for (int i = 0; i < MAX_FILES; i++)
    {
        if (vfs[i].used)
        {
            if (c == index) return vfs[i].name;
            c++;
        }
    }
    return "";
}

static int handle_disk_commands(const char *cmd)
{
    if (str_eq(cmd, "disktest"))
    {
        uint8_t write_buf[512];
        uint8_t read_buf[512];

        const char *msg = "SovereignX disk test OK";
        int i = 0;
        while (msg[i] && i < 512) { write_buf[i] = msg[i]; i++; }
        while (i < 512) { write_buf[i] = 0; i++; }

        uint32_t test_lba = 50000;

        terminal_print("Writing to sector 50000...\n");
        ata_write_sector(test_lba, write_buf);

        terminal_print("Reading back sector 50000...\n");
        ata_read_sector(test_lba, read_buf);

        int match = 1;
        for (int j = 0; j < 512; j++)
        {
            if (write_buf[j] != read_buf[j]) { match = 0; break; }
        }

        if (match)
        {
            terminal_print("Disk test PASSED: ");
            terminal_print((char *)read_buf);
            terminal_print("\n");
        }
        else
        {
            terminal_print("Disk test FAILED: data mismatch.\n");
        }

        return 1;
    }

    if (str_starts_with(cmd, "dwrite "))
    {
        const char *rest = cmd + 7;
        char fname[32];
        int i = 0;
        while (rest[i] != 0 && rest[i] != ' ' && i < 31)
        {
            fname[i] = rest[i];
            i++;
        }
        fname[i] = 0;
        const char *text = (rest[i] == ' ') ? rest + i + 1 : "";

        if (rfs_write_file(fname, text))
            terminal_print("Written to disk.\n");
        else
            terminal_print("No space left on disk filesystem.\n");
        return 1;
    }

    if (str_starts_with(cmd, "dcat "))
    {
        char buf[256];
        if (rfs_read_file(cmd + 5, buf, 256))
        {
            terminal_print(buf);
            terminal_print("\n");
        }
        else
        {
            terminal_print("File not found on disk.\n");
        }
        return 1;
    }

    if (str_eq(cmd, "dls"))
    {
        int count = rfs_file_count();
        if (count == 0)
        {
            terminal_print("(disk filesystem empty)\n");
        }
        else
        {
            for (int i = 0; i < count; i++)
            {
                terminal_print(rfs_file_name(i));
                terminal_print("\n");
            }
        }
        return 1;
    }

    if (str_starts_with(cmd, "drm "))
    {
        if (rfs_delete_file(cmd + 4))
            terminal_print("Removed from disk.\n");
        else
            terminal_print("File not found on disk.\n");
        return 1;
    }

    return 0;
}

static int handle_color_commands(const char *cmd)
{
    if (str_starts_with(cmd, "bgcolor "))
    {
        background_set_color(hex_to_uint(cmd + 8));
        return 1;
    }
    if (str_starts_with(cmd, "color desktop "))
    {
        const char *name = cmd + 14;
        for (unsigned i = 0; i < COLOR_COUNT; i++)
        {
            if (str_eq(name, color_table[i].name))
            {
                background_set_color(color_table[i].hex);
                terminal_print("Desktop color set to ");
                terminal_print(name);
                terminal_print("\n");
                return 1;
            }
        }
        terminal_print("Unknown color name.\n");
        return 1;
    }
    if (str_starts_with(cmd, "color "))
    {
        const char *name = cmd + 6;
        for (unsigned i = 0; i < COLOR_COUNT; i++)
        {
            if (str_eq(name, color_table[i].name))
            {
                background_set_color(color_table[i].hex);
                return 1;
            }
        }
        terminal_print("Unknown color name.\n");
        return 1;
    }
    if (str_eq(cmd, "bgreset"))
    {
        background_reset();
        return 1;
    }
    if (str_eq(cmd, "colors"))
    {
        terminal_print("Available colors:\n");
        for (unsigned i = 0; i < COLOR_COUNT; i++)
        {
            terminal_print(color_table[i].name);
            terminal_print(" ");
        }
        terminal_print("\n");
        return 1;
    }
    return 0;
}

static int handle_window_commands(const char *cmd)
{
    if (str_eq(cmd, "open files"))    { desktop_open_files(); return 1; }
    if (str_eq(cmd, "reboot"))        { system_reboot(); return 1; }
    if (str_eq(cmd, "open settings")) { desktop_open_settings(); return 1; }
    if (str_eq(cmd, "open terminal")) { desktop_open_terminal(); return 1; }
    if (str_eq(cmd, "shutdown"))      { desktop_trigger_shutdown(); return 1; }
    if (str_eq(cmd, "halt"))          { desktop_trigger_shutdown(); return 1; }
    if (str_eq(cmd, "poweroff"))      { desktop_trigger_shutdown(); return 1; }
    return 0;
}

static int handle_info_commands(const char *cmd)
{
    if (str_eq(cmd, "sysinfo"))
    {
        terminal_print("SovereignX x86_64 - custom hobby kernel\n");
        terminal_print("Build: Limine bootloader, BIOS+UEFI hybrid\n");
        return 1;
    }
    if (str_eq(cmd, "version"))
    {
        terminal_print("SovereignX v0.6\n");
        return 1;
    }
    if (str_eq(cmd, "changelog"))
    {
        terminal_print("SovereignX v0.6 changelog:\n");
        terminal_print("- Mouse hover + Enter opens icons\n");
        terminal_print("- File manager now uses fast in-memory VFS\n");
        terminal_print("- Custom keybinds: bind game/app <name> <key>\n");
        terminal_print("- Win+F/G/C/P file shortcuts\n");
        terminal_print("- network command\n");
        return 1;
    }
    if (str_eq(cmd, "uptime"))
    {
        terminal_print("Uptime tracking not implemented yet.\n");
        return 1;
    }
    if (str_eq(cmd, "whoami"))
    {
        terminal_print(installer_get_username());
        terminal_print("\n");
        return 1;
    }
    return 0;
}

static int handle_math_commands(const char *cmd)
{
    if (str_starts_with(cmd, "add "))
    {
        int a = 0, b = 0, idx = 4, val = 0, part = 0;
        char c;
        while ((c = cmd[idx]) != 0)
        {
            if (c == ' ') { if (part == 0) { a = val; val = 0; part = 1; } idx++; continue; }
            val = val * 10 + (c - '0');
            idx++;
        }
        b = val;
        char out[16];
        int_to_str(a + b, out);
        terminal_print("= ");
        terminal_print(out);
        terminal_print("\n");
        return 1;
    }
    if (str_starts_with(cmd, "sub "))
    {
        int a = 0, val = 0, part = 0, idx = 4;
        char c;
        while ((c = cmd[idx]) != 0)
        {
            if (c == ' ') { if (part == 0) { a = val; val = 0; part = 1; } idx++; continue; }
            val = val * 10 + (c - '0');
            idx++;
        }
        char out[16];
        int_to_str(a - val, out);
        terminal_print("= ");
        terminal_print(out);
        terminal_print("\n");
        return 1;
    }
    return 0;
}

static int handle_vfs_commands(const char *cmd)
{
    if (str_starts_with(cmd, "touch "))
    {
        const char *name = cmd + 6;
        if (vfs_find(name)) { terminal_print("File already exists.\n"); return 1; }
        if (vfs_alloc(name))
        {
            if (str_starts_with(name, "sys/"))
                terminal_print("System file created (protected).\n");
            else
                terminal_print("File created.\n");
        }
        else terminal_print("No space left.\n");
        return 1;
    }
    if (str_eq(cmd, "ls"))
    {
        int any = 0;
        for (int i = 0; i < MAX_FILES; i++)
        {
            if (vfs[i].used)
            {
                terminal_print(vfs[i].name);
                if (vfs[i].system) terminal_print(" [SYS]");
                terminal_print("\n");
                any = 1;
            }
        }
        if (!any) terminal_print("(empty)\n");
        return 1;
    }
    if (str_starts_with(cmd, "cat "))
    {
        VFile *f = vfs_find(cmd + 4);
        if (!f) terminal_print("File not found.\n");
        else { terminal_print(f->content); terminal_print("\n"); }
        return 1;
    }
    if (str_starts_with(cmd, "rm "))
    {
        VFile *f = vfs_find(cmd + 3);
        if (!f) { terminal_print("File not found.\n"); return 1; }
        if (f->system)
        {
            terminal_print("Protected: cannot delete system file.\n");
            return 1;
        }
        f->used = 0;
        terminal_print("Removed.\n");
        return 1;
    }
    if (str_starts_with(cmd, "write "))
    {
        const char *rest = cmd + 6;
        char fname[MAX_NAME];
        int i = 0;
        while (rest[i] != 0 && rest[i] != ' ' && i < MAX_NAME - 1)
        {
            fname[i] = rest[i];
            i++;
        }
        fname[i] = 0;
        const char *text = (rest[i] == ' ') ? rest + i + 1 : "";

        VFile *f = vfs_find(fname);
        if (!f) f = vfs_alloc(fname);
        if (!f) { terminal_print("No space left.\n"); return 1; }

        decode_newlines(text, f->content, MAX_CONTENT);
        terminal_print("Written.\n");
        return 1;
    }
    if (str_starts_with(cmd, "append "))
    {
        const char *rest = cmd + 7;
        char fname[MAX_NAME];
        int i = 0;
        while (rest[i] != 0 && rest[i] != ' ' && i < MAX_NAME - 1)
        {
            fname[i] = rest[i];
            i++;
        }
        fname[i] = 0;
        const char *text = (rest[i] == ' ') ? rest + i + 1 : "";

        VFile *f = vfs_find(fname);
        if (!f) f = vfs_alloc(fname);
        if (!f) { terminal_print("No space left.\n"); return 1; }

        char decoded[MAX_CONTENT];
        decode_newlines(text, decoded, MAX_CONTENT);

        int len = 0;
        while (f->content[len]) len++;

        if (len > 0 && len < MAX_CONTENT - 1)
            f->content[len++] = '\n';

        int k = 0;
        while (decoded[k] && len < MAX_CONTENT - 1)
            f->content[len++] = decoded[k++];
        f->content[len] = 0;

        terminal_print("Appended.\n");
        return 1;
    }
    if (str_starts_with(cmd, "run "))
    {
        VFile *f = vfs_find(cmd + 4);
        if (!f) { terminal_print("File not found.\n"); return 1; }
        mc_run_script(f->content);
        return 1;
    }
    return 0;
}

static int handle_network_commands(const char *cmd)
{
    if (str_eq(cmd, "ping"))
    {
        unsigned char *gw_ip = arp_get_gateway_ip();
        unsigned char mac[6];
        if (arp_resolve_mac(gw_ip, mac))
        {
            icmp_send_echo_request(gw_ip, mac);
            terminal_print("Ping sent to gateway 10.0.2.2. Waiting...\n");
        }
        else
        {
            arp_send_request(gw_ip);
            terminal_print("Resolving gateway MAC, try 'ping' again in a moment.\n");
        }
        return 1;
    }
    if (str_eq(cmd, "netinfo"))
    {
        unsigned char *ip = arp_get_my_ip();
        char buf[8];
        terminal_print("My IP: ");
        for (int i = 0; i < 4; i++)
        {
            int_to_str(ip[i], buf);
            terminal_print(buf);
            if (i < 3) terminal_print(".");
        }
        terminal_print("\nGateway: 10.0.2.2\n");
        return 1;
    }
    if (str_eq(cmd, "network"))
    {
        unsigned char *ip = arp_get_my_ip();
        char buf[8];

        terminal_print("=== SovereignX Network Stack ===\n");
        terminal_print("Layers: Ethernet -> ARP -> IPv4 -> ICMP/TCP -> HTTP\n\n");

        terminal_print("My IP:      ");
        for (int i = 0; i < 4; i++)
        {
            int_to_str(ip[i], buf);
            terminal_print(buf);
            if (i < 3) terminal_print(".");
        }
        terminal_print("\n");

        terminal_print("Gateway:    10.0.2.2\n");

        unsigned char mac[6];
        if (arp_resolve_mac(arp_get_gateway_ip(), mac))
            terminal_print("ARP status: resolved\n");
        else
            terminal_print("ARP status: not resolved (try 'ping')\n");

        if (tcp_is_established())
            terminal_print("TCP status: connection active\n");
        else
            terminal_print("TCP status: idle\n");

        terminal_print("\nCommands: ping, netinfo, http <ip> <port> <path>\n");
        return 1;
    }
    if (str_starts_with(cmd, "http "))
    {
        const char *rest = cmd + 5;
        unsigned char ip[4];
        int part = 0, val = 0, i = 0;
        while (rest[i] && rest[i] != ' ')
        {
            if (rest[i] == '.')
            {
                ip[part++] = val;
                val = 0;
            }
            else
            {
                val = val * 10 + (rest[i] - '0');
            }
            i++;
        }
        ip[part] = val;

        while (rest[i] == ' ') i++;
        int port = 0;
        while (rest[i] >= '0' && rest[i] <= '9')
        {
            port = port * 10 + (rest[i] - '0');
            i++;
        }

        while (rest[i] == ' ') i++;
        const char *path = (rest[i]) ? &rest[i] : "/";

        http_get(ip, (unsigned short)port, path);
        terminal_print("HTTP request sent, waiting for response...\n");
        return 1;
    }
    return 0;
}

static int handle_game_commands(const char *cmd)
{
    if (game_pending_save())
    {
        if (str_eq(cmd, "y") || str_eq(cmd, "Y"))
        {
            game_confirm_save(1);
            return 1;
        }
        if (str_eq(cmd, "n") || str_eq(cmd, "N"))
        {
            game_confirm_save(0);
            return 1;
        }
    }

    if (str_starts_with(cmd, "play game "))
    {
        game_start(cmd + 10);
        return 1;
    }

    if (str_starts_with(cmd, "play app "))
    {
        app_create(cmd + 9);
        return 1;
    }

    if (game_is_active() && str_starts_with(cmd, "guess "))
    {
        int val = 0;
        const char *p = cmd + 6;
        while (*p >= '0' && *p <= '9') { val = val * 10 + (*p - '0'); p++; }
        game_guess(val);
        return 1;
    }

    if (str_starts_with(cmd, "bind game "))
    {
        const char *rest = cmd + 10;
        char name[32];
        int i = 0;
        while (rest[i] && rest[i] != ' ' && i < 31) { name[i] = rest[i]; i++; }
        name[i] = 0;
        while (rest[i] == ' ') i++;
        char key = rest[i];

        if (key == 0)
        {
            terminal_print("Usage: bind game <name> <key>\n");
            return 1;
        }

        if (keybind_add(key, 1, name))
        {
            char keystr[2];
            keystr[0] = key;
            keystr[1] = 0;
            terminal_print("Bound Alt+");
            terminal_print(keystr);
            terminal_print(" to game '");
            terminal_print(name);
            terminal_print("'.\n");
        }
        else
        {
            terminal_print("Invalid key or no space left.\n");
        }
        return 1;
    }

    if (str_starts_with(cmd, "bind app "))
    {
        const char *rest = cmd + 9;
        char name[32];
        int i = 0;
        while (rest[i] && rest[i] != ' ' && i < 31) { name[i] = rest[i]; i++; }
        name[i] = 0;
        while (rest[i] == ' ') i++;
        char key = rest[i];

        if (key == 0)
        {
            terminal_print("Usage: bind app <name> <key>\n");
            return 1;
        }

        if (keybind_add(key, 0, name))
        {
            char keystr[2];
            keystr[0] = key;
            keystr[1] = 0;
            terminal_print("Bound Alt+");
            terminal_print(keystr);
            terminal_print(" to app '");
            terminal_print(name);
            terminal_print("'.\n");
        }
        else
        {
            terminal_print("Invalid key or no space left.\n");
        }
        return 1;
    }

    if (str_eq(cmd, "bind list"))
    {
        keybind_list();
        return 1;
    }

    return 0;
}

static int handle_desktop_commands(const char *cmd)
{
    if (str_starts_with(cmd, "theme "))
    {
        const char *name = cmd + 6;
        if (str_eq(name, "dark"))       { background_set_color(0x101014); terminal_print("Theme applied: dark\n"); return 1; }
        if (str_eq(name, "retro"))      { background_set_color(0x0000AA); terminal_print("Theme applied: retro\n"); return 1; }
        if (str_eq(name, "matrix"))     { background_set_color(0x001A00); terminal_print("Theme applied: matrix\n"); return 1; }
        if (str_eq(name, "ocean"))      { background_set_color(0x0D3B3E); terminal_print("Theme applied: ocean\n"); return 1; }
        terminal_print("Unknown theme. Try: dark, retro, matrix, ocean\n");
        return 1;
    }

    if (str_starts_with(cmd, "app create "))
    {
        const char *rest = cmd + 11;
        char name[16];
        int i = 0;
        while (rest[i] && rest[i] != ' ' && i < 15) { name[i] = rest[i]; i++; }
        name[i] = 0;
        while (rest[i] == ' ') i++;
        const char *script = &rest[i];

        if (script[0] == 0)
        {
            terminal_print("Usage: app create <name> <script.mc>\n");
            return 1;
        }

        custom_icon_add_app(name, 0x55FFAA, script);
        terminal_print("App created: ");
        terminal_print(name);
        terminal_print(" -> runs ");
        terminal_print(script);
        terminal_print("\n");
        return 1;
    }

    if (str_starts_with(cmd, "icon add "))
    {
        const char *rest = cmd + 9;
        char name[16];
        int i = 0;
        while (rest[i] && rest[i] != ' ' && i < 15) { name[i] = rest[i]; i++; }
        name[i] = 0;
        const char *hex = (rest[i] == ' ') ? rest + i + 1 : "FFFFFF";
        custom_icon_add(name, hex_to_uint(hex));
        terminal_print("Icon added: ");
        terminal_print(name);
        terminal_print("\n");
        return 1;
    }

    if (str_starts_with(cmd, "icon remove "))
    {
        custom_icon_remove(cmd + 12);
        terminal_print("Icon removed.\n");
        return 1;
    }

    if (str_eq(cmd, "layout save"))
    {
        char buf[200];
        int p = 0;
        int count = custom_icon_count();
        for (int i = 0; i < count; i++)
        {
            const char *n = custom_icon_name(i);
            uint32_t c = custom_icon_color(i);
            int j = 0;
            while (n[j] && p < 190) buf[p++] = n[j++];
            buf[p++] = ',';
            const char *hexchars = "0123456789ABCDEF";
            for (int k = 0; k < 6; k++)
                buf[p++] = hexchars[(c >> ((5 - k) * 4)) & 0xF];
            buf[p++] = ';';
        }
        buf[p] = 0;
        vfs_write_file("sys/layout.dat", buf);
        terminal_print("Layout saved.\n");
        return 1;
    }

    if (str_eq(cmd, "layout load"))
    {
        char buf[200];
        if (!vfs_read_file("sys/layout.dat", buf, 200))
        {
            terminal_print("No saved layout found.\n");
            return 1;
        }

        custom_icon_clear_all();

        int i = 0;
        while (buf[i])
        {
            char name[16];
            int ni = 0;
            while (buf[i] && buf[i] != ',' && ni < 15) name[ni++] = buf[i++];
            name[ni] = 0;
            if (buf[i] == ',') i++;

            char hex[8];
            int hi = 0;
            while (buf[i] && buf[i] != ';' && hi < 7) hex[hi++] = buf[i++];
            hex[hi] = 0;
            if (buf[i] == ';') i++;

            if (ni > 0)
                custom_icon_add(name, hex_to_uint(hex));
        }

        terminal_print("Layout loaded.\n");
        return 1;
    }

    return 0;
}

static int handle_pkg_commands(const char *cmd)
{
    if (str_starts_with(cmd, "pkg install "))
    {
        pkg_install(cmd + 12);
        return 1;
    }
    if (str_eq(cmd, "pkg list"))
    {
        pkg_list();
        return 1;
    }
    if (str_eq(cmd, "pkg avail"))
    {
        pkg_avail();
        return 1;
    }
    if (str_eq(cmd, "open desktop"))
    {
        if (pkg_xorg_installed() && pkg_wm_installed())
        {
            terminal_print("Starting ");
            terminal_print(pkg_wm_name());
            terminal_print(" desktop environment...\n");
            desktop_activate();
        }
        else
        {
            terminal_print("No desktop environment installed.\n");
            terminal_print("Try: pkg install xorg\n");
            terminal_print("Then: pkg install i3 (or gnome, kde, xfce, openbox, dwm, fluxbox, mate, ...)\n");
        }
        return 1;
    }
    return 0;
}

int terminal_handle_system_command(const char *cmd)
{
    if (handle_disk_commands(cmd))    return 1;
    if (handle_pkg_commands(cmd))     return 1;
    if (handle_desktop_commands(cmd)) return 1;
    if (handle_game_commands(cmd))    return 1;
    if (handle_color_commands(cmd))   return 1;
    if (handle_window_commands(cmd))  return 1;
    if (handle_info_commands(cmd))    return 1;
    if (handle_math_commands(cmd))    return 1;
    if (handle_vfs_commands(cmd))     return 1;
    if (handle_network_commands(cmd)) return 1;
    return 0;
}
