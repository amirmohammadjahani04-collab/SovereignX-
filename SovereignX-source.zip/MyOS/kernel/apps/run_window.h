#ifndef RUN_WINDOW_H
#define RUN_WINDOW_H

void run_window_open(void);
void run_window_close(void);
int run_window_is_open(void);
void run_window_key(char c);
void run_window_draw(void);

#endif
