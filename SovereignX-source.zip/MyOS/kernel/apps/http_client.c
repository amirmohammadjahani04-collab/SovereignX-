#include "http_client.h"
#include "../network/tcp.h"

void http_get(unsigned char *dest_ip, unsigned short port, const char *path)
{
    char request[300];
    int i = 0;

    const char *get = "GET ";
    while (*get) request[i++] = *get++;

    const char *p = path;
    while (*p) request[i++] = *p++;

    const char *httpver = " HTTP/1.0\r\nConnection: close\r\n\r\n";
    while (*httpver) request[i++] = *httpver++;

    request[i] = 0;

    tcp_open_and_send(dest_ip, port, request, i);
}
