#ifndef EMBEDDED_SOURCE_H
#define EMBEDDED_SOURCE_H

int source_file_count(void);
const char *source_file_name(int index);
const char *source_file_content(const char *name);

#endif
