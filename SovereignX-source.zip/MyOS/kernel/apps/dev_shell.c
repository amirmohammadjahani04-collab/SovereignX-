#include "dev_shell.h"
#include "../gui/wm.h"
#include "../gui/background.h"
#include "../gui/icons.h"
#include "../gui/desktop.h"
#include "../fb.h"
#include "../graphics.h"
#include "../text_render.h"

#define DS_ROWS 35
#define DS_COLS 80
#define DS_MAX_CMD 128

static int active = 0;
static char screen[DS_ROWS][DS_COLS];
static int cur_row = 0;
static int cur_col = 0;
static char cmdline[DS_MAX_CMD];
static int cmd_len = 0;

/* ========== رنگ‌های قابل تغییر ========== */
static uint32_t live_bgcolor   = 0x12121F;
static uint32_t live_icon_files   = 0x4A6FE8;
static uint32_t live_icon_trash   = 0xE84A4A;
static uint32_t live_icon_sysinfo = 0xE8B84A;
static uint32_t live_icon_logout  = 0x4AE86F;
static uint32_t live_icon_settings= 0x8A4AE8;
static uint32_t live_taskbar_color= 0x14141F;

/* ========== فایل‌های سورس ========== */
typedef struct { const char *name; const char *summary; const char *content; } SourceFile;

static SourceFile src_files[] = {
{
"kernel/gui/desktop.c",
"Desktop manager: icons, windows, click handling",
"void desktop_redraw() {\n"
"    background_draw();\n"
"    icons_draw();\n"
"    taskbar_draw();\n"
"    if (terminal_open) terminal_window_draw();\n"
"}\n"
"void desktop_handle_click(int mx, int my) {\n"
"    // check start button, taskbar buttons, icons\n"
"}\n"
"void desktop_toggle_terminal() { terminal_open = !terminal_open; }\n"
"void desktop_cycle_bgcolor() { bgcolor_cycle_index++; }\n"
},
{
"kernel/gui/icons.c",
"Icon renderer: colored squares with labels",
"void draw_icon(fb, x, y, color, label) {\n"
"    draw_rect(fb, x-2, y-2, 52, 52, 0x0D0D17); // border\n"
"    draw_rect(fb, x, y, 48, 48, color);          // body\n"
"    draw_string(x, y+54, label, 0xCFCFCF);       // label\n"
"}\n"
"void icons_draw() {\n"
"    draw_icon(fb, 24, 24,  0x4A6FE8, 'Files');\n"
"    draw_icon(fb, 24, 112, 0xE84A4A, 'Trash');\n"
"    draw_icon(fb, 24, 200, 0xE8B84A, 'SysInfo');\n"
"    draw_icon(fb, 24, 288, 0x4AE86F, 'Logout');\n"
"    draw_icon(fb, 24, 376, 0x8A4AE8, 'Settings');\n"
"}\n"
},
{
"kernel/gui/taskbar.c",
"Taskbar: Start button, task buttons, branding",
"#define BAR_BG   0x14141F\n"
"#define BAR_ACCENT 0x4A6FE8\n"
"void taskbar_draw() {\n"
"    draw_rect(fb, 0, bar_y, width, 48, BAR_BG);\n"
"    draw_rect(fb, 7, bar_y+8, 88, 30, BAR_ACCENT); // Start\n"
"    draw_string(22, bar_y+18, 'Start', 0xFFFFFF);\n"
"    draw_task_button(T); draw_task_button(F);\n"
"    draw_task_button(S); draw_task_button(I);\n"
"}\n"
},
{
"kernel/gui/background.c",
"Background: framebuffer fill with gradient",
"#define PRO_DARK 0x12121F\n"
"static uint32_t bg_color = PRO_DARK;\n"
"void background_draw() {\n"
"    uint32_t top = lighten(bg_color, 12);\n"
"    for (y=0; y<height; y++) {\n"
"        color = (y < height/2) ? top : bg_color;\n"
"        for (x=0; x<width; x++) fb->buffer[y*stride+x] = color;\n"
"    }\n"
"}\n"
"void background_set_color(uint32_t c) { bg_color = c; }\n"
},
{
"kernel/drivers/keyboard.c",
"PS/2 keyboard: scancodes to ASCII, modifiers",
"static const char scancode_to_ascii[128] = {\n"
"    0,27,'1','2','3','4','5','6','7','8','9','0','-','=','\\b',\n"
"    '\\t','q','w','e','r','t','y','u','i','o','p','[',']','\\n',\n"
"    0,'a','s','d','f','g','h','j','k','l',';','\\'','`',\n"
"    0,'\\\\','z','x','c','v','b','n','m',',','.','/' ...\n"
"};\n"
"void keyboard_handler(uint8_t scancode) {\n"
"    if (ctrl && alt) handle_shortcuts(scancode);\n"
"    else terminal_key(scancode_to_ascii[scancode]);\n"
"}\n"
},
{
"kernel/apps/terminal_key.c",
"Terminal: screen buffer, command runner",
"static char buffer[20][60];\n"
"void terminal_key(char c) {\n"
"    if (c == '\\n') { run_command(cmdline); cmd_len=0; }\n"
"    else cmdline[cmd_len++] = c;\n"
"}\n"
"void run_command(cmd) {\n"
"    if (str_eq(cmd,'help')) print_help();\n"
"    else terminal_handle_system_command(cmd);\n"
"}\n"
},
{
"kernel/gui/wm.c",
"Window manager: draws windows with titlebar",
"void wm_draw_window(x, y, w, h, title) {\n"
"    draw_rect(fb, x+6, y+6, w, h, 0x000000); // shadow\n"
"    draw_rect(fb, x, y, w, h, 0x2B2F38);     // body\n"
"    draw_rect(fb, x, y, w, 28, 0x1C2733);    // titlebar\n"
"    draw_circle(x+16, y+14, 6, 0xFF5F56);    // red\n"
"    draw_circle(x+36, y+14, 6, 0xFFBD2E);    // yellow\n"
"    draw_circle(x+56, y+14, 6, 0x27C93F);    // green\n"
"    draw_string(x+75, y+10, title, 0xCCCCCC);\n"
"}\n"
},
{
"kernel/main.c",
"Kernel entry point: init all subsystems",
"void kernel_main() {\n"
"    fb_init(); idt_init(); serial_init();\n"
"    installer_run();\n"
"    boot_log_run();\n"
"    terminal_init();\n"
"    desktop_init();\n"
"    nic_init(); ethernet_init();\n"
"    arp_init(); ipv4_init(); tcp_init();\n"
"    udp_init(); dns_init();\n"
"    rfs_init(); keybind_init();\n"
"    while(1) ethernet_poll();\n"
"}\n"
},
};
#define SRC_COUNT 8

/* ========== helper ========== */
static int ds_str_eq(const char *a, const char *b)
{
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static int ds_str_starts(const char *s, const char *p)
{
    while (*p) { if (*s != *p) return 0; s++; p++; }
    return 1;
}

static uint32_t ds_hex(const char *s)
{
    if (s[0]=='0' && (s[1]=='x'||s[1]=='X')) s+=2;
    uint32_t r=0;
    while (*s) {
        char c=*s;
        uint32_t v;
        if (c>='0'&&c<='9') v=c-'0';
        else if (c>='a'&&c<='f') v=c-'a'+10;
        else if (c>='A'&&c<='F') v=c-'A'+10;
        else break;
        r=(r<<4)|v; s++;
    }
    return r;
}

/* ========== screen ========== */
static void ds_cls(void)
{
    for (int r=0;r<DS_ROWS;r++)
        for (int c=0;c<DS_COLS;c++)
            screen[r][c]=0;
    cur_row=0; cur_col=0;
}

static void ds_scroll(void)
{
    for (int r=1;r<DS_ROWS;r++)
        for (int c=0;c<DS_COLS;c++)
            screen[r-1][c]=screen[r][c];
    for (int c=0;c<DS_COLS;c++) screen[DS_ROWS-1][c]=0;
    cur_row=DS_ROWS-1;
}

static void ds_nl(void)
{
    cur_col=0; cur_row++;
    if (cur_row>=DS_ROWS) ds_scroll();
}

static void ds_print(const char *s)
{
    while (*s) {
        if (*s=='\n') { ds_nl(); }
        else {
            if (cur_col>=DS_COLS) ds_nl();
            if (cur_row>=DS_ROWS) ds_scroll();
            screen[cur_row][cur_col++]=*s;
        }
        s++;
    }
}

/* ========== دستورات ========== */
static void cmd_source_list(void)
{
    ds_print("=== SovereignX Kernel Source Files ===\n");
    for (int i=0;i<SRC_COUNT;i++) {
        ds_print("  ");
        ds_print(src_files[i].name);
        ds_print("\n    -> ");
        ds_print(src_files[i].summary);
        ds_print("\n");
    }
    ds_print("\nUse: file content <filename>\n");
}

static void cmd_file_content(const char *name)
{
    for (int i=0;i<SRC_COUNT;i++) {
        if (ds_str_eq(name, src_files[i].name) ||
            ds_str_eq(name, src_files[i].name + 11) ||
            ds_str_eq(name, src_files[i].name + 7))
        {
            ds_print("=== "); ds_print(src_files[i].name); ds_print(" ===\n");
            ds_print(src_files[i].content);
            return;
        }
    }
    ds_print("Not found. Use 'source list' to see all files.\n");
}

static void cmd_set(const char *args)
{
    if (ds_str_starts(args, "bgcolor ")) {
        live_bgcolor = ds_hex(args+8);
        background_set_color(live_bgcolor);
        ds_print("bgcolor updated. Press F5 to apply.\n");
        return;
    }
    if (ds_str_starts(args, "taskbar ")) {
        live_taskbar_color = ds_hex(args+8);
        ds_print("taskbar color saved. Press F5 to apply.\n");
        return;
    }
    if (ds_str_starts(args, "iconcolor ")) {
        const char *rest = args+10;
        char icon[16]; int i=0;
        while (rest[i] && rest[i]!=' ' && i<15) { icon[i]=rest[i]; i++; }
        icon[i]=0;
        const char *hex = (rest[i]==' ') ? rest+i+1 : "FFFFFF";
        uint32_t color = ds_hex(hex);

        if (ds_str_eq(icon,"Files"))    { live_icon_files=color; }
        else if (ds_str_eq(icon,"Trash"))   { live_icon_trash=color; }
        else if (ds_str_eq(icon,"SysInfo")) { live_icon_sysinfo=color; }
        else if (ds_str_eq(icon,"Logout"))  { live_icon_logout=color; }
        else if (ds_str_eq(icon,"Settings")){ live_icon_settings=color; }
        else { ds_print("Icons: Files Trash SysInfo Logout Settings\n"); return; }

        ds_print("Icon color saved. Press F5 to apply.\n");
        return;
    }
    ds_print("Usage:\n");
    ds_print("  set bgcolor 0x1A1A2E\n");
    ds_print("  set taskbar 0x14141F\n");
    ds_print("  set iconcolor Files 0xFF0000\n");
}

static void apply_changes(void)
{
    background_set_color(live_bgcolor);
    icons_set_color(0, live_icon_files);
    icons_set_color(1, live_icon_trash);
    icons_set_color(2, live_icon_sysinfo);
    icons_set_color(3, live_icon_logout);
    icons_set_color(4, live_icon_settings);
    desktop_redraw();
    ds_print("Changes applied to desktop!\n");
}

static void ds_run(const char *cmd)
{
    if (cmd[0]==0) return;

    if (ds_str_eq(cmd,"help")) {
        ds_print("=== SovereignX Dev Shell ===\n");
        ds_print("source list           - all kernel source files\n");
        ds_print("file content <name>   - show file content\n");
        ds_print("set bgcolor 0xRRGGBB  - change bg color\n");
        ds_print("set iconcolor <n> 0x  - change icon color\n");
        ds_print("set taskbar 0xRRGGBB  - change taskbar color\n");
        ds_print("status                - current settings\n");
        ds_print("clear                 - clear screen\n");
        ds_print("F5                    - apply all changes\n");
        ds_print("Ctrl+Alt+X            - exit Dev Shell\n");
        return;
    }
    if (ds_str_eq(cmd,"source list") || ds_str_eq(cmd,"ls")) {
        cmd_source_list(); return;
    }
    if (ds_str_starts(cmd,"file content ")) {
        cmd_file_content(cmd+13); return;
    }
    if (ds_str_starts(cmd,"set ")) {
        cmd_set(cmd+4); return;
    }
    if (ds_str_eq(cmd,"status")) {
        ds_print("Current settings:\n");
        ds_print("  bgcolor:   live (use set bgcolor to change)\n");
        ds_print("  icons:     Files Trash SysInfo Logout Settings\n");
        ds_print("  Press F5 to apply changes to desktop\n");
        return;
    }
    if (ds_str_eq(cmd,"clear")) { ds_cls(); return; }

    ds_print("Unknown: "); ds_print(cmd); ds_print("\nType 'help'\n");
}

/* ========== public API ========== */
void dev_shell_open(void)
{
    active=1;
    ds_cls();
    ds_print("SovereignX Dev Shell\n");
    ds_print("Ctrl+Alt+X to exit | F5 to apply changes\n");
    ds_print("Type 'help' for commands\n");
    ds_print("----------------------------------------\n");
    ds_print("dev@sovereignx:~$ ");
}

void dev_shell_close(void)
{
    active=0;
    cmd_len=0;
    cmdline[0]=0;
}

int dev_shell_is_open(void) { return active; }

void dev_shell_key(char c)
{
    if (!active) return;

    if (c=='\n') {
        cmdline[cmd_len]=0;
        ds_nl();
        ds_run(cmdline);
        if (active) ds_print("dev@sovereignx:~$ ");
        cmd_len=0;
        return;
    }
    if (c=='\b') {
        if (cmd_len>0) {
            cmd_len--;
            if (cur_col>0) { cur_col--; screen[cur_row][cur_col]=0; }
        }
        return;
    }
    if (cmd_len<DS_MAX_CMD-1 && c>=32 && c<127) {
        cmdline[cmd_len++]=c;
        if (cur_col>=DS_COLS) ds_nl();
        screen[cur_row][cur_col++]=c;
    }
}

void dev_shell_f5(void)
{
    if (!active) return;
    ds_nl();
    apply_changes();
    ds_print("dev@sovereignx:~$ ");
}

void dev_shell_draw(void)
{
    if (!active) return;

    Framebuffer *fb = get_fb();

    /* پس‌زمینه کاملاً سیاه تمام‌صفحه */
    clear_screen(fb, 0x000000);

    /* نوار عنوان بالا */
    draw_rect(fb, 0, 0, fb->width, 20, 0x1A1A2E);
    draw_string(8, 4, "SovereignX Dev Shell | F5=Apply | Ctrl+Alt+X=Exit", 0x55FFFF);

    /* محتوای ترمینال */
    for (int row=0;row<DS_ROWS;row++) {
        char line[DS_COLS+1];
        for (int c=0;c<DS_COLS;c++) {
            char ch=screen[row][c];
            line[c]=ch?ch:' ';
        }
        line[DS_COLS]=0;

        uint32_t color=0x33FF66;
        if (line[0]=='='&&line[1]=='=') color=0x55FFFF;
        else if (line[0]==' '&&line[1]==' ') color=0xCCCCCC;
        else if (line[0]=='/') color=0x888888;
        else if (line[0]=='#') color=0xFF8844;
        else if (line[0]=='v'||line[0]=='s'||line[0]=='w') color=0xFFFF55;
        else if (ds_str_starts(line,"dev@")) color=0x4AE0E8;

        draw_string(4, 24+row*13, line, color);
    }

    fb_present();
}
