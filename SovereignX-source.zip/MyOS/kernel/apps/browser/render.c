#include "render.h"


static void draw_text(
    char *text
)
{
    /*
       اتصال به Framebuffer
       و Font Renderer

       فعلاً لایه خروجی:
       Window Manager

    */

    (void)text;
}



void render_dom(
    DOM_NODE *node
)
{
    if(!node)
        return;


    /*
       نمایش متن HTML
    */

    draw_text(
        node->text
    );
}
