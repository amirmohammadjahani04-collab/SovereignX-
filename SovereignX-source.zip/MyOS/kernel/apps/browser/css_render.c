#include "render.h"


void render_element(
    char *tag,
    char *text
)
{

    /*
       پشتیبانی:

       h1
       p
       div
       a

       رنگ و اندازه پایه

    */


    (void)tag;
    (void)text;
}
