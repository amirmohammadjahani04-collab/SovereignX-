#include "dom.h"


static DOM_NODE root;


static void copy_text(
    char *dst,
    char *src,
    int max
)
{
    int i=0;

    while(src[i] && i<max-1)
    {
        dst[i]=src[i];
        i++;
    }

    dst[i]=0;
}



void dom_parse(
    char *html
)
{

    root.tag[0]=0;
    root.text[0]=0;


    /*
       Parser ساده:

       <h1>Hello</h1>

    */


    if(html[0])
    {

        if(html[1]=='h' &&
           html[2]=='1')
        {
            copy_text(
                root.tag,
                "h1",
                32
            );
        }


        char *start = html;


        while(*start &&
              *start!='>')
        {
            start++;
        }


        if(*start)
        {
            start++;

            copy_text(
                root.text,
                start,
                128
            );
        }
    }
}



DOM_NODE *dom_root()
{
    return &root;
}
