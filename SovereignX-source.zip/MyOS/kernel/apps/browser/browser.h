#ifndef BROWSER_H
#define BROWSER_H

void browser_init();
void browser_open(char *url);

#endif
