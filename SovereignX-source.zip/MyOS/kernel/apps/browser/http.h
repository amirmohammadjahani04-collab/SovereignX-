#ifndef HTTP_H
#define HTTP_H

int http_get(
    unsigned int ip,
    char *host,
    char *path
);

char *http_body();

#endif
