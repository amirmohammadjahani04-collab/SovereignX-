#include "http.h"


int http_request(
    char *host,
    char *path
)
{

    /*
       GET /path HTTP/1.1

       Host: host

    */


    (void)host;
    (void)path;


    return 0;
}
