#include "dom.h"
#include "render.h"


void browser_show(
    char *html
)
{
    dom_parse(html);

    render_dom(
        dom_root()
    );
}
