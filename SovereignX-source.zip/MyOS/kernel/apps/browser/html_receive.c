#include "html_receive.h"


static char html_buffer[8192];

static int html_size = 0;


void html_receive(
    char *data,
    int size
)
{

    if(size > 8192)
        size = 8192;


    for(int i=0;i<size;i++)
    {
        html_buffer[i]=data[i];
    }


    html_size=size;
}
