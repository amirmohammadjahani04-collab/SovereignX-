#include "http.h"
#include "../../network/socket.h"


static char request[512];


static void build_request(
    char *host,
    char *path
)
{

    int i=0;


    char *a =
    "GET ";


    while(*a)
        request[i++]=*a++;


    while(*path)
        request[i++]=*path++;


    char *b =
    " HTTP/1.1\r\nHost: ";


    while(*b)
        request[i++]=*b++;


    while(*host)
        request[i++]=*host++;


    char *c =
    "\r\nConnection: close\r\n\r\n";


    while(*c)
        request[i++]=*c++;


    request[i]=0;
}



int http_get_real(
    unsigned int ip,
    char *host,
    char *path
)
{

    /*
       TCP Connect
    */

    if(socket_connect(
        ip,
        80
    ) != 0)
    {
        return -1;
    }


    /*
       ساخت:

       GET /index.html HTTP/1.1
       Host: example.com

    */

    build_request(
        host,
        path
    );


    /*
       ارسال Request
       از TCP

       tcp_send(request)

       بعد از اتصال TCP واقعی

    */


    return 0;
}
