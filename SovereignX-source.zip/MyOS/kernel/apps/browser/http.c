#include "http.h"
#include "../../network/socket.h"


static char response[8192];

static char body[8192];


static void make_request(
    char *host,
    char *path
)
{
    /*
       GET /path HTTP/1.1
       Host: host

    */

    (void)host;
    (void)path;
}



static void split_header()
{
    /*
       پیدا کردن:

       \r\n\r\n

       و جدا کردن Body

    */

}



int http_get(
    unsigned int ip,
    char *host,
    char *path
)
{

    /*
       TCP Connect
    */

    if(socket_connect(
        ip,
        80
    ) != 0)
    {
        return -1;
    }


    make_request(
        host,
        path
    );


    /*
       ارسال Request
       از TCP

    */


    /*
       دریافت Response
    */


    split_header();


    return 0;
}



char *http_body()
{
    return body;
}
