#ifndef HTML_H
#define HTML_H

void html_parse(
    char *data
);

#endif
