#ifndef RENDER_H
#define RENDER_H

#include "dom.h"

void render_dom(
    DOM_NODE *node
);

#endif
