#ifndef HTTP_RESPONSE_H
#define HTTP_RESPONSE_H


void http_receive(
    char *data,
    int size
);


char *http_html();


#endif
