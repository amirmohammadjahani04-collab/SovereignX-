#ifndef DOM_H
#define DOM_H


typedef struct
{
    char tag[32];
    char text[128];

} DOM_NODE;


void dom_parse(
    char *html
);


DOM_NODE *dom_root();


#endif
