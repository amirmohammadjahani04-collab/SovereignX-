#include "http_response.h"


static char response_buffer[16384];

static char html_buffer[16384];


static int html_length = 0;



void http_receive(
    char *data,
    int size
)
{

    if(size > 16384)
        size = 16384;


    for(int i=0;i<size;i++)
    {
        response_buffer[i]=data[i];
    }



    /*
       جدا کردن Header:

       HTTP/1.1 200 OK

       Header

       \r\n\r\n

       Body

    */


    int body_start = -1;


    for(int i=0;i<size-3;i++)
    {
        if(response_buffer[i]=='\r' &&
           response_buffer[i+1]=='\n' &&
           response_buffer[i+2]=='\r' &&
           response_buffer[i+3]=='\n')
        {
            body_start=i+4;
            break;
        }
    }



    if(body_start!=-1)
    {

        html_length=0;


        for(
            int i=body_start;
            i<size;
            i++
        )
        {
            html_buffer[html_length++]
            =
            response_buffer[i];
        }


        html_buffer[html_length]=0;
    }
}



char *http_html()
{
    return html_buffer;
}
