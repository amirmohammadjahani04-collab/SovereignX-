#include "html.h"


void html_parse(
    char *data
)
{

    /*
       Parser پایه:

       <title>
       <h1>
       <p>
       <a>

    */


    (void)data;
}
