#ifndef HTML_RECEIVE_H
#define HTML_RECEIVE_H

void html_receive(
    char *data,
    int size
);

#endif
