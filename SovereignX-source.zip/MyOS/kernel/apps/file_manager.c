#include "file_manager.h"


static volatile unsigned short *vga =
    (unsigned short*)0xb8000;


static void write_text(
    int pos,
    char *text
)
{
    int i = 0;

    while(text[i])
    {
        vga[pos+i] =
            text[i] | 0x0700;
        i++;
    }
}


void file_manager_init()
{
}


void file_manager_show()
{
    write_text(
        160,
        "SovereignX File Manager"
    );

    write_text(
        240,
        "[DIR] kernel"
    );

    write_text(
        320,
        "[FILE] sovereignx.kernel"
    );

    write_text(
        400,
        "[FILE] config.sys"
    );
}
