#include "../gui/wm.h"
#include "../fb.h"
#include "../graphics.h"
#include "../text_render.h"
#include "terminal_commands.h"

#define FM_X 480
#define FM_Y 40
#define FM_W 300
#define FM_H 350
#define CLIP_LEN 256

static char clipboard[CLIP_LEN];
static int clipboard_has_data = 0;
static char last_viewed[32] = "";
static int new_counter = 1;
static int rename_counter = 1;
static int paste_counter = 1;

void file_manager_window_draw(void)
{
    wm_draw_window(FM_X, FM_Y, FM_W, FM_H, "Files");

    int x = FM_X + 16;
    int y = FM_Y + 44;

    draw_string(x, y, "Files (memory):", 0x55FFFF);
    y += 20;

    int count = vfs_file_count();
    if (count == 0)
    {
        draw_string(x, y, "(empty)", 0xAAAAAA);
    }
    else
    {
        for (int i = 0; i < count && y < FM_Y + FM_H - 60; i++)
        {
            draw_string(x, y, vfs_file_name_at(i), 0xEEEEEE);
            y += 16;
        }
    }

    y = FM_Y + FM_H - 96;
    draw_string(x, y, "Win+F = new file", 0x888888); y += 14;
    draw_string(x, y, "Win+G = rename last file", 0x888888); y += 14;
    draw_string(x, y, "Win+C = copy last file", 0x888888); y += 14;
    draw_string(x, y, "Win+P = paste clipboard", 0x888888);
}

void file_manager_new_file(void)
{
    char name[32];
    int i = 0;
    const char *base = "newfile";
    while (base[i]) { name[i] = base[i]; i++; }
    name[i++] = '0' + (new_counter % 10);
    name[i] = 0;
    new_counter++;

    vfs_write_file(name, "");

    int j = 0;
    while (name[j] && j < 31) { last_viewed[j] = name[j]; j++; }
    last_viewed[j] = 0;
}

void file_manager_rename_last(void)
{
    if (last_viewed[0] == 0) return;

    char content[256];
    vfs_read_file(last_viewed, content, 256);

    char new_name[32];
    int i = 0;
    const char *base = "renamed";
    while (base[i]) { new_name[i] = base[i]; i++; }
    new_name[i++] = '0' + (rename_counter % 10);
    new_name[i] = 0;
    rename_counter++;

    vfs_write_file(new_name, content);

    int j = 0;
    while (new_name[j] && j < 31) { last_viewed[j] = new_name[j]; j++; }
    last_viewed[j] = 0;
}

void file_manager_copy(void)
{
    if (last_viewed[0] == 0) return;
    if (vfs_read_file(last_viewed, clipboard, CLIP_LEN))
        clipboard_has_data = 1;
}

void file_manager_paste(void)
{
    if (!clipboard_has_data) return;

    char name[32];
    int i = 0;
    const char *base = "pasted";
    while (base[i]) { name[i] = base[i]; i++; }
    name[i++] = '0' + (paste_counter % 10);
    name[i] = 0;
    paste_counter++;

    vfs_write_file(name, clipboard);
}
