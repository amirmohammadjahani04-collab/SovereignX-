#ifndef GAMES_H
#define GAMES_H

void game_start(const char *name);
void app_create(const char *name);
int game_is_active(void);
int game_pending_save(void);
void game_guess(int value);
void game_confirm_save(int yes);
int game_installed_count(void);
const char *game_installed_name(int index);
void game_replay_installed(int index);

#endif
