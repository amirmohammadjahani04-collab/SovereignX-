#include "source_shell.h"
#include "embedded_source.h"
#include "terminal_commands.h"
#include "../gui/wm.h"
#include "../fb.h"
#include "../graphics.h"
#include "../text_render.h"

#define SS_X 40
#define SS_Y 40
#define SS_W 500
#define SS_H 420

#define HIST_LEN 2000

static int active = 0;
static char history[HIST_LEN];
static int hist_len = 0;
static char cmdline[64];
static int cmd_len = 0;

static int str_eq(const char *a, const char *b)
{
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static int str_starts_with(const char *s, const char *prefix)
{
    while (*prefix) { if (*s != *prefix) return 0; s++; prefix++; }
    return 1;
}

static void ss_print(const char *s)
{
    int i = 0;
    while (s[i] && hist_len < HIST_LEN - 1) history[hist_len++] = s[i++];
    history[hist_len] = 0;
}

/* اگر تاریخچه خیلی طولانی شد، ابتدای آن را حذف کن تا جا باز شود */
static void ss_trim_if_needed(void)
{
    if (hist_len < HIST_LEN - 200) return;

    int cut = 400;
    if (cut > hist_len) cut = hist_len;

    for (int i = cut; i < hist_len; i++)
        history[i - cut] = history[i];
    hist_len -= cut;
    history[hist_len] = 0;
}

static void run_shell_command(const char *cmd)
{
    if (cmd[0] == 0) return;

    if (str_eq(cmd, "help"))
    {
        ss_print("Commands:\n");
        ss_print("  source list\n");
        ss_print("  file content <name>\n");
        ss_print("  clear\n");
        return;
    }

    if (str_eq(cmd, "clear"))
    {
        hist_len = 0;
        history[0] = 0;
        return;
    }

    if (str_eq(cmd, "source list"))
    {
        int count = source_file_count();
        for (int i = 0; i < count; i++)
        {
            ss_print(source_file_name(i));
            ss_print("\n");
        }
        return;
    }

    if (str_starts_with(cmd, "file content "))
    {
        const char *name = cmd + 13;
        const char *content = source_file_content(name);
        if (content[0] == 0)
        {
            ss_print("File not found: ");
            ss_print(name);
            ss_print("\n");
        }
        else
        {
            ss_print("--- ");
            ss_print(name);
            ss_print(" ---\n");
            ss_print(content);
            ss_print("--- end ---\n");
        }
        return;
    }

    ss_print("Unknown command: ");
    ss_print(cmd);
    ss_print("\n");
}

void source_shell_open(void)
{
    active = 1;
    hist_len = 0;
    history[0] = 0;
    cmd_len = 0;
    ss_print("SovereignX Source Shell\n");
    ss_print("Type 'help' for commands.\n");
    ss_print("> ");
}

int source_shell_is_active(void)
{
    return active;
}

void source_shell_key(char c)
{
    if (!active) return;

    if (c == '\n')
    {
        cmdline[cmd_len] = 0;
        ss_print("\n");
        run_shell_command(cmdline);
        ss_trim_if_needed();
        ss_print("> ");
        cmd_len = 0;
        return;
    }

    if (c == '\b')
    {
        if (cmd_len > 0)
        {
            cmd_len--;
            if (hist_len > 0) hist_len--;
            history[hist_len] = 0;
        }
        return;
    }

    if (cmd_len < 63 && hist_len < HIST_LEN - 1)
    {
        cmdline[cmd_len++] = c;
        char s[2]; s[0] = c; s[1] = 0;
        ss_print(s);
    }
}

void source_shell_window_draw(void)
{
    if (!active) return;

    wm_draw_window(SS_X, SS_Y, SS_W, SS_H, "Source Shell");

    int x = SS_X + 12;
    int y_top = SS_Y + 30;
    int y_max = SS_Y + SS_H - 16;

    /* شمارش تعداد خطوط برای نمایش فقط چند خط آخر (اسکرول ساده) */
    int total_lines = 1;
    for (int i = 0; i < hist_len; i++)
        if (history[i] == '\n') total_lines++;

    int visible_lines = (y_max - y_top) / 14;
    int skip_lines = total_lines - visible_lines;
    if (skip_lines < 0) skip_lines = 0;

    int line_no = 0;
    int line_start = 0;
    int y = y_top;

    for (int i = 0; i <= hist_len && y < y_max; i++)
    {
        if (history[i] == '\n' || history[i] == 0)
        {
            if (line_no >= skip_lines)
            {
                char line[76];
                int len = i - line_start;
                if (len > 74) len = 74;
                for (int k = 0; k < len; k++) line[k] = history[line_start + k];
                line[len] = 0;
                draw_string(x, y, line, 0x55FF88);
                y += 14;
            }
            line_no++;
            line_start = i + 1;
            if (history[i] == 0) break;
        }
    }
}
