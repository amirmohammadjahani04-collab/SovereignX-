#include "../gui/wm.h"

void settings_window_draw(void)
{
    wm_draw_window(200, 420, 400, 200, "Settings");
}
