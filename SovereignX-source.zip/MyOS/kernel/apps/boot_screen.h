#ifndef BOOT_SCREEN_H
#define BOOT_SCREEN_H

void boot_screen_run(void);

#endif
