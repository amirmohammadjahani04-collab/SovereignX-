#include "alert.h"

static volatile unsigned short *vga =
(unsigned short*)0xb8000;


void terminal_alert(char *msg)
{
    int pos = 700;
    int i = 0;

    while(msg[i])
    {
        vga[pos+i] =
            msg[i] | 0x0700;
        i++;
    }
}
