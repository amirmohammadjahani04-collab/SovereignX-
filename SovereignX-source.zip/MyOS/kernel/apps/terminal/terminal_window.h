#ifndef TERMINAL_WINDOW_H
#define TERMINAL_WINDOW_H

void terminal_window_draw(void);
void terminal_window_draw_text(void);

#endif
