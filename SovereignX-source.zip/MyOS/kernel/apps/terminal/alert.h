#ifndef ALERT_H
#define ALERT_H

void terminal_alert(char *msg);

#endif
