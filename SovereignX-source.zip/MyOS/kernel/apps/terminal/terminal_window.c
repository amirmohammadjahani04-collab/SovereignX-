#include "terminal_window.h"
#include "../../gui/wm.h"
#include "../../text_render.h"
#include "../../graphics.h"
#include "../../fb.h"
#include "../terminal.h"

void terminal_window_draw(void)
{
    wm_draw_window(40, 40, 400, 300, "Terminal");
    terminal_window_draw_text();
}

void terminal_window_draw_text(void)
{
    Framebuffer *fb = get_fb();

    draw_rect(fb, 42, 62, 396, 270, 0x2B2F38);

    for (int row = 0; row < TERMINAL_ROWS; row++)
    {
        char line[TERMINAL_COLS + 1];
        int i;
        for (i = 0; i < TERMINAL_COLS; i++)
        {
            char c = terminal_get_char(row, i);
            line[i] = c ? c : ' ';
        }
        line[TERMINAL_COLS] = 0;
        draw_string(50, 70 + row * 11, line, 0xCCCCCC);
    }
}
