#include "ata.h"

#define ATA_DATA       0x1F0
#define ATA_STATUS     0x1F7
#define ATA_COMMAND    0x1F7

static inline void outb(uint16_t port, uint8_t value)
{
    asm volatile("outb %0,%1"
    :
    :"a"(value),"Nd"(port));
}

static inline uint8_t inb(uint16_t port)
{
    uint8_t ret;

    asm volatile("inb %1,%0"
    :"=a"(ret)
    :"Nd"(port));

    return ret;
}

static inline void outw(uint16_t port, uint16_t value)
{
    asm volatile("outw %0,%w1"
    :
    :"a"(value),"Nd"(port));
}

static inline uint16_t inw(uint16_t port)
{
    uint16_t ret;

    asm volatile("inw %w1,%0"
    :"=a"(ret)
    :"Nd"(port));

    return ret;
}

static void ata_wait_ready(void)
{
    while (!(inb(ATA_STATUS) & 0x08));
}

int ata_read_sector(uint32_t lba, uint8_t *buffer)
{
    outb(0x1F6, 0xE0 | ((lba >> 24) & 0x0F));
    outb(0x1F2, 1);
    outb(0x1F3, lba);
    outb(0x1F4, lba >> 8);
    outb(0x1F5, lba >> 16);
    outb(ATA_COMMAND, 0x20);

    ata_wait_ready();

    for (int i = 0; i < 256; i++)
    {
        uint16_t data = inw(ATA_DATA);
        buffer[i * 2] = data & 0xff;
        buffer[i * 2 + 1] = data >> 8;
    }

    return 0;
}

int ata_write_sector(uint32_t lba, uint8_t *buffer)
{
    outb(0x1F6, 0xE0 | ((lba >> 24) & 0x0F));
    outb(0x1F2, 1);
    outb(0x1F3, lba);
    outb(0x1F4, lba >> 8);
    outb(0x1F5, lba >> 16);
    outb(0x1F7, 0x30);

    ata_wait_ready();

    for (int i = 0; i < 256; i++)
    {
        uint16_t data = buffer[i * 2] | (buffer[i * 2 + 1] << 8);
        outw(ATA_DATA, data);
    }

    return 0;
}
