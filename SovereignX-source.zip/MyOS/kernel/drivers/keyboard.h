#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <stdint.h>

void keyboard_handler(uint8_t scancode);
int keyboard_quick_boot_requested(void);

#endif
