#ifndef STORAGE_H
#define STORAGE_H

#define SECTOR_SIZE 512

void storage_init();

int storage_read(
    unsigned long sector,
    char* buffer
);

int storage_write(
    unsigned long sector,
    const char* buffer
);

#endif
