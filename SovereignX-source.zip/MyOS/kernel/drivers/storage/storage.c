#include "storage.h"

#define MAX_SECTORS 2048

static unsigned char disk[MAX_SECTORS][SECTOR_SIZE];


void storage_init()
{
    for(int i=0;i<MAX_SECTORS;i++)
    {
        for(int j=0;j<SECTOR_SIZE;j++)
        {
            disk[i][j]=0;
        }
    }
}


int storage_read(
    unsigned long sector,
    char* buffer
)
{
    if(sector>=MAX_SECTORS)
        return 0;


    for(int i=0;i<SECTOR_SIZE;i++)
    {
        buffer[i]=disk[sector][i];
    }

    return 1;
}


int storage_write(
    unsigned long sector,
    const char* buffer
)
{
    if(sector>=MAX_SECTORS)
        return 0;


    for(int i=0;i<SECTOR_SIZE;i++)
    {
        disk[sector][i]=buffer[i];
    }

    return 1;
}
