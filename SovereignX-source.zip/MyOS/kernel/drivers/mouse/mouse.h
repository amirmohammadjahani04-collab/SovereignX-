#ifndef MOUSE_H
#define MOUSE_H

void mouse_init(void);
void mouse_handler(unsigned char data);
int mouse_get_x(void);
int mouse_get_y(void);
int mouse_left_pressed(void);

#endif
