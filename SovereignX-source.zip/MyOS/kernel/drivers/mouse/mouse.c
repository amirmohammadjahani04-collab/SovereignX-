#include "mouse.h"
#include "../../gui/cursor.h"
#include "../../gui/desktop.h"
#include "../../installer.h"

static unsigned char packet[3];
static int packet_index = 0;
static int left_button = 0;
static int prev_left_button = 0;

static int down_x = 0;
static int down_y = 0;

void mouse_init(void)
{
    packet_index = 0;
}

static int abs_int(int v)
{
    return v < 0 ? -v : v;
}

void mouse_handler(unsigned char data)
{
    if (installer_is_active())
    {
        return; // موقع صفحه‌ی نصب، ماوس هیچ کاری نکنه
    }

    if (packet_index == 0)
    {
        if (!(data & 0x08) || (data & 0xC0))
        {
            return;
        }
    }

    packet[packet_index++] = data;

    if (packet_index == 3)
    {
        packet_index = 0;

        if (!(packet[0] & 0x08) || (packet[0] & 0xC0))
        {
            return;
        }

        prev_left_button = left_button;
        left_button = packet[0] & 0x01;

        signed char dx = (signed char)packet[1];
        signed char dy = (signed char)packet[2];

        cursor_move(dx, -dy);

        if (left_button && !prev_left_button)
        {
            down_x = cursor_get_x();
            down_y = cursor_get_y();
        }

        if (!left_button && prev_left_button)
        {
            int moved_x = abs_int(cursor_get_x() - down_x);
            int moved_y = abs_int(cursor_get_y() - down_y);
            if (moved_x < 8 && moved_y < 8)
            {
                desktop_handle_click(cursor_get_x(), cursor_get_y());
            }
        }

        desktop_redraw();
    }
}

int mouse_left_pressed(void)
{
    return left_button;
}
