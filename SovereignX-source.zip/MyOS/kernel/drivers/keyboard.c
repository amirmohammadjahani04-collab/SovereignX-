#include <stdint.h>
#include "../gui/cursor.h"
#include "../gui/desktop.h"
#include "../gui/keybind.h"
#include "../apps/terminal.h"
#include "../apps/file_manager_window.h"
#include "../apps/code_editor.h"
#include "../apps/dev_shell.h"
#include "../apps/run_window.h"
#include "../installer.h"
#include "../reboot.h"

extern void keyboard_set_quick_boot(int v);
extern void desktop_redraw_terminal_fast(void);

static uint8_t extended = 0;
static uint8_t ctrl_pressed = 0;
static uint8_t alt_pressed = 0;
static uint8_t win_pressed = 0;

static const char scancode_to_ascii[128] = {
    0, 27, '1','2','3','4','5','6','7','8','9','0','-','=','\b',
    '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',
    0, 'a','s','d','f','g','h','j','k','l',';','\'','`',
    0, '\\','z','x','c','v','b','n','m',',','.','/', 0,
    '*', 0, ' ', 0,
};

void keyboard_handler(uint8_t scancode)
{
    if (scancode == 0xE0)
    {
        extended = 1;
        return;
    }

    if (extended)
    {
        extended = 0;

        if (scancode == 0x5B) { win_pressed = 1; return; }
        if (scancode == 0xDB)
        {
            win_pressed = 0;
            desktop_toggle_start_menu();
            return;
        }

        switch (scancode)
        {
            case 0x48: cursor_move(0, -10); desktop_redraw(); return;
            case 0x50: cursor_move(0, 10);  desktop_redraw(); return;
            case 0x4B: cursor_move(-10, 0); desktop_redraw(); return;
            case 0x4D: cursor_move(10, 0);  desktop_redraw(); return;
        }
        return;
    }

    /* F5 */
    if (scancode == 0x3F)
    {
        if (dev_shell_is_open()) { dev_shell_f5(); desktop_redraw(); }
        return;
    }

    /* F10 */
    if (scancode == 0x44)
    {
        if (dev_shell_is_open()) { dev_shell_close(); desktop_redraw(); }
        return;
    }

    if (scancode == 0x1D) { ctrl_pressed = 1; return; }
    if (scancode == 0x9D) { ctrl_pressed = 0; return; }
    if (scancode == 0x38) { alt_pressed = 1; return; }
    if (scancode == 0xB8) { alt_pressed = 0; return; }

    if (scancode & 0x80) { return; }

    /* Ctrl+N = Quick Boot / رفتن مستقیم به دسکتاپ */
    if (ctrl_pressed && !alt_pressed && scancode == 0x31)
    {
        keyboard_set_quick_boot(1);
        if (installer_is_active())
        {
            installer_feed_key('n');
            installer_feed_key('\n');
        }
        return;
    }

    /* ESC */
    if (scancode == 0x01)
    {
        if (run_window_is_open()) { run_window_close(); desktop_redraw(); return; }
        desktop_close_start_menu();
        desktop_redraw();
        return;
    }

    if (win_pressed)
    {
        switch (scancode)
        {
            case 0x1F: dev_shell_open(); desktop_redraw(); return;
            case 0x10: dev_shell_close(); desktop_redraw(); return;
            case 0x13: run_window_open(); desktop_redraw(); return;
            case 0x21: file_manager_new_file();    desktop_redraw(); return;
            case 0x22: file_manager_rename_last(); desktop_redraw(); return;
            case 0x2E: file_manager_copy();        desktop_redraw(); return;
            case 0x19: file_manager_paste();       desktop_redraw(); return;
        }
    }

    if (ctrl_pressed && !alt_pressed && editor_is_active())
    {
        if (scancode == 0x13) { editor_run(); return; }
    }

    if (ctrl_pressed && alt_pressed)
    {
        switch (scancode)
        {
            case 0x14: desktop_toggle_terminal(); desktop_redraw(); return;
            case 0x21: desktop_toggle_files(); desktop_redraw(); return;
            case 0x1F: desktop_toggle_settings(); desktop_redraw(); return;
            case 0x26: desktop_trigger_shutdown(); return;
            case 0x17: desktop_toggle_sysinfo(); desktop_redraw(); return;
            case 0x13: system_reboot(); return;
            case 0x20: dev_shell_open(); desktop_redraw(); return;
            case 0x12: dev_shell_open(); desktop_redraw(); return;
            case 0x2D:
                if (dev_shell_is_open()) { dev_shell_close(); desktop_redraw(); return; }
                if (run_window_is_open()) { run_window_close(); desktop_redraw(); return; }
                if (editor_is_active()) { editor_exit(); return; }
                desktop_emergency_reset();
                return;
            case 0x22: desktop_cycle_bgcolor(); return;
            case 0x23: desktop_show_help(); return;
        }
        return;
    }
    else if (alt_pressed && !ctrl_pressed && !win_pressed)
    {
        keybind_handle_alt_key(scancode);
        return;
    }

    if (scancode == 0x1C &&
        desktop_is_active() &&
        !desktop_is_terminal_open() &&
        !editor_is_active() &&
        !dev_shell_is_open() &&
        !run_window_is_open())
    {
        desktop_activate_hovered();
        desktop_redraw();
        return;
    }

    if (scancode < 128)
    {
        char c = scancode_to_ascii[scancode];
        if (c)
        {
            if (installer_is_active())
            {
                installer_feed_key(c);
            }
            else if (dev_shell_is_open())
            {
                dev_shell_key(c);
                desktop_redraw();
            }
            else if (run_window_is_open())
            {
                run_window_key(c);
                desktop_redraw();
            }
            else
            {
                terminal_key(c);
                desktop_redraw_terminal_fast();
            }
        }
    }
}
