#include <stdint.h>

extern void interrupt_handler(uint8_t interrupt,uint8_t data);

void keyboard_irq(uint8_t key)
{
    interrupt_handler(1,key);
}
