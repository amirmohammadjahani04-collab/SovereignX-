#include <stdint.h>

extern void keyboard_handler(uint8_t key);

void interrupt_handler(uint8_t interrupt, uint8_t data)
{
    // Keyboard IRQ
    if(interrupt == 1)
    {
        keyboard_handler(data);
    }
}
