#include <stdint.h>
#include "idt.h"
#include "../io.h"

extern void keyboard_handler(uint8_t scancode);
extern void mouse_handler(uint8_t data);

struct idt_entry
{
    uint16_t offset_low;
    uint16_t selector;
    uint8_t  ist;
    uint8_t  type_attr;
    uint16_t offset_mid;
    uint32_t offset_high;
    uint32_t zero;
} __attribute__((packed));

struct idt_ptr
{
    uint16_t limit;
    uint64_t base;
} __attribute__((packed));

static struct idt_entry idt[256];
static struct idt_ptr idtp;

static void set_gate(int n, void *handler, uint16_t sel)
{
    uint64_t addr = (uint64_t)handler;
    idt[n].offset_low  = addr & 0xFFFF;
    idt[n].selector    = sel;
    idt[n].ist         = 0;
    idt[n].type_attr   = 0x8E;
    idt[n].offset_mid  = (addr >> 16) & 0xFFFF;
    idt[n].offset_high = (addr >> 32) & 0xFFFFFFFF;
    idt[n].zero        = 0;
}

struct interrupt_frame;

__attribute__((interrupt))
static void irq1_keyboard(struct interrupt_frame *frame)
{
    (void)frame;
    uint8_t scancode = inb(0x60);
    keyboard_handler(scancode);
    outb(0x20, 0x20);
}

__attribute__((interrupt))
static void irq12_mouse(struct interrupt_frame *frame)
{
    (void)frame;
    uint8_t data = inb(0x60);
    mouse_handler(data);
    outb(0xA0, 0x20); // EOI به PIC ثانویه
    outb(0x20, 0x20); // EOI به PIC اصلی
}

static void pic_remap(void)
{
    outb(0x20, 0x11);
    outb(0xA0, 0x11);
    outb(0x21, 0x20);
    outb(0xA1, 0x28);
    outb(0x21, 0x04);
    outb(0xA1, 0x02);
    outb(0x21, 0x01);
    outb(0xA1, 0x01);

    outb(0x21, 0xF9); // IRQ0,1,2 آزاد (کیبورد+cascade)، بقیه ماسک
    outb(0xA1, 0xEF); // IRQ12 (ماوس) آزاد
}

static void mouse_wait_signal(void)
{
    int timeout = 100000;
    while (timeout--)
    {
        if ((inb(0x64) & 2) == 0) return;
    }
}

static void mouse_wait_data(void)
{
    int timeout = 100000;
    while (timeout--)
    {
        if (inb(0x64) & 1) return;
    }
}

static void mouse_write(uint8_t data)
{
    mouse_wait_signal();
    outb(0x64, 0xD4);
    mouse_wait_signal();
    outb(0x60, data);
}

static uint8_t mouse_read(void)
{
    mouse_wait_data();
    return inb(0x60);
}

static void mouse_init(void)
{
    mouse_wait_signal();
    outb(0x64, 0xA8); // فعال‌سازی پورت ماوس

    mouse_wait_signal();
    outb(0x64, 0x20); // خوندن byte وضعیت کنترلر
    mouse_wait_data();
    uint8_t status = inb(0x60) | 2;
    mouse_wait_signal();
    outb(0x64, 0x60);
    mouse_wait_signal();
    outb(0x60, status);

    mouse_write(0xF6); // تنظیمات پیش‌فرض
    mouse_read();

    mouse_write(0xF4); // فعال‌سازی گزارش‌دهی
    mouse_read();
}

void idt_init(void)
{
    uint16_t cs;
    asm volatile ("mov %%cs, %0" : "=r"(cs));

    for (int i = 0; i < 256; i++)
    {
        set_gate(i, 0, cs);
        idt[i].type_attr = 0;
    }

    pic_remap();

    set_gate(33, (void*)irq1_keyboard, cs);
    set_gate(44, (void*)irq12_mouse, cs);

    idtp.limit = sizeof(idt) - 1;
    idtp.base = (uint64_t)&idt;
    asm volatile ("lidt %0" : : "m"(idtp));

    mouse_init();

    asm volatile ("sti");
}
