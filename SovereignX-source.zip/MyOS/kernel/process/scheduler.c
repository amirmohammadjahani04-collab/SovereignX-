#include "scheduler.h"
#include "process.h"

extern Process processes[];

int current_process=0;


void scheduler_init()
{
    current_process=0;
}


void scheduler_tick()
{
    for(int i=0;i<MAX_PROCESS;i++)
    {
        int index=(current_process+i)%MAX_PROCESS;

        if(processes[index].state==1)
        {
            current_process=index;

            if(processes[index].entry)
            {
                processes[index].entry();
            }

            break;
        }
    }
}
