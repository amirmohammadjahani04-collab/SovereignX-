#include "process.h"

Process processes[MAX_PROCESS];

int current=0;


void process_init()
{
    for(int i=0;i<MAX_PROCESS;i++)
    {
        processes[i].id=-1;
        processes[i].state=0;
    }
}


int process_create(char* name, void (*entry)())
{
    for(int i=0;i<MAX_PROCESS;i++)
    {
        if(processes[i].id==-1)
        {
            processes[i].id=i;
            processes[i].entry=entry;
            processes[i].state=1;

            int j=0;

            while(name[j])
            {
                processes[i].name[j]=name[j];
                j++;
            }

            processes[i].name[j]=0;

            return i;
        }
    }

    return -1;
}


void process_run()
{
    for(int i=0;i<MAX_PROCESS;i++)
    {
        if(processes[i].state==1)
        {
            current=i;

            if(processes[i].entry)
                processes[i].entry();
        }
    }
}
