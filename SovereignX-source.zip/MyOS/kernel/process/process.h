#ifndef PROCESS_H
#define PROCESS_H

#define MAX_PROCESS 32

typedef struct
{
    int id;
    char name[32];
    int state;
    void (*entry)();
} Process;


void process_init();
int process_create(char* name, void (*entry)());
void process_run();

#endif
