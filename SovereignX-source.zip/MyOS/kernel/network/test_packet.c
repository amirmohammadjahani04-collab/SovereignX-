#include "e1000.h"


void network_test()
{

    unsigned char packet[] =
    {
        0xff,0xff,0xff,
        0xff,0xff,0xff,

        0x02,0x00,0x00,
        0x00,0x00,0x01,

        0x08,0x00,

        'M','y','O','S'
    };


    e1000_send(
        packet,
        sizeof(packet)
    );
}
