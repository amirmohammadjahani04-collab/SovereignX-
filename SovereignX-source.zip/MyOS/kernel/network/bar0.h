#ifndef BAR0_H
#define BAR0_H

unsigned int pci_read_bar0(
    unsigned char bus,
    unsigned char slot
);

#endif
