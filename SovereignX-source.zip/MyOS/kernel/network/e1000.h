#ifndef E1000_H
#define E1000_H

void e1000_map_bar0(unsigned long bar0);
void e1000_init();

int e1000_send(
    unsigned char *data,
    int size
);

int e1000_receive(unsigned char *buffer);

#endif
