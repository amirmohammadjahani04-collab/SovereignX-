#ifndef PCI_H
#define PCI_H

#include <stdint.h>

int pci_find_e1000(uint32_t *bar0_out);

#endif
