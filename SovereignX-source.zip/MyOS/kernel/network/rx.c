#include "e1000.h"


int network_receive(
    unsigned char *buffer
)
{
    /*
      خواندن RX Descriptor

      اگر status آماده بود:
      packet تحویل لایه بالاتر می‌شود
    */


    (void)buffer;

    return 0;
}
