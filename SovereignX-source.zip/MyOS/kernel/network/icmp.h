#ifndef ICMP_H
#define ICMP_H

void icmp_send_echo_request(unsigned char *dest_ip, unsigned char *dest_mac);
void icmp_handle(unsigned char *data, int len, unsigned char *src_ip);
int icmp_reply_received(void);
unsigned char *icmp_last_reply_ip(void);

#endif
