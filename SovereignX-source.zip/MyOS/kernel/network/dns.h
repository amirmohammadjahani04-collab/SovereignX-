#ifndef DNS_H
#define DNS_H

void dns_init(void);
void dns_query(const char *hostname);
int dns_is_ready(void);
unsigned char *dns_get_result(void);
void dns_reset(void);

#endif
