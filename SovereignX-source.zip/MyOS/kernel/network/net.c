#include "net.h"

static int network_ready = 0;


void network_init()
{
    /*
      مرحله پایه شبکه SovereignX

      بعداً:
      PCI
      NIC
      TCP/IP
    */

    network_ready = 1;
}


void network_send_test()
{
    if(network_ready)
    {
        /*
          Packet TX placeholder
        */
    }
}
