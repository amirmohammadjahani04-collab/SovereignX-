#ifndef SOCKET_H
#define SOCKET_H

int socket_connect(
    unsigned int ip,
    unsigned short port
);

#endif
