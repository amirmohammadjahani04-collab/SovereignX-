#ifndef UDP_H
#define UDP_H

typedef void (*udp_callback)(unsigned char *data, int len, unsigned char *src_ip, unsigned short src_port);

void udp_init(void);
void udp_register_handler(unsigned short port, udp_callback cb);
void udp_send(unsigned char *dest_ip, unsigned char *dest_mac, unsigned short src_port, unsigned short dest_port, unsigned char *payload, int len);
void udp_handle(unsigned char *data, int len, unsigned char *src_ip);

#endif
