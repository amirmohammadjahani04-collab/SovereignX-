#include "ipv4.h"
#include "ethernet.h"
#include "arp.h"
#include "icmp.h"
#include "tcp.h"
#include "../serial.h"

static unsigned short ip_id_counter = 1;

static unsigned short checksum16(unsigned char *data, int len)
{
    unsigned int sum = 0;
    for (int i = 0; i + 1 < len; i += 2)
    {
        unsigned short word = (data[i] << 8) | data[i + 1];
        sum += word;
        if (sum & 0x10000) { sum &= 0xFFFF; sum++; }
    }
    if (len & 1)
    {
        unsigned short word = data[len - 1] << 8;
        sum += word;
        if (sum & 0x10000) { sum &= 0xFFFF; sum++; }
    }
    return (unsigned short)(~sum & 0xFFFF);
}

void ipv4_init(void)
{
    serial_write_string("[ipv4] ready\n");
}

unsigned char *ipv4_get_my_ip(void)
{
    return arp_get_my_ip();
}

void ipv4_send(unsigned char *dest_ip, unsigned char *dest_mac, unsigned char protocol, unsigned char *payload, int len)
{
    unsigned char packet[1500];
    unsigned char *my_ip_ptr = arp_get_my_ip();
    unsigned short total_len = 20 + len;

    packet[0] = 0x45;
    packet[1] = 0x00;
    packet[2] = (total_len >> 8) & 0xFF;
    packet[3] = total_len & 0xFF;
    packet[4] = (ip_id_counter >> 8) & 0xFF;
    packet[5] = ip_id_counter & 0xFF;
    ip_id_counter++;
    packet[6] = 0x40;
    packet[7] = 0x00;
    packet[8] = 64;
    packet[9] = protocol;
    packet[10] = 0;
    packet[11] = 0;
    for (int i = 0; i < 4; i++) packet[12 + i] = my_ip_ptr[i];
    for (int i = 0; i < 4; i++) packet[16 + i] = dest_ip[i];

    unsigned short csum = checksum16(packet, 20);
    packet[10] = (csum >> 8) & 0xFF;
    packet[11] = csum & 0xFF;

    for (int i = 0; i < len; i++) packet[20 + i] = payload[i];

    ethernet_send(dest_mac, 0x0800, packet, 20 + len);
}

void ipv4_handle(unsigned char *data, int len)
{
    if (len < 20)
        return;

    unsigned char protocol = data[9];
    unsigned char *src_ip = data + 12;
    int ihl = (data[0] & 0x0F) * 4;
    unsigned char *payload = data + ihl;
    int payload_len = len - ihl;

    if (protocol == 1)
    {
        icmp_handle(payload, payload_len, src_ip);
    }
    else if (protocol == 6)
    {
        tcp_handle(payload, payload_len, src_ip);
    }
}
