#include "e1000.h"
#include "e1000_desc.h"


extern volatile unsigned int *regs;

extern TX_DESC tx_ring[];

extern unsigned char tx_buffer[][2048];


#define E1000_TDT 0x3818


static void memcpy_fast(
    unsigned char *dst,
    unsigned char *src,
    int size
)
{
    for(int i=0;i<size;i++)
        dst[i]=src[i];
}



int e1000_send_old(
    unsigned char *data,
    int size
)
{

    if(size <=0 || size>2048)
        return -1;


    unsigned int index =
        regs[E1000_TDT/4]
        % TX_DESC_COUNT;


    memcpy_fast(
        tx_buffer[index],
        data,
        size
    );


    tx_ring[index].addr =
        (unsigned long)
        tx_buffer[index];


    tx_ring[index].length =
        size;


    /*
       E1000 Command:

       EOP  = End Of Packet
       IFCS = Insert CRC
       RS   = Report Status
    */

    tx_ring[index].cmd =
        0x09;


    tx_ring[index].status =
        0;


    /*
       حرکت Tail Pointer
    */

    regs[E1000_TDT/4] =
        (index+1)
        % TX_DESC_COUNT;


    return 0;
}
