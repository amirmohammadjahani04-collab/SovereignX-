#include "arp.h"
#include "ethernet.h"
#include "../serial.h"

static unsigned char my_ip[4] = { 10, 0, 2, 15 };
static unsigned char gateway_ip[4] = { 10, 0, 2, 2 };

static unsigned char last_ip[4];
static unsigned char last_mac[6];
static int last_known = 0;

void arp_init(void)
{
    serial_write_string("[arp] ready, IP=10.0.2.15\n");
}

unsigned char *arp_get_my_ip(void)
{
    return my_ip;
}

unsigned char *arp_get_gateway_ip(void)
{
    return gateway_ip;
}

int arp_resolve_mac(unsigned char *ip, unsigned char *mac_out)
{
    if (!last_known)
        return 0;
    for (int i = 0; i < 4; i++)
        if (ip[i] != last_ip[i])
            return 0;
    for (int i = 0; i < 6; i++)
        mac_out[i] = last_mac[i];
    return 1;
}

void arp_send_request(unsigned char *target_ip)
{
    unsigned char packet[28];
    unsigned char broadcast[6] = { 0xFF,0xFF,0xFF,0xFF,0xFF,0xFF };
    unsigned char *my_mac = ethernet_get_mac();

    packet[0] = 0x00; packet[1] = 0x01;
    packet[2] = 0x08; packet[3] = 0x00;
    packet[4] = 6;
    packet[5] = 4;
    packet[6] = 0x00; packet[7] = 0x01;

    for (int i = 0; i < 6; i++) packet[8 + i] = my_mac[i];
    for (int i = 0; i < 4; i++) packet[14 + i] = my_ip[i];
    for (int i = 0; i < 6; i++) packet[18 + i] = 0x00;
    for (int i = 0; i < 4; i++) packet[24 + i] = target_ip[i];

    ethernet_send(broadcast, 0x0806, packet, 28);

    serial_write_string("[arp] request sent\n");
}

void arp_handle_packet(unsigned char *data, int len)
{
    if (len < 28)
        return;

    unsigned short opcode = (data[6] << 8) | data[7];

    if (opcode == 0x0002)
    {
        unsigned char *sender_mac = data + 8;
        unsigned char *sender_ip = data + 14;

        for (int i = 0; i < 6; i++) last_mac[i] = sender_mac[i];
        for (int i = 0; i < 4; i++) last_ip[i] = sender_ip[i];
        last_known = 1;

        serial_write_string("[arp] reply received! MAC=");
        for (int i = 0; i < 6; i++) serial_write_hex(sender_mac[i]);
        serial_write_string("\n");
    }
    else if (opcode == 0x0001)
    {
        serial_write_string("[arp] request received\n");
    }
}
