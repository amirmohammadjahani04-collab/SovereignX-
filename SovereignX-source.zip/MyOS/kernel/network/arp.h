#ifndef ARP_H
#define ARP_H

void arp_init(void);
void arp_send_request(unsigned char *target_ip);
void arp_handle_packet(unsigned char *data, int len);
unsigned char *arp_get_my_ip(void);
unsigned char *arp_get_gateway_ip(void);
int arp_resolve_mac(unsigned char *ip, unsigned char *mac_out);

#endif
