#ifndef NET_H
#define NET_H

void network_init();
void network_send_test();

#endif
