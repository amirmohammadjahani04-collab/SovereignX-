#ifndef TCP_H
#define TCP_H

void tcp_init(void);
void tcp_open_and_send(unsigned char *dest_ip, unsigned short dest_port, const char *data, int len);
void tcp_handle(unsigned char *data, int len, unsigned char *src_ip);
int tcp_data_available(void);
int tcp_read_data(char *out, int max_len);
int tcp_is_established(void);

#endif
