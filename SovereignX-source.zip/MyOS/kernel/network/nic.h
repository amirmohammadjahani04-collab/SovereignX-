#ifndef NIC_H
#define NIC_H

void nic_init();

int nic_send(
    unsigned char *data,
    int size
);

int nic_receive(
    unsigned char *buffer
);

#endif
