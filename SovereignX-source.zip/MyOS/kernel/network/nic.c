#include "nic.h"
#include "pci.h"
#include "e1000.h"
#include "../serial.h"

static int nic_ready = 0;

void nic_init(void)
{
    uint32_t bar0;
    if (pci_find_e1000(&bar0))
    {
        serial_write_string("[nic] e1000 found, bar0=");
        serial_write_hex((bar0 >> 24) & 0xFF);
        serial_write_hex((bar0 >> 16) & 0xFF);
        serial_write_hex((bar0 >> 8) & 0xFF);
        serial_write_hex(bar0 & 0xFF);
        serial_write_string("\n");

        e1000_map_bar0(bar0);
        e1000_init();
        nic_ready = 1;
        serial_write_string("[nic] init complete\n");
    }
    else
    {
        serial_write_string("[nic] e1000 NOT FOUND\n");
        nic_ready = 0;
    }
}

int nic_send(unsigned char *data, int size)
{
    if (!nic_ready)
        return -1;
    return e1000_send(data, size);
}

int nic_receive(unsigned char *buffer)
{
    if (!nic_ready)
        return -1;
    return e1000_receive(buffer);
}
