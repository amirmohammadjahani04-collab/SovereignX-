#include "bar0.h"


static inline void outl(
    unsigned short port,
    unsigned int value
)
{
    asm volatile(
        "outl %0,%1"
        :
        :"a"(value),"Nd"(port)
    );
}


static inline unsigned int inl(
    unsigned short port
)
{
    unsigned int value;

    asm volatile(
        "inl %1,%0"
        :"=a"(value)
        :"Nd"(port)
    );

    return value;
}


unsigned int pci_read_bar0(
    unsigned char bus,
    unsigned char slot
)
{
    unsigned int address;

    address =
        (1<<31) |
        ((unsigned int)bus<<16) |
        ((unsigned int)slot<<11) |
        (0x10);


    outl(
        0xCF8,
        address
    );


    unsigned int bar =
        inl(0xCFC);


    return bar & 0xfffffff0;
}
