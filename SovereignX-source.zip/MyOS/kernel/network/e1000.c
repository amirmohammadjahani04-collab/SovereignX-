#include "e1000.h"
#include "e1000_desc.h"
#include "../kaddr.h"
#include "../serial.h"

#define E1000_CTRL  0x0000
#define E1000_RCTL  0x0100
#define E1000_TCTL  0x0400

#define E1000_TDBAL 0x3800
#define E1000_TDBAH 0x3804
#define E1000_TDLEN 0x3808
#define E1000_TDH   0x3810
#define E1000_TDT   0x3818

#define E1000_RDBAL 0x2800
#define E1000_RDBAH 0x2804
#define E1000_RDLEN 0x2808
#define E1000_RDH   0x2810
#define E1000_RDT   0x2818

#define E1000_RAL0  0x5400
#define E1000_RAH0  0x5404

#define TX_COUNT 16
#define RX_COUNT 16


static volatile unsigned int *regs = 0;

static TX_DESC tx_ring[TX_COUNT];
static RX_DESC rx_ring[RX_COUNT];


static unsigned char tx_buffer[TX_COUNT][2048];
static unsigned char rx_buffer[RX_COUNT][2048];


static int nic_ready = 0;


static void reg_write(
    unsigned int reg,
    unsigned int value
)
{
    regs[reg/4] = value;
}


static unsigned int reg_read(
    unsigned int reg
)
{
    return regs[reg/4];
}


void e1000_map_bar0(
    unsigned long bar0
)
{
    regs =
    (volatile unsigned int*)bar0;
}


static void e1000_register_init()
{
    // بیت 6 = Set Link Up (SLU). بدون این، کارت لینک رو بالا نمی‌آورد.
    reg_write(
        E1000_CTRL,
        0x40
    );
}


static void e1000_set_mac_filter(void)
{
    unsigned int ral = 0x52u | (0x54u << 8) | (0x00u << 16) | (0x12u << 24);
    unsigned int rah = 0x34u | (0x56u << 8) | (1u << 31);

    reg_write(E1000_RAL0, ral);
    reg_write(E1000_RAH0, rah);
}


static void e1000_enable_tx_rx(void)
{
    reg_write(E1000_TCTL, (1u << 1) | (1u << 3) | (0x0Fu << 4) | (0x3Fu << 12));
    reg_write(E1000_RCTL, (1u << 1) | (1u << 15));
}


static void e1000_tx_init()
{
    for(int i=0;i<TX_COUNT;i++)
    {
        tx_ring[i].addr =
        virt_to_phys((unsigned long)tx_buffer[i]);

        tx_ring[i].status = 1;
    }

    uint64_t ring_phys = virt_to_phys((unsigned long)tx_ring);

    reg_write(E1000_TDBAL, (unsigned int)(ring_phys & 0xFFFFFFFF));
    reg_write(E1000_TDBAH, (unsigned int)(ring_phys >> 32));

    reg_write(
        E1000_TDLEN,
        sizeof(tx_ring)
    );

    reg_write(
        E1000_TDH,
        0
    );

    reg_write(
        E1000_TDT,
        0
    );
}


static void e1000_rx_init()
{
    for(int i=0;i<RX_COUNT;i++)
    {
        rx_ring[i].addr =
        virt_to_phys((unsigned long)rx_buffer[i]);

        rx_ring[i].status = 0;
    }

    uint64_t ring_phys = virt_to_phys((unsigned long)rx_ring);

    reg_write(E1000_RDBAL, (unsigned int)(ring_phys & 0xFFFFFFFF));
    reg_write(E1000_RDBAH, (unsigned int)(ring_phys >> 32));

    reg_write(
        E1000_RDLEN,
        sizeof(rx_ring)
    );

    reg_write(
        E1000_RDH,
        0
    );

    reg_write(
        E1000_RDT,
        RX_COUNT-1
    );
}



void e1000_init()
{
    if(!regs)
    {
        serial_write_string("[e1000] regs is NULL, aborting\n");
        return;
    }

    serial_write_string("[e1000] regs mapped OK\n");

    e1000_register_init();

    e1000_tx_init();
    serial_write_string("[e1000] tx_init done\n");

    e1000_rx_init();
    serial_write_string("[e1000] rx_init done\n");

    e1000_set_mac_filter();
    serial_write_string("[e1000] mac filter set\n");

    e1000_enable_tx_rx();
    serial_write_string("[e1000] tx/rx enabled\n");

    unsigned int rctl = reg_read(E1000_RCTL);
    unsigned int status = reg_read(0x0008);
    serial_write_string("[e1000] RCTL=");
    serial_write_hex((rctl >> 24) & 0xFF);
    serial_write_hex((rctl >> 16) & 0xFF);
    serial_write_hex((rctl >> 8) & 0xFF);
    serial_write_hex(rctl & 0xFF);
    serial_write_string(" STATUS=");
    serial_write_hex((status >> 24) & 0xFF);
    serial_write_hex((status >> 16) & 0xFF);
    serial_write_hex((status >> 8) & 0xFF);
    serial_write_hex(status & 0xFF);
    serial_write_string("\n");

    nic_ready = 1;
}



int e1000_send(
    unsigned char *data,
    int size
)
{
    if(!nic_ready)
        return -1;


    int index =
    reg_read(E1000_TDT)
    % TX_COUNT;


    for(int i=0;i<size;i++)
        tx_buffer[index][i]=data[i];


    tx_ring[index].length=size;

    tx_ring[index].cmd=0x09;

    tx_ring[index].status=0;


    reg_write(
        E1000_TDT,
        index+1
    );


    return 0;
}


int e1000_receive(unsigned char *buffer)
{
    if (!nic_ready)
        return -1;

    int index = (reg_read(E1000_RDT) + 1) % RX_COUNT;

    if (!(rx_ring[index].status & 0x01))
    {
        return -1;
    }

    int len = rx_ring[index].length;

    for (int i = 0; i < len; i++)
        buffer[i] = rx_buffer[index][i];

    rx_ring[index].status = 0;

    reg_write(E1000_RDT, index);

    return len;
}
