#include "socket.h"
#include "tcp.h"


int socket_connect(
    unsigned int ip,
    unsigned short port
)
{
    return tcp_connect(
        ip,
        port
    );
}
