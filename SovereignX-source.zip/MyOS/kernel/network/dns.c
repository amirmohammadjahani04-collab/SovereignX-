#include "dns.h"
#include "udp.h"
#include "arp.h"
#include "../serial.h"

#define DNS_STATE_IDLE    0
#define DNS_STATE_WAITING 1
#define DNS_STATE_READY   2
#define DNS_STATE_FAILED  3

static unsigned char dns_server_ip[4] = { 10, 0, 2, 3 };
static unsigned char dns_server_mac[6];
static unsigned char result_ip[4];
static int state = DNS_STATE_IDLE;
static unsigned short query_id = 1234;

static void dns_udp_callback(unsigned char *data, int len, unsigned char *src_ip, unsigned short src_port)
{
    (void)src_ip;
    (void)src_port;
    if (len < 12) return;

    unsigned short id = (data[0] << 8) | data[1];
    if (id != query_id) return;

    unsigned short flags = (data[2] << 8) | data[3];
    unsigned short qdcount = (data[4] << 8) | data[5];
    unsigned short ancount = (data[6] << 8) | data[7];

    if (!(flags & 0x8000) || ancount == 0)
    {
        state = DNS_STATE_FAILED;
        serial_write_string("[dns] no answer / error\n");
        return;
    }

    int pos = 12;

    for (int q = 0; q < qdcount; q++)
    {
        int ended = 0;
        while (pos < len && !ended)
        {
            if ((data[pos] & 0xC0) == 0xC0) { pos += 2; ended = 1; }
            else if (data[pos] == 0) { pos += 1; ended = 1; }
            else { pos += data[pos] + 1; }
        }
        pos += 4;
    }

    for (int a = 0; a < ancount; a++)
    {
        if ((data[pos] & 0xC0) == 0xC0)
        {
            pos += 2;
        }
        else
        {
            while (pos < len && data[pos] != 0) pos += data[pos] + 1;
            pos += 1;
        }

        unsigned short type = (data[pos] << 8) | data[pos + 1];
        pos += 2;
        pos += 2;
        pos += 4;
        unsigned short rdlength = (data[pos] << 8) | data[pos + 1];
        pos += 2;

        if (type == 1 && rdlength == 4)
        {
            for (int i = 0; i < 4; i++) result_ip[i] = data[pos + i];
            state = DNS_STATE_READY;
            serial_write_string("[dns] resolved\n");
            return;
        }
        pos += rdlength;
    }

    state = DNS_STATE_FAILED;
    serial_write_string("[dns] no A record found\n");
}

void dns_init(void)
{
    udp_register_handler(53, dns_udp_callback);
    state = DNS_STATE_IDLE;
    serial_write_string("[dns] ready\n");
}

void dns_query(const char *hostname)
{
    if (!arp_resolve_mac(dns_server_ip, dns_server_mac))
    {
        arp_send_request(dns_server_ip);
        serial_write_string("[dns] resolving dns server mac, try again in a moment\n");
        state = DNS_STATE_WAITING;
        return;
    }

    unsigned char packet[300];
    query_id++;

    packet[0] = (query_id >> 8) & 0xFF;
    packet[1] = query_id & 0xFF;
    packet[2] = 0x01;
    packet[3] = 0x00;
    packet[4] = 0x00; packet[5] = 0x01;
    packet[6] = 0x00; packet[7] = 0x00;
    packet[8] = 0x00; packet[9] = 0x00;
    packet[10] = 0x00; packet[11] = 0x00;

    int pos = 12;
    int label_start = pos;
    pos++;
    int label_len = 0;
    const char *p = hostname;

    while (*p)
    {
        if (*p == '.')
        {
            packet[label_start] = label_len;
            label_start = pos;
            pos++;
            label_len = 0;
        }
        else
        {
            packet[pos] = *p;
            pos++;
            label_len++;
        }
        p++;
    }
    packet[label_start] = label_len;
    packet[pos] = 0;
    pos++;

    packet[pos++] = 0x00; packet[pos++] = 0x01;
    packet[pos++] = 0x00; packet[pos++] = 0x01;

    udp_send(dns_server_ip, dns_server_mac, 50000, 53, packet, pos);

    state = DNS_STATE_WAITING;
    serial_write_string("[dns] query sent\n");
}

int dns_is_ready(void)
{
    return state == DNS_STATE_READY;
}

unsigned char *dns_get_result(void)
{
    return result_ip;
}

void dns_reset(void)
{
    state = DNS_STATE_IDLE;
}
