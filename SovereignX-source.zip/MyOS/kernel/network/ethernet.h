#ifndef ETHERNET_H
#define ETHERNET_H

void ethernet_init(void);
void ethernet_send(unsigned char *dest, unsigned short type, unsigned char *payload, int size);
void ethernet_poll(void);
unsigned char *ethernet_get_mac(void);

#endif
