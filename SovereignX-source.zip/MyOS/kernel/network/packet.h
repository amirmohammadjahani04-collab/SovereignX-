#ifndef PACKET_H
#define PACKET_H

void packet_init();

int packet_send(
    unsigned char *data,
    int size
);

int packet_receive(
    unsigned char *buffer
);

#endif
