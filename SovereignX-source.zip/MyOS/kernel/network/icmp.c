#include "icmp.h"
#include "ipv4.h"
#include "../serial.h"

static int reply_flag = 0;
static unsigned char last_reply_ip[4];

static unsigned short icmp_checksum(unsigned char *data, int len)
{
    unsigned int sum = 0;
    for (int i = 0; i + 1 < len; i += 2)
    {
        unsigned short word = (data[i] << 8) | data[i + 1];
        sum += word;
        if (sum & 0x10000) { sum &= 0xFFFF; sum++; }
    }
    if (len & 1)
    {
        unsigned short word = data[len - 1] << 8;
        sum += word;
        if (sum & 0x10000) { sum &= 0xFFFF; sum++; }
    }
    return (unsigned short)(~sum & 0xFFFF);
}

void icmp_send_echo_request(unsigned char *dest_ip, unsigned char *dest_mac)
{
    unsigned char packet[12];
    packet[0] = 8;
    packet[1] = 0;
    packet[2] = 0;
    packet[3] = 0;
    packet[4] = 0x00;
    packet[5] = 0x01;
    packet[6] = 0x00;
    packet[7] = 0x01;
    packet[8] = 'M';
    packet[9] = 'y';
    packet[10] = 'O';
    packet[11] = 'S';

    unsigned short csum = icmp_checksum(packet, 12);
    packet[2] = (csum >> 8) & 0xFF;
    packet[3] = csum & 0xFF;

    reply_flag = 0;
    ipv4_send(dest_ip, dest_mac, 1, packet, 12);
    serial_write_string("[icmp] echo request sent\n");
}

void icmp_handle(unsigned char *data, int len, unsigned char *src_ip)
{
    if (len < 8)
        return;

    unsigned char type = data[0];
    if (type == 0)
    {
        reply_flag = 1;
        for (int i = 0; i < 4; i++) last_reply_ip[i] = src_ip[i];
        serial_write_string("[icmp] echo reply received\n");
    }
}

int icmp_reply_received(void)
{
    int r = reply_flag;
    reply_flag = 0;
    return r;
}

unsigned char *icmp_last_reply_ip(void)
{
    return last_reply_ip;
}
