#ifndef E1000_DESC_H
#define E1000_DESC_H

#define TX_DESC_COUNT 16
#define RX_DESC_COUNT 16


typedef struct
{
    unsigned long addr;
    unsigned short length;
    unsigned char cso;
    unsigned char cmd;
    unsigned char status;
    unsigned char css;
    unsigned short special;

} TX_DESC;


typedef struct
{
    unsigned long addr;
    unsigned short length;
    unsigned short checksum;
    unsigned char status;
    unsigned char errors;
    unsigned short special;

} RX_DESC;


#endif
