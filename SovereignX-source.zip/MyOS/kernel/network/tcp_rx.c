#include "tcp.h"
#include "e1000.h"


void tcp_receive(
    unsigned char *packet,
    int size
)
{
    if(size <= 0)
        return;


    /*
       بررسی TCP Header

       استخراج:
       - Source Port
       - Destination Port
       - Flags
       - Sequence

    */


    tcp_process(
        packet,
        size
    );
}
