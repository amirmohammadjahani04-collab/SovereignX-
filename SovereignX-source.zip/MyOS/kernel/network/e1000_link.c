#include <stdint.h>

static volatile uint32_t *e1000_regs = 0;

void e1000_link_init(void)
{
    if (!e1000_regs)
    {
        return;
    }

    uint32_t status = e1000_regs[2];

    if (status & 0x2)
    {
        return;
    }
}
