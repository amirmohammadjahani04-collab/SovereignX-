#include "tcp.h"
#include "ipv4.h"
#include "arp.h"
#include "../serial.h"

#define TCP_CLOSED     0
#define TCP_SYN_SENT   1
#define TCP_ESTABLISHED 2

#define FLAG_FIN 0x01
#define FLAG_SYN 0x02
#define FLAG_RST 0x04
#define FLAG_PSH 0x08
#define FLAG_ACK 0x10

static unsigned char state = TCP_CLOSED;
static unsigned int local_seq;
static unsigned int remote_seq;
static unsigned short local_port = 49152;
static unsigned short remote_port;
static unsigned char remote_ip[4];
static unsigned char remote_mac[6];

static char pending_data[512];
static int pending_len = 0;
static int pending_sent = 0;

static char rx_buffer[2048];
static int rx_len = 0;
static int rx_available = 0;

void tcp_init(void)
{
    state = TCP_CLOSED;
    serial_write_string("[tcp] ready\n");
}

static unsigned short tcp_checksum(unsigned char *my_ip, unsigned char *dst_ip, unsigned char *segment, int seg_len)
{
    unsigned char pseudo[12];
    for (int i = 0; i < 4; i++) pseudo[i] = my_ip[i];
    for (int i = 0; i < 4; i++) pseudo[4 + i] = dst_ip[i];
    pseudo[8] = 0;
    pseudo[9] = 6;
    pseudo[10] = (seg_len >> 8) & 0xFF;
    pseudo[11] = seg_len & 0xFF;

    unsigned int sum = 0;

    for (int i = 0; i + 1 < 12; i += 2)
    {
        unsigned short word = (pseudo[i] << 8) | pseudo[i + 1];
        sum += word;
        if (sum & 0x10000) { sum &= 0xFFFF; sum++; }
    }

    for (int i = 0; i + 1 < seg_len; i += 2)
    {
        unsigned short word = (segment[i] << 8) | segment[i + 1];
        sum += word;
        if (sum & 0x10000) { sum &= 0xFFFF; sum++; }
    }
    if (seg_len & 1)
    {
        unsigned short word = segment[seg_len - 1] << 8;
        sum += word;
        if (sum & 0x10000) { sum &= 0xFFFF; sum++; }
    }

    return (unsigned short)(~sum & 0xFFFF);
}

static void build_and_send_tcp(unsigned char flags, const unsigned char *payload, int payload_len)
{
    unsigned char packet[600];
    unsigned char *my_ip = arp_get_my_ip();

    packet[0] = (local_port >> 8) & 0xFF;
    packet[1] = local_port & 0xFF;
    packet[2] = (remote_port >> 8) & 0xFF;
    packet[3] = remote_port & 0xFF;

    packet[4] = (local_seq >> 24) & 0xFF;
    packet[5] = (local_seq >> 16) & 0xFF;
    packet[6] = (local_seq >> 8) & 0xFF;
    packet[7] = local_seq & 0xFF;

    packet[8] = (remote_seq >> 24) & 0xFF;
    packet[9] = (remote_seq >> 16) & 0xFF;
    packet[10] = (remote_seq >> 8) & 0xFF;
    packet[11] = remote_seq & 0xFF;

    packet[12] = 0x50;
    packet[13] = flags;
    packet[14] = 0xFF;
    packet[15] = 0xFF;
    packet[16] = 0;
    packet[17] = 0;
    packet[18] = 0;
    packet[19] = 0;

    for (int i = 0; i < payload_len; i++)
        packet[20 + i] = payload[i];

    int total_len = 20 + payload_len;
    unsigned short csum = tcp_checksum(my_ip, remote_ip, packet, total_len);
    packet[16] = (csum >> 8) & 0xFF;
    packet[17] = csum & 0xFF;

    ipv4_send(remote_ip, remote_mac, 6, packet, total_len);
}

void tcp_open_and_send(unsigned char *dest_ip, unsigned short dest_port, const char *data, int len)
{
    for (int i = 0; i < 4; i++) remote_ip[i] = dest_ip[i];
    remote_port = dest_port;

    unsigned char *gw_ip = arp_get_gateway_ip();
    if (!arp_resolve_mac(gw_ip, remote_mac))
    {
        arp_send_request(gw_ip);
        serial_write_string("[tcp] resolving gateway mac, retry\n");
        return;
    }

    int i = 0;
    while (i < len && i < 511) { pending_data[i] = data[i]; i++; }
    pending_len = i;
    pending_sent = 0;

    local_seq = 1000;
    remote_seq = 0;
    state = TCP_SYN_SENT;
    rx_len = 0;
    rx_available = 0;

    build_and_send_tcp(FLAG_SYN, 0, 0);
    local_seq++;

    serial_write_string("[tcp] SYN sent\n");
}

void tcp_handle(unsigned char *data, int len, unsigned char *src_ip)
{
    (void)src_ip;
    if (len < 20) return;

    unsigned short dst_port = (data[2] << 8) | data[3];
    if (dst_port != local_port) return;

    unsigned int seq = ((unsigned int)data[4] << 24) | ((unsigned int)data[5] << 16) |
                        ((unsigned int)data[6] << 8) | data[7];
    unsigned char flags = data[13];
    int hdr_len = ((data[12] >> 4) & 0xF) * 4;
    int payload_len = len - hdr_len;
    unsigned char *payload = data + hdr_len;

    if (state == TCP_SYN_SENT && (flags & (FLAG_SYN | FLAG_ACK)) == (FLAG_SYN | FLAG_ACK))
    {
        remote_seq = seq + 1;
        build_and_send_tcp(FLAG_ACK, 0, 0);
        state = TCP_ESTABLISHED;
        serial_write_string("[tcp] established\n");

        if (pending_len > 0 && !pending_sent)
        {
            build_and_send_tcp(FLAG_ACK | FLAG_PSH, (unsigned char *)pending_data, pending_len);
            local_seq += pending_len;
            pending_sent = 1;
        }
        return;
    }

    if (state == TCP_ESTABLISHED)
    {
        if (payload_len > 0)
        {
            for (int i = 0; i < payload_len && rx_len < (int)sizeof(rx_buffer) - 1; i++)
                rx_buffer[rx_len++] = payload[i];
            rx_buffer[rx_len] = 0;
            rx_available = 1;
            remote_seq = seq + payload_len;
            build_and_send_tcp(FLAG_ACK, 0, 0);
        }

        if (flags & FLAG_FIN)
        {
            remote_seq += 1;
            build_and_send_tcp(FLAG_ACK | FLAG_FIN, 0, 0);
            local_seq += 1;
            state = TCP_CLOSED;
            serial_write_string("[tcp] closed by peer\n");
        }
    }
}

int tcp_data_available(void)
{
    return rx_available;
}

int tcp_read_data(char *out, int max_len)
{
    int i = 0;
    while (i < rx_len && i < max_len - 1) { out[i] = rx_buffer[i]; i++; }
    out[i] = 0;
    rx_available = 0;
    rx_len = 0;
    return i;
}

int tcp_is_established(void)
{
    return state == TCP_ESTABLISHED;
}
