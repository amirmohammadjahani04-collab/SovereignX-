#include "packet.h"
#include "ethernet.h"


void packet_init()
{
}


int packet_send(
    unsigned char *data,
    int size
)
{
    if(size <= 0)
        return -1;


    unsigned char dest[6] = {
        0xff,0xff,0xff,
        0xff,0xff,0xff
    };

    ethernet_send(
        dest,
        0x0800,
        data,
        size
    );


    return 0;
}


int packet_receive(
    unsigned char *buffer
)
{
    (void)buffer;

    return 0;
}
