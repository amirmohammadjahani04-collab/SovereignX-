#include "pci.h"

#define PCI_CONFIG_ADDRESS 0xCF8
#define PCI_CONFIG_DATA    0xCFC

static inline void outl(uint16_t port, uint32_t value)
{
    asm volatile ("outl %0, %%dx" : : "a"(value), "d"(port));
}

static inline uint32_t inl(uint16_t port)
{
    uint32_t value;
    asm volatile ("inl %%dx, %0" : "=a"(value) : "d"(port));
    return value;
}

static uint32_t pci_config_read(uint8_t bus, uint8_t slot, uint8_t func, uint8_t offset)
{
    uint32_t address = (1u << 31) |
                        ((uint32_t)bus << 16) |
                        ((uint32_t)slot << 11) |
                        ((uint32_t)func << 8) |
                        (offset & 0xFC);
    outl(PCI_CONFIG_ADDRESS, address);
    return inl(PCI_CONFIG_DATA);
}

int pci_find_e1000(uint32_t *bar0_out)
{
    for (uint32_t bus = 0; bus < 256; bus++)
    {
        for (uint32_t slot = 0; slot < 32; slot++)
        {
            for (uint32_t func = 0; func < 8; func++)
            {
                uint32_t id = pci_config_read(bus, slot, func, 0x00);
                uint16_t vendor = id & 0xFFFF;
                uint16_t device = (id >> 16) & 0xFFFF;

                if (vendor == 0xFFFF)
                    continue; // دستگاهی وجود نداره

                // Intel e1000 (QEMU پیش‌فرض): vendor 0x8086, device 0x100E (82540EM)
                if (vendor == 0x8086 &&
                    (device == 0x100E || device == 0x100F || device == 0x10D3))
                {
                    uint32_t bar0 = pci_config_read(bus, slot, func, 0x10);
                    *bar0_out = bar0 & 0xFFFFFFF0; // پاک کردن bitهای پرچم
                    return 1;
                }
            }
        }
    }
    return 0;
}
