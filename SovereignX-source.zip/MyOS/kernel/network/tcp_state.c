#include "tcp.h"


typedef enum
{
    TCP_CLOSED,
    TCP_SYN_SENT,
    TCP_SYN_RECEIVED,
    TCP_ESTABLISHED,
    TCP_FINISHED

} TCP_STATE;


static TCP_STATE state =
TCP_CLOSED;



void tcp_process(
    unsigned char *data,
    int size
)
{

    unsigned char flags =
        data[13];


    if(state==TCP_SYN_SENT)
    {

        if(flags & 0x12)
        {
            /*
             SYN + ACK
            */

            state =
            TCP_ESTABLISHED;
        }

    }


    (void)size;
}
