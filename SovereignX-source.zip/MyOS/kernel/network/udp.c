#include "udp.h"
#include "ipv4.h"
#include "arp.h"
#include "../serial.h"

#define MAX_UDP_HANDLERS 4

static struct {
    unsigned short port;
    udp_callback cb;
} handlers[MAX_UDP_HANDLERS];

static int handler_count = 0;

void udp_init(void)
{
    handler_count = 0;
    serial_write_string("[udp] ready\n");
}

void udp_register_handler(unsigned short port, udp_callback cb)
{
    if (handler_count < MAX_UDP_HANDLERS)
    {
        handlers[handler_count].port = port;
        handlers[handler_count].cb = cb;
        handler_count++;
    }
}

static unsigned short udp_checksum(unsigned char *my_ip, unsigned char *dst_ip, unsigned char *segment, int seg_len)
{
    unsigned char pseudo[12];
    for (int i = 0; i < 4; i++) pseudo[i] = my_ip[i];
    for (int i = 0; i < 4; i++) pseudo[4 + i] = dst_ip[i];
    pseudo[8] = 0;
    pseudo[9] = 17;
    pseudo[10] = (seg_len >> 8) & 0xFF;
    pseudo[11] = seg_len & 0xFF;

    unsigned int sum = 0;

    for (int i = 0; i + 1 < 12; i += 2)
    {
        unsigned short word = (pseudo[i] << 8) | pseudo[i + 1];
        sum += word;
        if (sum & 0x10000) { sum &= 0xFFFF; sum++; }
    }

    for (int i = 0; i + 1 < seg_len; i += 2)
    {
        unsigned short word = (segment[i] << 8) | segment[i + 1];
        sum += word;
        if (sum & 0x10000) { sum &= 0xFFFF; sum++; }
    }
    if (seg_len & 1)
    {
        unsigned short word = segment[seg_len - 1] << 8;
        sum += word;
        if (sum & 0x10000) { sum &= 0xFFFF; sum++; }
    }

    unsigned short result = (unsigned short)(~sum & 0xFFFF);
    return result ? result : 0xFFFF;
}

void udp_send(unsigned char *dest_ip, unsigned char *dest_mac, unsigned short src_port, unsigned short dest_port, unsigned char *payload, int len)
{
    unsigned char packet[600];
    unsigned char *my_ip = arp_get_my_ip();
    int total_len = 8 + len;

    packet[0] = (src_port >> 8) & 0xFF;
    packet[1] = src_port & 0xFF;
    packet[2] = (dest_port >> 8) & 0xFF;
    packet[3] = dest_port & 0xFF;
    packet[4] = (total_len >> 8) & 0xFF;
    packet[5] = total_len & 0xFF;
    packet[6] = 0;
    packet[7] = 0;

    for (int i = 0; i < len; i++) packet[8 + i] = payload[i];

    unsigned short csum = udp_checksum(my_ip, dest_ip, packet, total_len);
    packet[6] = (csum >> 8) & 0xFF;
    packet[7] = csum & 0xFF;

    ipv4_send(dest_ip, dest_mac, 17, packet, total_len);
}

void udp_handle(unsigned char *data, int len, unsigned char *src_ip)
{
    if (len < 8) return;

    unsigned short src_port = (data[0] << 8) | data[1];
    unsigned short dst_port = (data[2] << 8) | data[3];
    unsigned char *payload = data + 8;
    int payload_len = len - 8;

    for (int i = 0; i < handler_count; i++)
    {
        if (handlers[i].port == dst_port)
        {
            handlers[i].cb(payload, payload_len, src_ip, src_port);
            return;
        }
    }
}
