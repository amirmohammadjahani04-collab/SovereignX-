#ifndef IPV4_H
#define IPV4_H

void ipv4_init(void);
unsigned char *ipv4_get_my_ip(void);
void ipv4_send(unsigned char *dest_ip, unsigned char *dest_mac, unsigned char protocol, unsigned char *payload, int len);
void ipv4_handle(unsigned char *data, int len);

#endif
