#include "ethernet.h"
#include "nic.h"
#include "arp.h"
#include "ipv4.h"
#include "../serial.h"

static unsigned char mac[6] = { 0x52, 0x54, 0x00, 0x12, 0x34, 0x56 };
static unsigned char tx_frame[1518];
static unsigned char rx_frame[1518];

void ethernet_init(void)
{
    serial_init();
    serial_write_string("[ethernet] init, MAC=");
    for (int i = 0; i < 6; i++) serial_write_hex(mac[i]);
    serial_write_string("\n");
}

unsigned char *ethernet_get_mac(void)
{
    return mac;
}

void ethernet_send(unsigned char *dest, unsigned short type, unsigned char *payload, int size)
{
    for (int i = 0; i < 6; i++) tx_frame[i] = dest[i];
    for (int i = 0; i < 6; i++) tx_frame[6 + i] = mac[i];
    tx_frame[12] = (type >> 8) & 0xFF;
    tx_frame[13] = type & 0xFF;

    for (int i = 0; i < size; i++)
        tx_frame[14 + i] = payload[i];

    nic_send(tx_frame, 14 + size);
}

void ethernet_poll(void)
{
    int len = nic_receive(rx_frame);
    if (len < 14)
        return;

    unsigned short type = (rx_frame[12] << 8) | rx_frame[13];

    if (type == 0x0806)
    {
        arp_handle_packet(rx_frame + 14, len - 14);
    }
    else if (type == 0x0800)
    {
        ipv4_handle(rx_frame + 14, len - 14);
    }
}
