#include <stdint.h>

extern void draw_text(int x,int y,const char* text,uint32_t color);

void sovereignx_print(const char* text)
{
    draw_text(200,500,text,0x00ff00);
}
