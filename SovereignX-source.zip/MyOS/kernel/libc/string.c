#include <stddef.h>

int strncmp(const char *a,const char *b,unsigned long n)
{
    for(unsigned long i=0;i<n;i++)
    {
        if(a[i]!=b[i])
            return (unsigned char)a[i]-(unsigned char)b[i];

        if(a[i]==0)
            return 0;
    }

    return 0;
}
