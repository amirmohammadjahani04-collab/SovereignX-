#ifndef PAGING_H
#define PAGING_H

void paging_init();

void map_page(unsigned long virtual_addr,
              unsigned long physical_addr);

unsigned long get_physical(unsigned long virtual_addr);

#endif
