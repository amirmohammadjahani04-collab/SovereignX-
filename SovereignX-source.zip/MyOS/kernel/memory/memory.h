#ifndef MEMORY_H
#define MEMORY_H

void memory_init();

void* kmalloc(unsigned long size);

void kfree(void* ptr);

#endif
