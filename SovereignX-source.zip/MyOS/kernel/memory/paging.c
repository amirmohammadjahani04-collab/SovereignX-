#include "paging.h"

#define MAX_PAGES 256

typedef struct
{
    unsigned long virtual_page;
    unsigned long physical_page;
    int present;
} Page;


Page pages[MAX_PAGES];


void paging_init()
{
    for(int i=0;i<MAX_PAGES;i++)
    {
        pages[i].present=0;
    }
}


void map_page(unsigned long virtual_addr,
              unsigned long physical_addr)
{
    for(int i=0;i<MAX_PAGES;i++)
    {
        if(pages[i].present==0)
        {
            pages[i].virtual_page=virtual_addr;
            pages[i].physical_page=physical_addr;
            pages[i].present=1;
            return;
        }
    }
}


unsigned long get_physical(unsigned long virtual_addr)
{
    for(int i=0;i<MAX_PAGES;i++)
    {
        if(pages[i].present &&
           pages[i].virtual_page==virtual_addr)
        {
            return pages[i].physical_page;
        }
    }

    return 0;
}
