#include "installer.h"

void installer_skip(void)
{
    installer_feed_key('n');
    installer_feed_key('\n');
    installer_feed_key('n');
    installer_feed_key('\n');
    installer_feed_key('n');
    installer_feed_key('\n');
}
