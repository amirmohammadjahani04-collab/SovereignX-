#include <stdint.h>

int disk_detect()
{
    return 1;
}

int disk_write()
{
    return 1;
}
