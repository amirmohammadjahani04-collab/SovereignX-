#include <stdint.h>

extern void draw_text(const char*);

void installer_menu()
{
    draw_text("==== SovereignX Installer ====");
    draw_text("");
    draw_text("1. Install SovereignX to Disk");
    draw_text("2. Run Live Desktop");
    draw_text("");
}
