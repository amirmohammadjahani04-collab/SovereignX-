#include <stdint.h>

void draw_text(const char* text);

int copy_system_file(const char* src, const char* dst)
{
    // بعداً به درایور دیسک واقعی وصل می‌شود
    return 1;
}

void install_to_disk()
{
    draw_text("Installing SovereignX to HDD/SSD...");

    copy_system_file(
        "EFI/BOOT/BOOTX64.EFI",
        "EFI/BOOT/BOOTX64.EFI"
    );

    copy_system_file(
        "kernel/sovereignx.kernel",
        "kernel/sovereignx.kernel"
    );

    draw_text("SovereignX installation complete.");
}
