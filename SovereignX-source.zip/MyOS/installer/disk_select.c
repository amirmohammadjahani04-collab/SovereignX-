#include <stdint.h>

void draw_text(const char* text);

void disk_menu()
{
    draw_text("SovereignX Disk Installer");
    draw_text("-------------------");
    draw_text("Disk 0 : Internal SSD");
    draw_text("Disk 1 : USB Drive");
    draw_text("");
    draw_text("Select target disk...");
}

int select_disk(int id)
{
    if(id == 0)
        return 1;

    return 0;
}
