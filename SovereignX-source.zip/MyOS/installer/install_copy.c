#include <stdint.h>

void draw_text(const char* text);

void install_copy()
{
    draw_text("Copying SovereignX files...");

    draw_text("BOOTX64.EFI");
    draw_text("kernel/sovereignx.kernel");
    draw_text("GUI files");

    draw_text("Writing system files...");
    draw_text("Done.");
}
