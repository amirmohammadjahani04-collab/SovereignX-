#include <stdint.h>

void draw_text(const char* text);

void install_sovereignx()
{
    draw_text("SovereignX Installer");
    draw_text("Preparing disk...");
    draw_text("Copying system files...");
    draw_text("Installing bootloader...");
    draw_text("Installation complete!");
}


void installer_start()
{
    install_sovereignx();
}
