#include <stdint.h>

void draw_text(const char* text);

void install_final()
{
    draw_text("SovereignX Final Installer");
    draw_text("");

    draw_text("Creating EFI partition...");
    draw_text("Copying BOOTX64.EFI...");
    draw_text("Copying Kernel...");
    draw_text("Installing Desktop GUI...");
    draw_text("Creating UEFI boot entry...");

    draw_text("");
    draw_text("SovereignX installed successfully!");
}
