
void interrupt_handler()
{

    // CPU وارد اینجا می‌شود

    while(1)
    {

    }

}

