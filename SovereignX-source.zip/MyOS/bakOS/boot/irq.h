#ifndef IRQ_H
#define IRQ_H

void irq0_handler();
void irq1_handler();

#endif
