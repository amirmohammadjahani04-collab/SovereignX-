
void draw_file(
char *name,
int x,
int y
)
{
    // نمایش آیکون فایل
}


void open_file(
char *name
)
{

    // خواندن فایل

    // تشخیص ELF

    // اجرا


}


void file_manager_start()
{

    // لیست فایل‌ها

}

