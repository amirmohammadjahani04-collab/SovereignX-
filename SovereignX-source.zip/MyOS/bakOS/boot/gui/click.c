
void icon_click(
char *file
)
{

    open_file(file);

}

