#include "../../sdk/app.h"

void app_start()
{
    // برنامه کاربر SovereignX
}
