#include <stdint.h>

extern void draw_text(int x,int y,const char* text,uint32_t color);

void app_run(const char* name)
{
    draw_text(
        220,
        300,
        "SovereignX App Running:",
        0x00ff00
    );

    draw_text(
        220,
        330,
        name,
        0x00ff00
    );
}
