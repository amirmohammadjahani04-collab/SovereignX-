#ifndef FAT_WRITE_H
#define FAT_WRITE_H

#include <stdint.h>

int fat_create_file(
    const char *name,
    uint8_t *data,
    uint32_t size
);

#endif
