#ifndef FILE_OPEN_H
#define FILE_OPEN_H

int open_file(
    const char *name,
    unsigned char *buffer
);

#endif
