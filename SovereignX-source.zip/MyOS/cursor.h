#ifndef CURSOR_H
#define CURSOR_H

#include <stdint.h>

void cursor_init(void);
void cursor_draw(void);
void cursor_move(int x, int y);

#endif
