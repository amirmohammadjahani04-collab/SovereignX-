#ifndef TASKBAR_H
#define TASKBAR_H

void taskbar_draw(void);
void taskbar_add_app(const char *name);

#endif
