#include "cursor.h"
#include "graphics.h"

static int cursor_x = 100;
static int cursor_y = 100;


void cursor_init(void)
{
    cursor_x = 100;
    cursor_y = 100;
}


void cursor_draw(void)
{
    // شکل ساده فلش ماوس

    for(int i=0;i<10;i++)
    {
        put_pixel(
            cursor_x+i,
            cursor_y+i,
            0xffffff
        );

        put_pixel(
            cursor_x,
            cursor_y+i,
            0xffffff
        );
    }
}


void cursor_move(int x,int y)
{
    cursor_x = x;
    cursor_y = y;
}
