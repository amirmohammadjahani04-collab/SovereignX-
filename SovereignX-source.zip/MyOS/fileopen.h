#ifndef FILEOPEN_H
#define FILEOPEN_H

void file_open(const char *name);

#endif
