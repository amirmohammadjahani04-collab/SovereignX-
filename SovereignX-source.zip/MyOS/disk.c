#include "disk.h"

#define ATA_DATA       0x1F0
#define ATA_STATUS     0x1F7
#define ATA_COMMAND    0x1F7

static inline void outb(uint16_t port, uint8_t value)
{
    asm volatile("outb %0,%1"
    :
    :"a"(value),"Nd"(port));
}


static inline uint8_t inb(uint16_t port)
{
    uint8_t ret;

    asm volatile("inb %1,%0"
    :"=a"(ret)
    :"Nd"(port));

    return ret;
}


int ata_read_sector(
    uint32_t lba,
    uint8_t *buffer
)
{
    // انتخاب درایو
    outb(0x1F6,
        0xE0 | ((lba >> 24)&0x0F));


    // تعداد سکتور
    outb(0x1F2,1);


    // LBA
    outb(0x1F3,lba);
    outb(0x1F4,lba>>8);
    outb(0x1F5,lba>>16);


    // دستور خواندن
    outb(ATA_COMMAND,0x20);


    // انتظار آماده شدن
    while(!(inb(ATA_STATUS)&8));


    // خواندن 512 بایت
    for(int i=0;i<256;i++)
    {
        uint16_t data;

        asm volatile(
        "inw %1,%0"
        :"=a"(data)
        :"Nd"(ATA_DATA));


        buffer[i*2]=data&0xff;
        buffer[i*2+1]=data>>8;
    }


    return 0;
}
