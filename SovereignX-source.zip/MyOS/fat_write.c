#include "fat_write.h"
#include "disk.h"


uint16_t find_free_cluster(void)
{
    /*
       نسخه اولیه:
       بعداً FAT Table را جستجو می‌کنیم
    */

    return 5;
}



int fat_create_file(
    const char *name,
    uint8_t *data,
    uint32_t size
)
{
    uint16_t cluster;


    cluster = find_free_cluster();


    /*
      تبدیل Cluster به Sector
    */

    uint32_t sector;

    sector =
        33 +
        (cluster-2);


    /*
      نوشتن اطلاعات فایل
    */

    ata_write_sector(
        sector,
        data
    );


    /*
      مرحله بعد:
      - بروزرسانی FAT
      - ساخت Directory Entry
    */


    return 0;
}
