#include <string.h>

extern void create_app(const char*);
extern void build_app(const char*);
extern void run_app(const char*);

void terminal_command(char* input)
{
    if(strncmp(input,"create app ",11)==0)
    {
        create_app(input+11);
        return;
    }

    if(strncmp(input,"build ",6)==0)
    {
        build_app(input+6);
        return;
    }

    if(strncmp(input,"run ",4)==0)
    {
        run_app(input+4);
        return;
    }
}
