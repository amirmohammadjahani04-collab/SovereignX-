extern void terminal_add_char(char c);
extern void terminal_clear();
extern char* terminal_get_command();
extern void terminal_command(char* input);

void terminal_key(char c)
{
    if(c == '\n')
    {
        terminal_command(terminal_get_command());
        terminal_clear();
        return;
    }

    if(c == '\b')
    {
        return;
    }

    terminal_add_char(c);
}
