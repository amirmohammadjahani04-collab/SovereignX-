#include <stdint.h>

char terminal_buffer[128];
int terminal_index = 0;

void terminal_add_char(char c)
{
    if(terminal_index < 127)
    {
        terminal_buffer[terminal_index++] = c;
        terminal_buffer[terminal_index] = 0;
    }
}

void terminal_clear()
{
    terminal_index = 0;
    terminal_buffer[0] = 0;
}

char* terminal_get_command()
{
    return terminal_buffer;
}
