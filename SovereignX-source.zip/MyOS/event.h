#ifndef EVENT_H
#define EVENT_H

void mouse_click(int x, int y);

#endif
