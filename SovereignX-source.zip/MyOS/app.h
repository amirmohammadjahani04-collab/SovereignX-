#ifndef APP_H
#define APP_H

void open_file_manager(void);

#endif
