#include "fat_lookup.h"
#include "disk.h"


typedef struct
{
    char name[11];
    uint8_t attr;
    uint8_t reserved[10];
    uint16_t cluster;
    uint32_t size;

} fat_entry;


uint16_t fat_find_file(const char *name)
{
    uint8_t sector[512];


    /*
       فعلاً Root Directory نمونه است.
       بعداً:
       - تعداد سکتورهای FAT
       - محل Root Directory
       - تبدیل نام 8.3
       اضافه می‌شود.
    */


    ata_read_sector(
        19,
        sector
    );


    fat_entry *entry =
        (fat_entry*)sector;


    for(int i=0;i<16;i++)
    {
        if(entry[i].name[0]==0)
            break;


        /*
          مقایسه نام فایل
          در نسخه کامل اینجا انجام می‌شود
        */


        if(entry[i].name[0]==name[0])
        {
            return entry[i].cluster;
        }
    }


    return 0;
}
