#include "filemanager.h"
#include "wm.h"
#include "font.h"
#include "graphics.h"


static int file_window_id;


void filemanager_open(void)
{
    file_window_id = wm_create_window(
        "File Manager",
        80,
        60,
        400,
        300,
        0xaaaaaa
    );

    filemanager_draw();
}



void filemanager_draw(void)
{
    draw_string(
        100,
        100,
        "bakOS Files",
        0xffffff
    );


    draw_string(
        100,
        130,
        "[DIR] bin",
        0xffffff
    );


    draw_string(
        100,
        160,
        "[DIR] apps",
        0xffffff
    );


    draw_string(
        100,
        190,
        "[FILE] kernel.bin",
        0xffffff
    );


    draw_string(
        100,
        220,
        "[FILE] config.sys",
        0xffffff
    );
}
