#include <stdint.h>
#include "../kernel/framebuffer.h"

void pixel(int x,int y,uint32_t c)
{
    uint32_t *fb=(uint32_t*)framebuffer.address;
    fb[y*framebuffer.pixels_per_scanline+x]=c;
}


void draw_icon(int x,int y,uint32_t color)
{
    for(int yy=0;yy<90;yy++)
    {
        for(int xx=0;xx<90;xx++)
        {
            pixel(x+xx,y+yy,color);
        }
    }
}


void draw_icons()
{
    draw_icon(80,50,0x6655ff);    // Welcome
    draw_icon(320,50,0xff9900);  // Files
    draw_icon(560,50,0x00aa88);  // Terminal
    draw_icon(800,50,0x3377ff);  // Browser
    draw_icon(80,250,0xff3366);  // Status
}
