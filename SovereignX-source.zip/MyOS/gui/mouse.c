#include <stdint.h>

extern void pixel(int x,int y,uint32_t c);

int mouse_x=400;
int mouse_y=300;

void draw_mouse()
{
    uint32_t color=0xffffff;

    for(int i=0;i<15;i++)
    {
        pixel(mouse_x+i,mouse_y+i,color);
        pixel(mouse_x,mouse_y+i,color);
    }
}

void mouse_move(int dx,int dy)
{
    mouse_x+=dx;
    mouse_y+=dy;

    draw_mouse();
}
