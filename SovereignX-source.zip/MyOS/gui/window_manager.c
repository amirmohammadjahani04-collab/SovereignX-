#include <stdint.h>

typedef struct
{
    int x;
    int y;
    int width;
    int height;
    int visible;
} Window;

Window windows[10];

int window_count=0;

void create_window(int x,int y,int w,int h)
{
    windows[window_count].x=x;
    windows[window_count].y=y;
    windows[window_count].width=w;
    windows[window_count].height=h;
    windows[window_count].visible=1;

    window_count++;
}

void close_window(int id)
{
    if(id>=0 && id<window_count)
        windows[id].visible=0;
}

void move_window(int id,int x,int y)
{
    if(id>=0 && id<window_count)
    {
        windows[id].x=x;
        windows[id].y=y;
    }
}
