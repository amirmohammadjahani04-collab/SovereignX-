void clear_screen();
void draw_background();
void draw_logo(char*);
void draw_taskbar();
void create_window(char*,int,int,int,int);
void draw_rect(int,int,int,int);
void draw_text(int,int,char*);
