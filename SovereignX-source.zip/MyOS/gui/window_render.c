#include <stdint.h>

extern void pixel(int x,int y,uint32_t c);

typedef struct
{
    int x;
    int y;
    int width;
    int height;
    int visible;
} Window;

extern Window windows[10];
extern int window_count;

void draw_window_rect(int x,int y,int w,int h,uint32_t c)
{
    for(int j=0;j<h;j++)
    {
        for(int i=0;i<w;i++)
        {
            pixel(x+i,y+j,c);
        }
    }
}

void render_windows()
{
    for(int i=0;i<window_count;i++)
    {
        if(windows[i].visible)
        {
            int x=windows[i].x;
            int y=windows[i].y;

            // بدنه پنجره
            draw_window_rect(
                x,
                y,
                windows[i].width,
                windows[i].height,
                0x202020
            );

            // نوار عنوان
            draw_window_rect(
                x,
                y,
                windows[i].width,
                30,
                0x0066aa
            );
        }
    }
}
