#include <stdint.h>
#include "../kernel/framebuffer.h"

void pixel(int x, int y, uint32_t color)
{
    uint32_t* fb = (uint32_t*)framebuffer.address;

    fb[y * framebuffer.pixels_per_scanline + x] = color;
}
