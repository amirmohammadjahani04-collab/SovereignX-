#include <stdint.h>

extern void pixel(int x,int y,uint32_t c);

void draw_button(int x,int y,uint32_t color)
{
    for(int j=0;j<12;j++)
        for(int i=0;i<12;i++)
            pixel(x+i,y+j,color);
}

void draw_window_buttons(int x,int y,int width)
{
    uint32_t white=0xffffff;
    uint32_t red=0xff3333;
    uint32_t gray=0xaaaaaa;

    // minimize _
    for(int i=0;i<10;i++)
        pixel(x+width-70+i,y+20,gray);

    // maximize □
    for(int i=0;i<12;i++)
    {
        pixel(x+width-45,y+10+i,white);
        pixel(x+width-34,y+10+i,white);
        pixel(x+width-45+i,y+10,white);
        pixel(x+width-45+i,y+21,white);
    }

    // close X
    for(int i=0;i<12;i++)
    {
        pixel(x+width-20+i,y+10+i,red);
        pixel(x+width-8-i,y+10+i,red);
    }
}
