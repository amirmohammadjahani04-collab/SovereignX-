#include <stdint.h>

extern void pixel(int x,int y,uint32_t c);

void draw_search_window()
{
    uint32_t dark=0x202020;
    uint32_t blue=0x00aaff;
    uint32_t white=0xffffff;

    int x=250;
    int y=150;

    // بدنه پنجره
    for(int j=0;j<250;j++)
    {
        for(int i=0;i<400;i++)
        {
            pixel(x+i,y+j,dark);
        }
    }

    // نوار بالا
    for(int i=0;i<400;i++)
    {
        pixel(x+i,y,blue);
    }

    // جای لوگوی M
    for(int i=0;i<20;i++)
    {
        pixel(x+40+i,y+60+i,white);
        pixel(x+80-i,y+60+i,white);
    }
}
