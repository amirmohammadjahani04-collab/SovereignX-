extern int mouse_x;
extern int mouse_y;

extern void move_window(int id,int x,int y);

int dragging=0;
int active_window=0;

void mouse_drag()
{
    if(dragging)
    {
        move_window(
            active_window,
            mouse_x-100,
            mouse_y-20
        );
    }
}

void start_drag(int id)
{
    active_window=id;
    dragging=1;
}

void stop_drag()
{
    dragging=0;
}
