#include "gui.h"

void clear_screen()
{
}

void draw_background()
{
}

void draw_logo(char *name)
{
}

void draw_taskbar()
{
}

void draw_rect(int x,int y,int w,int h)
{
}

void draw_text(int x,int y,char *text)
{
}
