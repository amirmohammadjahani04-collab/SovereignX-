#include <stdint.h>
#include "../kernel/framebuffer.h"

void draw_taskbar()
{
    uint32_t *p=(uint32_t*)framebuffer.address;

    for(int y=framebuffer.height-60;y<framebuffer.height;y++)
    {
        for(int x=0;x<framebuffer.width;x++)
        {
            p[y*framebuffer.pixels_per_scanline+x]=0x202020;
        }
    }
}
