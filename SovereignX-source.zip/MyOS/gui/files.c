#include <stdint.h>

extern void pixel(int x,int y,uint32_t c);
extern void draw_text(int x,int y,const char* text,uint32_t color);

void files_draw()
{
    uint32_t white=0xffffff;
    uint32_t blue=0x0066aa;

    // پنجره فایل‌ها
    for(int y=120;y<420;y++)
    {
        for(int x=150;x<750;x++)
        {
            pixel(x,y,0x202020);
        }
    }

    // نوار عنوان
    for(int x=150;x<750;x++)
        pixel(x,120,blue);

    draw_text(200,160,"SovereignX Files",white);
    draw_text(200,210,"/home",white);
    draw_text(200,250,"kernel",white);
    draw_text(200,290,"gui",white);
    draw_text(200,330,"apps",white);
}
