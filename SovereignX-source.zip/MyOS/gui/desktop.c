#include "font.h"

extern void draw_background();
extern void draw_logo();
extern void draw_icons();
extern void draw_taskbar();

void desktop_start()
{
    draw_background();
    draw_logo();
    draw_icons();

    draw_text(400,420,"SovereignX",0x00aaff);
    draw_text(350,450,"Desktop",0xffffff);

    draw_taskbar();
}
