#include <stdint.h>
#include "../kernel/framebuffer.h"

extern void pixel(int x,int y,uint32_t c);

void rect(int x,int y,int w,int h,uint32_t c)
{
    for(int j=0;j<h;j++)
        for(int i=0;i<w;i++)
            pixel(x+i,y+j,c);
}

void draw_folder(int x,int y)
{
    rect(x,y,90,60,0xffcc33);
    rect(x+10,y-10,40,15,0xffcc33);
}

void draw_terminal(int x,int y)
{
    rect(x,y,90,70,0x222222);

    for(int i=0;i<30;i++)
    {
        pixel(x+15+i,y+30,0x00ff00);
    }
}

void draw_settings(int x,int y)
{
    rect(x+35,y,20,90,0xaaaaaa);
    rect(x,y+35,90,20,0xaaaaaa);
}

void draw_monitor(int x,int y)
{
    rect(x,y,90,60,0x3377ff);
    rect(x+35,y+60,20,20,0xffffff);
}

void draw_browser(int x,int y)
{
    rect(x,y,90,70,0x00aa88);
    rect(x+15,y+15,60,5,0xffffff);
}

void draw_icons()
{
    draw_folder(80,50);       // Files
    draw_terminal(240,50);    // Terminal
    draw_settings(400,50);    // Settings
    draw_monitor(560,50);     // Monitor
    draw_browser(720,50);     // Browser
}
