#include <stdint.h>

extern void pixel(int x,int y,uint32_t c);

void draw_rect(int x,int y,int w,int h,uint32_t c)
{
    for(int j=0;j<h;j++)
        for(int i=0;i<w;i++)
            pixel(x+i,y+j,c);
}

void draw_window(int x,int y,int w,int h)
{
    uint32_t body=0x202020;
    uint32_t title=0x0066aa;
    uint32_t button=0xffffff;

    // بدنه پنجره
    draw_rect(x,y,w,h,body);

    // نوار عنوان
    draw_rect(x,y,w,30,title);

    // دکمه X
    for(int i=0;i<10;i++)
    {
        pixel(x+w-25+i,y+10+i,button);
        pixel(x+w-15-i,y+10+i,button);
    }

    // دکمه minimize
    draw_rect(x+w-60,y+20,15,2,button);
}
