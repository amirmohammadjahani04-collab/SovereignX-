#include <stdint.h>
#include "../kernel/framebuffer.h"
#include "assets/background.h"

void draw_image()
{
    uint32_t *screen =
    (uint32_t*)framebuffer.address;

    for(uint32_t y=0;y<framebuffer.height;y++)
    {
        for(uint32_t x=0;x<framebuffer.width;x++)
        {
            screen[
            y * framebuffer.pixels_per_scanline + x
            ] =
            image_data[
            (y * framebuffer.width + x) * 4
            ];
        }
    }
}
