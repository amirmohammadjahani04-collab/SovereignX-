#include "../kernel/framebuffer.h"

void put_pixel(
    int x,
    int y,
    unsigned int color
)
{
    unsigned int *buffer;

    buffer =
    (unsigned int*)fb.address;

    buffer[
        y * fb.pixels_per_scanline + x
    ] = color;
}


void draw_desktop()
{

    for(int y=0;y<fb.height;y++)
    {
        for(int x=0;x<fb.width;x++)
        {
            put_pixel(
                x,
                y,
                0x102040
            );
        }
    }


    for(
    int y=fb.height-60;
    y<fb.height;
    y++)
    {
        for(int x=0;x<fb.width;x++)
        {
            put_pixel(
                x,
                y,
                0x202020
            );
        }
    }
}
