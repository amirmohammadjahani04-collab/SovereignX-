#include <stdint.h>
#include "../kernel/framebuffer.h"

void pixel(int x,int y,uint32_t c)
{
    uint32_t *p=(uint32_t*)framebuffer.address;
    p[y*framebuffer.pixels_per_scanline+x]=c;
}
