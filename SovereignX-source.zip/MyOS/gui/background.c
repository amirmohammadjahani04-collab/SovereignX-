#include <stdint.h>

extern void pixel(int x,int y,uint32_t c);
#include "../kernel/framebuffer.h"

void draw_background()
{
    for(int y=0;y<framebuffer.height;y++)
    {
        for(int x=0;x<framebuffer.width;x++)
        {
            uint32_t c=0x081018;

            if(x%80==0 || y%80==0)
                c=0x102850;

            pixel(x,y,c);
        }
    }
}
