#include <stdint.h>

extern void pixel(int x,int y,uint32_t c);

void draw_logo()
{
    int x0=500;
    int y0=180;

    uint32_t blue=0x00aaff;
    uint32_t glow=0x005577;

    // Glow background
    for(int y=-70;y<130;y++)
    {
        for(int x=-70;x<130;x++)
        {
            if(x*x+y*y < 5000)
                pixel(x0+x,y0+y,glow);
        }
    }

    // SovereignX M logo
    for(int i=0;i<20;i++)
    {
        pixel(x0+i,y0+i,blue);
        pixel(x0+80-i,y0+i,blue);

        pixel(x0+i,y0+80-i,blue);
        pixel(x0+80-i,y0+80-i,blue);
    }

    // Center line
    for(int i=20;i<70;i++)
    {
        pixel(x0+40,y0+i,blue);
    }
}
