#include <stdint.h>

extern void pixel(int x,int y,uint32_t c);
extern void draw_text(int x,int y,const char* text,uint32_t color);

void draw_menu()
{
    uint32_t bg=0x202020;
    uint32_t blue=0x00aaff;
    uint32_t white=0xffffff;

    int x=50;
    int y=80;

    // پنجره منو
    for(int j=0;j<350;j++)
    {
        for(int i=0;i<250;i++)
        {
            pixel(x+i,y+j,bg);
        }
    }

    // نوار SovereignX
    for(int i=0;i<250;i++)
        pixel(x+i,y,blue);

    draw_text(x+30,y+50,"SovereignX",white);
    draw_text(x+30,y+100,"Search",white);
    draw_text(x+30,y+140,"Terminal",white);
    draw_text(x+30,y+180,"Files",white);
    draw_text(x+30,y+220,"Settings",white);
    draw_text(x+30,y+260,"About",white);
}
