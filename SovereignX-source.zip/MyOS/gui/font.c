#include <stdint.h>
#include "font.h"

extern void pixel(int x,int y,uint32_t c);

void draw_char(int x,int y,char c,uint32_t color)
{
    // فونت ساده موقت پیکسلی
    if(c=='M')
    {
        for(int i=0;i<20;i++)
        {
            pixel(x+i,y+i,color);
            pixel(x+40-i,y+i,color);
        }
    }

    if(c=='O')
    {
        for(int i=0;i<30;i++)
        {
            pixel(x+i,y,color);
            pixel(x+i,y+30,color);
        }
    }
}

void draw_text(int x,int y,const char* text,uint32_t color)
{
    while(*text)
    {
        draw_char(x,y,*text,color);
        x+=45;
        text++;
    }
}
