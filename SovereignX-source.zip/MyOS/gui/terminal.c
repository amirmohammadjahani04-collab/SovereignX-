#include <stdint.h>

extern void pixel(int x,int y,uint32_t c);
extern void draw_text(int x,int y,const char* text,uint32_t color);

void terminal_draw()
{
    uint32_t black=0x000000;
    uint32_t green=0x00ff00;

    // صفحه ترمینال
    for(int y=120;y<400;y++)
    {
        for(int x=180;x<700;x++)
        {
            pixel(x,y,black);
        }
    }

    // نوشته
    draw_text(220,160,"SovereignX",green);
    draw_text(220,190,"Terminal",green);
    draw_text(220,230,">",green);
}
