extern int mouse_x;
extern int mouse_y;

extern void draw_menu();
extern void open_terminal();
extern void open_files();
extern void settings_draw();
extern void draw_search_window();

void mouse_click()
{
    // دکمه M در Taskbar
    if(mouse_x>80 && mouse_x<125 &&
       mouse_y>0 && mouse_y<45)
    {
        draw_menu();
        return;
    }

    // Terminal
    if(mouse_x>240 && mouse_x<330 &&
       mouse_y>50 && mouse_y<140)
    {
        open_terminal();
        return;
    }

    // Files
    if(mouse_x>80 && mouse_x<170 &&
       mouse_y>50 && mouse_y<140)
    {
        open_files();
        return;
    }

    // Settings
    if(mouse_x>400 && mouse_x<490 &&
       mouse_y>50 && mouse_y<140)
    {
        settings_draw();
        return;
    }

    // Search
    if(mouse_x>130 && mouse_x<200 &&
       mouse_y>0 && mouse_y<45)
    {
        draw_search_window();
        return;
    }
}
