#include <stdint.h>

extern void pixel(int x,int y,uint32_t c);

void draw_search_button()
{
    int x=80;
    int y=0;

    uint32_t bg=0x303030;
    uint32_t blue=0x00aaff;

    // دکمه
    for(int j=0;j<45;j++)
    {
        for(int i=0;i<45;i++)
        {
            pixel(x+i,y+j,bg);
        }
    }

    // لوگوی M
    for(int i=0;i<15;i++)
    {
        pixel(x+10+i,y+10+i,blue);
        pixel(x+35-i,y+10+i,blue);

        pixel(x+10+i,y+10+i*2,blue);
        pixel(x+35-i,y+10+i*2,blue);
    }
}
