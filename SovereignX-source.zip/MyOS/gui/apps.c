#include <stdint.h>

extern void draw_window(int x,int y,int w,int h);

void open_terminal()
{
    draw_window(150,100,600,350);
}

void open_files()
{
    draw_window(200,150,500,300);
}

void app_click(int x,int y)
{
    // Terminal icon
    if(x>240 && x<330 && y>50 && y<140)
    {
        open_terminal();
    }

    // Files icon
    if(x>80 && x<170 && y>50 && y<140)
    {
        open_files();
    }
}
