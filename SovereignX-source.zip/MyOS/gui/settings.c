#include <stdint.h>

extern void pixel(int x,int y,uint32_t c);
extern void draw_text(int x,int y,const char* text,uint32_t color);

void settings_draw()
{
    uint32_t white=0xffffff;
    uint32_t blue=0x0066aa;

    // پنجره تنظیمات
    for(int y=100;y<450;y++)
    {
        for(int x=180;x<720;x++)
        {
            pixel(x,y,0x202020);
        }
    }

    // نوار عنوان
    for(int x=180;x<720;x++)
        pixel(x,100,blue);

    draw_text(230,140,"SovereignX Settings",white);

    draw_text(230,200,"Display",white);
    draw_text(230,240,"Theme",white);
    draw_text(230,280,"System",white);
    draw_text(230,320,"About SovereignX",white);
}
