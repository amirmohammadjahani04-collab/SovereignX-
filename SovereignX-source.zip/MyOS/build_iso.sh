#!/bin/bash
set -e
cd ~/SovereignX/MyOS
make clean && make
cp build/sovereignx.kernel iso/boot/sovereignx.kernel
cp ~/limine/bin/limine-bios.sys iso/boot/limine/
cp ~/limine/bin/limine-bios-cd.bin iso/boot/limine/
cp ~/limine/limine-uefi-cd.bin iso/boot/limine/
cp boot/uefi/BOOTX64.EFI iso/EFI/BOOT/BOOTX64.EFI
xorriso -as mkisofs -R -r \
  -b boot/limine/limine-bios-cd.bin \
  -no-emul-boot -boot-load-size 4 -boot-info-table \
  --efi-boot boot/limine/limine-uefi-cd.bin \
  -efi-boot-part --efi-boot-image --protective-msdos-label \
  iso/ -o SovereignX.iso
~/limine/bin/limine bios-install SovereignX.iso
echo "SovereignX.iso ready!"
