#ifndef WM_H
#define WM_H

#include "window.h"

void wm_init(void);

int wm_create_window(
    const char *title,
    int x,
    int y,
    int w,
    int h,
    uint32_t color
);

void wm_draw_all(void);

#endif
