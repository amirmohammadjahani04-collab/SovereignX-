#include "app.h"
#include "window.h"


window_t file_window;


void open_file_manager(void)
{
    window_create(
        &file_window,
        100,
        80,
        400,
        250,
        0xaaaaaa,
        "File Manager"
    );


    window_draw(&file_window);
}
