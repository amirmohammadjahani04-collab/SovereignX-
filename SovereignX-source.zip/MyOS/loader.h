#ifndef LOADER_H
#define LOADER_H

void load_program(
    unsigned char *program
);

#endif
