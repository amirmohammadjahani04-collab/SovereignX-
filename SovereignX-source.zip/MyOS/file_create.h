#ifndef FILE_CREATE_H
#define FILE_CREATE_H

#include <stdint.h>

int create_file(
    const char *name,
    uint8_t *data,
    uint32_t size
);

#endif
