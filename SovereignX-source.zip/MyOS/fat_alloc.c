#include "fat_alloc.h"


uint16_t fat_find_free_cluster(void)
{
    /*
      نسخه اولیه:
      بعداً FAT Table واقعی بررسی می‌شود
    */

    for(uint16_t cluster = 2;
        cluster < 0xFF0;
        cluster++)
    {
        // اگر مقدار FAT صفر بود
        // این Cluster آزاد است

        return cluster;
    }


    return 0;
}
