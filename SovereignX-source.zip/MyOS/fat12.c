#include "fat12.h"
#include "disk.h"


#define FAT_START 1
#define DATA_START 33


uint8_t fat_table[512];


void fat12_init(void)
{
    // خواندن اولین سکتور FAT

    ata_read_sector(
        FAT_START,
        fat_table
    );
}



uint16_t fat12_next_cluster(uint16_t cluster)
{
    uint32_t offset;

    offset = cluster + (cluster / 2);


    uint16_t value;


    value =
        fat_table[offset]
        |
        (fat_table[offset+1]<<8);


    if(cluster & 1)
        value >>=4;
    else
        value &=0x0FFF;


    return value;
}



int fat12_read_file(
    uint16_t cluster,
    uint8_t *buffer
)
{
    int position=0;


    while(cluster < 0xFF8)
    {
        uint32_t sector;


        sector =
            DATA_START +
            (cluster-2);


        ata_read_sector(
            sector,
            buffer+position
        );


        position +=512;


        cluster =
            fat12_next_cluster(cluster);
    }


    return position;
}
