#ifndef WINDOW_H
#define WINDOW_H

#include <stdint.h>

typedef struct
{
    int x;
    int y;
    int width;
    int height;

    uint32_t color;
    const char *title;

} window_t;


void window_draw(window_t *win);

void window_create(
    window_t *win,
    int x,
    int y,
    int w,
    int h,
    uint32_t color,
    const char *title
);


#endif
