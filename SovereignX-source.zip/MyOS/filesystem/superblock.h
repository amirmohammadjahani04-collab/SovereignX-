#ifndef SUPERBLOCK_H
#define SUPERBLOCK_H

typedef struct
{
    int magic;
    int total_blocks;
    int used_blocks;

} SuperBlock;


void superblock_init();

#endif
