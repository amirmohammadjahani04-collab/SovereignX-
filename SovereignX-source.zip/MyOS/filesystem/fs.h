#ifndef FS_H
#define FS_H

void fs_init();

int fs_create(
    const char* name,
    const char* data
);

int fs_read(
    const char* name,
    char* buffer
);

#endif
