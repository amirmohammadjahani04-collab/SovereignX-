#include "fs.h"

void save_app(const char* name)
{
    fs_create_file(name,"SOVEREIGNX APPLICATION");
}
