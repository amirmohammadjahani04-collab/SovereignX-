#include "block.h"
#include "../kernel/drivers/storage/storage.h"


void block_init()
{
    storage_init();
}


int block_write(
    int block,
    const char* data
)
{
    return storage_write(
        block,
        data
    );
}


int block_read(
    int block,
    char* buffer
)
{
    return storage_read(
        block,
        buffer
    );
}
