#include "fat.h"


int block_table[MAX_BLOCKS];


void fat_init()
{
    for(int i=0;i<MAX_BLOCKS;i++)
    {
        block_table[i]=0;
    }
}


int fat_allocate()
{
    for(int i=0;i<MAX_BLOCKS;i++)
    {
        if(block_table[i]==0)
        {
            block_table[i]=1;
            return i;
        }
    }

    return -1;
}


void fat_free(int block)
{
    if(block>=0 && block<MAX_BLOCKS)
    {
        block_table[block]=0;
    }
}
