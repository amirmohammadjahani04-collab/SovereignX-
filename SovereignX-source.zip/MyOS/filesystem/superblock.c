#include "superblock.h"


SuperBlock sb;


void superblock_init()
{
    sb.magic = 0x4D594F53;
    sb.total_blocks = 2048;
    sb.used_blocks = 0;
}
