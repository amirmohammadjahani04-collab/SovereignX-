#ifndef BLOCK_H
#define BLOCK_H

void block_init();

int block_write(
    int block,
    const char* data
);

int block_read(
    int block,
    char* buffer
);

#endif
