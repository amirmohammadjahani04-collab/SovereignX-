#include "disk.h"

#define BLOCK_SIZE 512
#define MAX_BLOCKS 128

char disk[MAX_BLOCKS][BLOCK_SIZE];


void disk_init()
{
    for(int i=0;i<MAX_BLOCKS;i++)
    {
        for(int j=0;j<BLOCK_SIZE;j++)
        {
            disk[i][j]=0;
        }
    }
}


int disk_write(int block,const char* data)
{
    int i=0;

    while(data[i] && i<BLOCK_SIZE)
    {
        disk[block][i]=data[i];
        i++;
    }

    return 1;
}


int disk_read(int block,char* buffer)
{
    int i=0;

    while(i<BLOCK_SIZE)
    {
        buffer[i]=disk[block][i];
        i++;
    }

    return 1;
}
