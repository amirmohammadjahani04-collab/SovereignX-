#ifndef SOVEREIGNX_DISK_H
#define SOVEREIGNX_DISK_H

void disk_init();
int disk_write(int block, const char* data);
int disk_read(int block, char* buffer);

#endif
