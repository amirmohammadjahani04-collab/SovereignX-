#ifndef FAT_H
#define FAT_H

#define MAX_BLOCKS 2048

void fat_init();

int fat_allocate();

void fat_free(int block);

#endif
