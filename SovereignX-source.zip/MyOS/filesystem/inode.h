#ifndef INODE_H
#define INODE_H

#define MAX_FILES 64

typedef struct
{
    int used;
    char name[32];
    int size;
    int block;
} Inode;


void inode_init();

int inode_create(char* name,int block);

Inode* inode_get(int id);

#endif
