#include "inode.h"

Inode table[MAX_FILES];


void inode_init()
{
    for(int i=0;i<MAX_FILES;i++)
    {
        table[i].used=0;
    }
}


int inode_create(char* name,int block)
{
    for(int i=0;i<MAX_FILES;i++)
    {
        if(table[i].used==0)
        {
            table[i].used=1;
            table[i].block=block;

            int j=0;

            while(name[j])
            {
                table[i].name[j]=name[j];
                j++;
            }

            table[i].name[j]=0;

            return i;
        }
    }

    return -1;
}


Inode* inode_get(int id)
{
    if(id<0 || id>=MAX_FILES)
        return 0;

    return &table[id];
}
