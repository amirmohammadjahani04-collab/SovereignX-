#include "fs.h"

#define MAX_FILES 64
#define DATA_SIZE 512


typedef struct
{
    int used;
    char name[32];
    char data[DATA_SIZE];

} File;


File files[MAX_FILES];


void fs_init()
{
    for(int i=0;i<MAX_FILES;i++)
    {
        files[i].used=0;
    }
}


int fs_create(
    const char* name,
    const char* data
)
{
    for(int i=0;i<MAX_FILES;i++)
    {
        if(files[i].used==0)
        {
            files[i].used=1;

            int j=0;

            while(name[j])
            {
                files[i].name[j]=name[j];
                j++;
            }

            files[i].name[j]=0;


            j=0;

            while(data[j])
            {
                files[i].data[j]=data[j];
                j++;
            }

            files[i].data[j]=0;


            return 1;
        }
    }

    return 0;
}


int fs_read(
    const char* name,
    char* buffer
)
{
    for(int i=0;i<MAX_FILES;i++)
    {
        if(files[i].used)
        {
            int j=0;

            while(files[i].name[j] &&
                  name[j] &&
                  files[i].name[j]==name[j])
            {
                j++;
            }


            if(files[i].name[j]==0 &&
               name[j]==0)
            {
                j=0;

                while(files[i].data[j])
                {
                    buffer[j]=files[i].data[j];
                    j++;
                }

                buffer[j]=0;

                return 1;
            }
        }
    }

    return 0;
}
