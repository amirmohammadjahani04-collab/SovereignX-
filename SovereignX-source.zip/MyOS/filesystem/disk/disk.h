#ifndef DISK_H
#define DISK_H

#define BLOCK_SIZE 512
#define MAX_BLOCKS 1024

void disk_init();

int disk_write_block(
    int block,
    const char* data
);

int disk_read_block(
    int block,
    char* buffer
);

#endif
