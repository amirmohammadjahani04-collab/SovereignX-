#include "disk.h"


unsigned char blocks[MAX_BLOCKS][BLOCK_SIZE];


void disk_init()
{
    for(int i=0;i<MAX_BLOCKS;i++)
    {
        for(int j=0;j<BLOCK_SIZE;j++)
        {
            blocks[i][j]=0;
        }
    }
}


int disk_write_block(
    int block,
    const char* data
)
{
    if(block<0 || block>=MAX_BLOCKS)
        return 0;


    int i=0;

    while(data[i] && i<BLOCK_SIZE)
    {
        blocks[block][i]=data[i];
        i++;
    }

    return 1;
}



int disk_read_block(
    int block,
    char* buffer
)
{
    if(block<0 || block>=MAX_BLOCKS)
        return 0;


    for(int i=0;i<BLOCK_SIZE;i++)
    {
        buffer[i]=blocks[block][i];
    }

    return 1;
}
