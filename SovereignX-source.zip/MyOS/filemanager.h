#ifndef FILEMANAGER_H
#define FILEMANAGER_H

void filemanager_open(void);
void filemanager_draw(void);

#endif
