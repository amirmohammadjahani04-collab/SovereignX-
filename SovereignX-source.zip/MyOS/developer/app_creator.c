#include <stdio.h>
#include <stdlib.h>

void create_app(const char *name)
{
    char cmd[256];

    sprintf(cmd, "mkdir -p apps/%s", name);
    system(cmd);

    sprintf(cmd,
    "echo '#include \"app.h\"' > apps/%s/main.c",
    name);

    system(cmd);

    sprintf(cmd,
    "echo 'SovereignX Application' > apps/%s/app.info",
    name);

    system(cmd);

    printf("SovereignX: App %s created successfully\n", name);
}
