#include "../filesystem/fs.h"

extern void sovereignx_print(const char* text);

void create_app(const char* name)
{
    fs_create_file(name, "SOVEREIGNX APP");
    sovereignx_print("APP CREATED");
}


void build_app(const char* name)
{
    fs_create_file(name, "SOVEREIGNX APP BINARY");
    sovereignx_print("APP BUILT");
}


void run_app(const char* name)
{
    sovereignx_print("RUNNING APP");
}
