#include <stdint.h>

struct SovereignX_App
{
    char magic[6];
    char name[32];
    int version;
};


extern void sovereignx_print(const char* text);


void build_app_file(const char* name)
{
    struct SovereignX_App app;

    app.magic[0]='M';
    app.magic[1]='Y';
    app.magic[2]='A';
    app.magic[3]='P';
    app.magic[4]='P';
    app.magic[5]=0;

    app.version=1;


    // مرحله بعد:
    // نوشتن این ساختار در فایل .app

    sovereignx_print("SovereignX: APP file created");
}
