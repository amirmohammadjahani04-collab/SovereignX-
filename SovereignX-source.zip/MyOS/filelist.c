#include "filelist.h"
#include "fat_dir.h"
#include "font.h"


void filelist_show(void)
{
    draw_string(
        100,
        100,
        "bakOS File Manager",
        0xffffff
    );


    fat_read_root();
}
