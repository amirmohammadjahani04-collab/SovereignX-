#include "startmenu.h"
#include "graphics.h"
#include "font.h"


static int menu_open = 0;


void startmenu_draw(void)
{
    // دکمه M روی Taskbar

    fill_rect(
        10,
        450,
        40,
        30,
        0x444444
    );


    draw_string(
        22,
        460,
        "M",
        0xffffff
    );


    if(menu_open)
    {
        fill_rect(
            10,
            200,
            180,
            230,
            0x222222
        );


        draw_string(
            30,
            220,
            "bakOS Menu",
            0xffffff
        );

        draw_string(
            30,
            260,
            "Files",
            0xffffff
        );

        draw_string(
            30,
            300,
            "Settings",
            0xffffff
        );

        draw_string(
            30,
            340,
            "Terminal",
            0xffffff
        );
    }
}


void startmenu_click(int x,int y)
{
    if(x>=10 && x<=50 &&
       y>=450 && y<=480)
    {
        menu_open = 1;
        startmenu_draw();
    }
}
