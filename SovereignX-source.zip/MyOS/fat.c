#include "fat.h"
#include "disk.h"
#include "font.h"


uint8_t boot_sector[512];


void fat_init(void)
{
    // خواندن Boot Sector
    ata_read_sector(
        0,
        boot_sector
    );


    draw_string(
        10,
        300,
        "FAT12 Initialized",
        0xffffff
    );
}



void fat_list_files(void)
{
    /*
      مرحله بعد:
      - خواندن Root Directory
      - پیدا کردن نام فایل‌ها
      - نمایش در File Manager
    */


    draw_string(
        10,
        320,
        "Reading Root Directory...",
        0xffffff
    );
}
