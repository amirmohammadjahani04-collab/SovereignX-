#include <stdio.h>

void create_app(const char *name)
{
    printf("[SovereignX] Creating app: %s\n", name);
}

void build_app(const char *name)
{
    printf("[SovereignX] Building app: %s\n", name);
}

void run_app(const char *name)
{
    printf("[SovereignX] Running app: %s\n", name);
}
