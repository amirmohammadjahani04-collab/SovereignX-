#ifndef SOVEREIGNX_DEVELOPER_H
#define SOVEREIGNX_DEVELOPER_H

void create_app(const char *name);
void build_app(const char *name);
void run_app(const char *name);

#endif
