#ifndef FAT_ALLOC_H
#define FAT_ALLOC_H

#include <stdint.h>

uint16_t fat_find_free_cluster(void);

#endif
