#ifndef FAT_DIR_H
#define FAT_DIR_H

void fat_read_root(void);

#endif
