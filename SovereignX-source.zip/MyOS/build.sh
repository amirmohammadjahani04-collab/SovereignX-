#!/bin/bash

echo "Cleaning..."
make clean

echo "Compiling..."
make

echo "Done."
