#include "exec.h"
#include "file_open.h"
#include "loader.h"


unsigned char program_memory[4096];


void execute(
    const char *filename
)
{

    if(open_file(
        filename,
        program_memory
    )==0)
    {

        load_program(
            program_memory
        );

    }

}
