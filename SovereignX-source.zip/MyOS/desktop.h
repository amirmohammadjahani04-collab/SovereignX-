#ifndef DESKTOP_H
#define DESKTOP_H

#include <stdint.h>

void desktop_init(uint32_t color);
void desktop_draw(void);

#endif
