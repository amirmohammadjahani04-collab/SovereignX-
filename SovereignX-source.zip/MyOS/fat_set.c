#include "fat_set.h"


uint8_t fat_table[512];


void fat_set_cluster(
    uint16_t cluster,
    uint16_t value
)
{
    uint32_t offset;

    offset =
        cluster +
        cluster/2;


    if(cluster & 1)
    {
        fat_table[offset+1] =
        (fat_table[offset+1]&0x0F)
        |
        ((value<<4)&0xF0);
    }
    else
    {
        fat_table[offset] =
        value & 0xFF;

        fat_table[offset+1] =
        value>>8;
    }
}
