#ifndef FILEMANAGER_UI_H
#define FILEMANAGER_UI_H

void filemanager_buttons(void);
void filemanager_click(int x,int y);

#endif
