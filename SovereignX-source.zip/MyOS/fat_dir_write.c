#include "fat_dir_write.h"
#include "disk.h"

#include <string.h>


typedef struct
{
    char name[11];

    uint8_t attr;

    uint8_t reserved[10];

    uint16_t cluster;

    uint32_t size;

} __attribute__((packed)) dir_entry;


int fat_create_entry(
    const char *name,
    uint16_t cluster,
    uint32_t size
)
{
    uint8_t sector[512];


    // Root Directory
    // (در نسخه کامل از Boot Sector محاسبه می‌شود)

    ata_read_sector(
        19,
        sector
    );


    dir_entry *entry =
        (dir_entry*)sector;


    for(int i=0;i<16;i++)
    {

        // پیدا کردن جای خالی

        if(entry[i].name[0]==0)
        {

            memset(
                &entry[i],
                0,
                sizeof(dir_entry)
            );


            // نام 8.3

            for(int j=0;j<11;j++)
                entry[i].name[j]=' ';


            for(int j=0;
                j<11 && name[j];
                j++)
            {
                entry[i].name[j]=name[j];
            }


            entry[i].attr = 0x20;

            entry[i].cluster = cluster;

            entry[i].size = size;


            // ذخیره Root Directory

            ata_write_sector(
                19,
                sector
            );


            return 0;
        }
    }


    return -1;
}
