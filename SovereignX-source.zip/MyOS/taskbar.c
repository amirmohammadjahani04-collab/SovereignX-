#include "taskbar.h"
#include "graphics.h"
#include "font.h"


#define MAX_APPS 10

static const char *apps[MAX_APPS];

static int app_count = 0;


void taskbar_draw(void)
{
    // نوار پایین صفحه

    fill_rect(
        0,
        440,
        640,
        40,
        0x202020
    );


    // دکمه M

    fill_rect(
        10,
        445,
        35,
        30,
        0x444444
    );

    draw_string(
        22,
        455,
        "M",
        0xffffff
    );


    // برنامه‌های باز

    int x = 60;

    for(int i=0;i<app_count;i++)
    {
        fill_rect(
            x,
            445,
            120,
            30,
            0x555555
        );


        draw_string(
            x+10,
            455,
            apps[i],
            0xffffff
        );


        x += 130;
    }
}



void taskbar_add_app(const char *name)
{
    if(app_count < MAX_APPS)
    {
        apps[app_count] = name;
        app_count++;
    }


    taskbar_draw();
}
