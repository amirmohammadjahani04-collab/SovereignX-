#ifndef STARTMENU_H
#define STARTMENU_H

void startmenu_draw(void);
void startmenu_click(int x,int y);

#endif
