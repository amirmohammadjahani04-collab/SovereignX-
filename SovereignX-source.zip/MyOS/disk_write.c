#include "disk_write.h"


#define ATA_DATA   0x1F0
#define ATA_STATUS 0x1F7


static inline void outb(uint16_t port,uint8_t value)
{
    asm volatile(
        "outb %0,%1"
        :
        :"a"(value),"Nd"(port)
    );
}


static inline uint8_t inb(uint16_t port)
{
    uint8_t r;

    asm volatile(
        "inb %1,%0"
        :"=a"(r)
        :"Nd"(port)
    );

    return r;
}


int ata_write_sector(
    uint32_t lba,
    uint8_t *buffer
)
{
    outb(0x1F6,
        0xE0 | ((lba>>24)&0x0F));


    outb(0x1F2,1);

    outb(0x1F3,lba);
    outb(0x1F4,lba>>8);
    outb(0x1F5,lba>>16);


    // دستور نوشتن سکتور
    outb(0x1F7,0x30);


    while(!(inb(ATA_STATUS)&8));


    for(int i=0;i<256;i++)
    {
        uint16_t data;

        data =
          buffer[i*2]
          |
          (buffer[i*2+1]<<8);


        asm volatile(
        "outw %0,%1"
        :
        :"a"(data),"Nd"(ATA_DATA)
        );
    }


    return 0;
}
