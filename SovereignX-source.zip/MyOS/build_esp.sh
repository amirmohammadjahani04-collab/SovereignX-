#!/bin/bash

mkdir -p build/esp

dd if=/dev/zero of=build/esp.img bs=1M count=64

mkfs.fat -F32 build/esp.img

mkdir -p build/esp_mount

mount -o loop build/esp.img build/esp_mount

mkdir -p build/esp_mount/EFI/BOOT

cp build/x86_64/BOOTX64.EFI \
build/esp_mount/EFI/BOOT/BOOTX64.EFI

sync

umount build/esp_mount

echo "ESP DONE"
