#ifndef FAT_DIR_WRITE_H
#define FAT_DIR_WRITE_H

#include <stdint.h>

int fat_create_entry(
    const char *name,
    uint16_t cluster,
    uint32_t size
);

#endif
