#include "fileopen.h"
#include "fat.h"
#include "disk.h"
#include "font.h"


void file_open(const char *name)
{
    uint8_t buffer[512];


    // فعلاً نمونه:
    // بعداً اینجا FAT را جستجو می‌کنیم
    // و Cluster فایل را پیدا می‌کنیم


    ata_read_sector(
        20,
        buffer
    );


    draw_string(
        50,
        250,
        "Opening:",
        0xffffff
    );


    draw_string(
        130,
        250,
        name,
        0xffffff
    );


    draw_string(
        50,
        280,
        (char*)buffer,
        0xffffff
    );
}
