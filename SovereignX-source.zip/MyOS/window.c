#include "window.h"
#include "graphics.h"
#include "font.h"


void window_create(
    window_t *win,
    int x,
    int y,
    int w,
    int h,
    uint32_t color,
    const char *title
)
{
    win->x = x;
    win->y = y;
    win->width = w;
    win->height = h;
    win->color = color;
    win->title = title;
}


void window_draw(window_t *win)
{
    // بدنه پنجره
    fill_rect(
        win->x,
        win->y,
        win->width,
        win->height,
        win->color
    );


    // نوار عنوان
    fill_rect(
        win->x,
        win->y,
        win->width,
        20,
        0x202020
    );


    // متن عنوان
    draw_string(
        win->x + 5,
        win->y + 5,
        win->title,
        0xffffff
    );
}
