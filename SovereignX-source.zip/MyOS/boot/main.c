typedef unsigned long long UINTN;

typedef struct {
    char _pad[44];
} EFI_SYSTEM_TABLE;

typedef unsigned long long EFI_STATUS;

EFI_STATUS efi_main(void *ImageHandle, EFI_SYSTEM_TABLE *SystemTable)
{
    volatile unsigned short *video = (unsigned short*)0xb8000;

    char *msg = "Starting SovereignX UEFI Boot...";

    for(int i = 0; msg[i]; i++)
    {
        video[i] = (unsigned short)msg[i] | 0x0700;
    }

    while(1){}

    return 0;
}
