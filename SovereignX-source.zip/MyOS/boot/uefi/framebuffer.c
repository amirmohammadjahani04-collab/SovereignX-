#include <efi.h>
#include <efilib.h>

EFI_GRAPHICS_OUTPUT_PROTOCOL *gop;

EFI_STATUS init_graphics()
{
    EFI_STATUS status;

    status = uefi_call_wrapper(
        BS->LocateProtocol,
        3,
        &gEfiGraphicsOutputProtocolGuid,
        NULL,
        (void**)&gop
    );

    if(status != EFI_SUCCESS)
        return status;


    framebuffer.address =
        gop->Mode->FrameBufferBase;

    framebuffer.width =
        gop->Mode->Info->HorizontalResolution;

    framebuffer.height =
        gop->Mode->Info->VerticalResolution;

    framebuffer.pixels_per_scanline =
        gop->Mode->Info->PixelsPerScanLine;


    return EFI_SUCCESS;
}
