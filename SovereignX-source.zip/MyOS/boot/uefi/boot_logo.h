#ifndef BOOT_LOGO_H
#define BOOT_LOGO_H

#include "include/efi.h"
#include "include/efi_types.h"

void show_boot_logo(EFI_SYSTEM_TABLE *SystemTable);

#endif
