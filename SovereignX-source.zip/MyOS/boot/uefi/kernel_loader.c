#include "include/efi.h"
#include "include/efi_types.h"
#include "include/elf64.h"
#include "bootinfo.h"

typedef void (*KernelEntry)(BootInfo*);

void load_segments(Elf64_Ehdr *elf)
{
    Elf64_Phdr *ph =
        (Elf64_Phdr *)((char*)elf + elf->e_phoff);

    for(unsigned int i = 0; i < elf->e_phnum; i++)
    {
        if(ph[i].p_type == PT_LOAD)
        {
            char *src =
                (char*)elf + ph[i].p_offset;

            char *dst =
                (char*)ph[i].p_paddr;

            for(unsigned long long j = 0;
                j < ph[i].p_filesz;
                j++)
            {
                dst[j] = src[j];
            }

            for(unsigned long long j = ph[i].p_filesz;
                j < ph[i].p_memsz;
                j++)
            {
                dst[j] = 0;
            }
        }
    }
}


void jump_kernel(void *kernel)
{
    BootInfo info;

    KernelEntry entry =
        (KernelEntry)kernel;

    entry(&info);
}
