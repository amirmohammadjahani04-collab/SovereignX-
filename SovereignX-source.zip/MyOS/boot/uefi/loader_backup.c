#include "include/efi.h"

EFI_STATUS efi_main(
    EFI_HANDLE image,
    EFI_SYSTEM_TABLE *table
)
{
    volatile unsigned short *screen =
        (unsigned short*)0xb8000;

    char *msg = "SovereignX UEFI Loader Ready";

    for(int i = 0; msg[i]; i++)
    {
        screen[i] = msg[i] | 0x0700;
    }

    while(1)
    {
    }

    return 0;
}
