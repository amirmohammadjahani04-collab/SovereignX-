#ifndef KERNEL_LOADER_H
#define KERNEL_LOADER_H

#include "efi.h"
#include "uefi_file.h"
#include "elf64.h"
#include "../bootinfo.h"

void load_kernel(
    EFI_FILE_PROTOCOL *root,
    BootInfo *bootinfo
);

#endif
