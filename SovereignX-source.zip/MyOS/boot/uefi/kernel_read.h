#ifndef KERNEL_READ_H
#define KERNEL_READ_H

#include "include/efi.h"
#include "include/efi_types.h"

EFI_STATUS read_kernel(EFI_SYSTEM_TABLE *SystemTable);

#endif
