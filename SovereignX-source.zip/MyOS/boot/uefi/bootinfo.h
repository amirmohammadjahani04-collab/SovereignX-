#ifndef BOOTINFO_H
#define BOOTINFO_H

#include <stdint.h>

typedef struct
{
    uint64_t framebuffer;
    uint32_t width;
    uint32_t height;
    uint32_t scanline;

} BootInfo;

#endif
