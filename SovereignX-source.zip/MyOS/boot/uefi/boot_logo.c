#include "include/efi.h"
#include "include/efi_types.h"


void show_boot_logo(EFI_SYSTEM_TABLE *SystemTable)
{
    volatile unsigned short *vga =
        (unsigned short*)0xb8000;


    char *msg =
        "SOVEREIGNX BOOTING...";


    for(int i=0; msg[i]; i++)
    {
        vga[i] = msg[i] | 0x0700;
    }


    char *bar =
        "[##########..........]";


    for(int i=0; bar[i]; i++)
    {
        vga[80+i] = bar[i] | 0x0700;
    }
}
