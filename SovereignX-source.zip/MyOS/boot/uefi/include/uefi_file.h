#ifndef UEFI_FILE_H
#define UEFI_FILE_H

#include "efi.h"

typedef struct EFI_FILE_PROTOCOL EFI_FILE_PROTOCOL;

typedef EFI_STATUS (*EFI_FILE_OPEN)(
    EFI_FILE_PROTOCOL *This,
    EFI_FILE_PROTOCOL **NewHandle,
    unsigned short *FileName,
    UINT64 OpenMode,
    UINT64 Attributes
);

typedef EFI_STATUS (*EFI_FILE_READ)(
    EFI_FILE_PROTOCOL *This,
    UINT64 *BufferSize,
    void *Buffer
);

struct EFI_FILE_PROTOCOL
{
    UINT64 Revision;
    EFI_FILE_OPEN Open;
    void *Close;
    EFI_FILE_READ Read;
};


typedef struct
{
    EFI_STATUS (*OpenVolume)(
        void *This,
        EFI_FILE_PROTOCOL **Root
    );

} EFI_SIMPLE_FILE_SYSTEM_PROTOCOL;


#define EFI_FILE_MODE_READ 0x1

#endif
