#ifndef EFI_H
#define EFI_H

typedef unsigned long long UINT64;
typedef unsigned int UINT32;
typedef unsigned short UINT16;
typedef unsigned char UINT8;

typedef unsigned long long EFI_STATUS;
typedef void* EFI_HANDLE;

#define EFI_SUCCESS 0

typedef struct EFI_BOOT_SERVICES EFI_BOOT_SERVICES;

typedef EFI_STATUS (*EFI_HANDLE_PROTOCOL)(
    EFI_HANDLE Handle,
    void *Protocol,
    void **Interface
);


struct EFI_BOOT_SERVICES
{
    UINT64 pad[12];

    EFI_HANDLE_PROTOCOL HandleProtocol;
};


typedef struct
{
    UINT64 pad1[12];

    EFI_BOOT_SERVICES *BootServices;

} EFI_SYSTEM_TABLE;


#endif
