#ifndef EFI_FILE_H
#define EFI_FILE_H

#include "efi_types.h"

typedef struct EFI_FILE_PROTOCOL EFI_FILE_PROTOCOL;

typedef EFI_STATUS (*EFI_FILE_OPEN)(
    EFI_FILE_PROTOCOL *This,
    EFI_FILE_PROTOCOL **NewHandle,
    unsigned short *FileName,
    UINT64 OpenMode,
    UINT64 Attributes
);

struct EFI_FILE_PROTOCOL
{
    UINT64 Revision;
    EFI_FILE_OPEN Open;
};

typedef struct
{
    EFI_STATUS (*OpenVolume)(
        void *This,
        EFI_FILE_PROTOCOL **Root
    );

} EFI_SIMPLE_FILE_SYSTEM_PROTOCOL;

#endif
