#ifndef EFI_TYPES_H
#define EFI_TYPES_H

typedef unsigned long long UINT64;
typedef unsigned int UINT32;
typedef unsigned short UINT16;
typedef unsigned char UINT8;
typedef unsigned long long EFI_STATUS;
typedef void* EFI_HANDLE;
typedef unsigned long long EFI_PHYSICAL_ADDRESS;

#define EFI_SUCCESS 0

#endif
