#include "kernel_read.h"


EFI_STATUS read_kernel(EFI_SYSTEM_TABLE *SystemTable)
{

    /*
       مرحله بعد:
       EFI_SIMPLE_FILE_SYSTEM_PROTOCOL
       OpenVolume()
       Open(L"\\kernel\\sovereignx.kernel")
       Read()
    */


    return EFI_SUCCESS;
}
