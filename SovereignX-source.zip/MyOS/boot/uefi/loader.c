#include "include/efi.h"
#include "include/efi_types.h"

#include "boot_logo.h"

EFI_STATUS
efi_main(
EFI_HANDLE ImageHandle,
EFI_SYSTEM_TABLE *SystemTable)
{

    show_boot_logo(SystemTable);

    while(1)
    {
    }

    return EFI_SUCCESS;
}
