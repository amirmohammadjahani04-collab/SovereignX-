#ifndef GRAPHICS_H
#define GRAPHICS_H

#include <stdint.h>

void put_pixel(int x,int y,uint32_t color);
void draw_line(int x1,int y1,int x2,int y2,uint32_t color);
void draw_rect(int x,int y,int w,int h,uint32_t color);
void fill_rect(int x,int y,int w,int h,uint32_t color);
void clear_screen(uint32_t color);

#endif
