#include "file_create.h"
#include "fat_alloc.h"
#include "fat_set.h"
#include "fat_dir_write.h"
#include "disk_write.h"


#define DATA_START 33


int create_file(
    const char *name,
    uint8_t *data,
    uint32_t size
)
{

    // 1. گرفتن Cluster آزاد

    uint16_t cluster;

    cluster =
        fat_find_free_cluster();


    if(cluster==0)
        return -1;



    // 2. نوشتن داده فایل

    uint32_t sector;

    sector =
        DATA_START +
        (cluster-2);


    ata_write_sector(
        sector,
        data
    );



    // 3. پایان زنجیره فایل

    fat_set_cluster(
        cluster,
        0xFFF
    );



    // 4. ساخت Entry در Root Directory

    fat_create_entry(
        name,
        cluster,
        size
    );


    return 0;
}
