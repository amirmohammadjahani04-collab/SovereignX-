#ifndef FAT12_H
#define FAT12_H

#include <stdint.h>

void fat12_init(void);

uint16_t fat12_next_cluster(uint16_t cluster);

int fat12_read_file(
    uint16_t cluster,
    uint8_t *buffer
);

#endif
