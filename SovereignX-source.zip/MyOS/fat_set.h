#ifndef FAT_SET_H
#define FAT_SET_H

#include <stdint.h>

void fat_set_cluster(
    uint16_t cluster,
    uint16_t value
);

#endif
