#include "filemanager_ui.h"
#include "graphics.h"
#include "font.h"
#include "file_create.h"


uint8_t note[] =
"Hello from bakOS File Manager";


void filemanager_buttons(void)
{

    fill_rect(
        100,
        250,
        120,
        30,
        0x555555
    );


    draw_string(
        120,
        260,
        "SAVE",
        0xffffff
    );

}



void filemanager_click(int x,int y)
{

    // دکمه SAVE

    if(x>=100 && x<=220 &&
       y>=250 && y<=280)
    {

        create_file(
            "NOTE.TXT",
            note,
            sizeof(note)
        );


        draw_string(
            100,
            300,
            "Saved!",
            0xffffff
        );
    }

}
