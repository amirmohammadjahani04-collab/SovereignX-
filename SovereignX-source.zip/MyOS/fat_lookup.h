#ifndef FAT_LOOKUP_H
#define FAT_LOOKUP_H

#include <stdint.h>

uint16_t fat_find_file(
    const char *name
);

#endif
