#ifndef DISK_WRITE_H
#define DISK_WRITE_H

#include <stdint.h>

int ata_write_sector(
    uint32_t lba,
    uint8_t *buffer
);

#endif
