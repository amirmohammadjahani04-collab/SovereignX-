#ifndef FAT_H
#define FAT_H

#include <stdint.h>

void fat_init(void);

void fat_list_files(void);

#endif
