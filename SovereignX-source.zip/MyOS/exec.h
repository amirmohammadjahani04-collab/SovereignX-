#ifndef EXEC_H
#define EXEC_H

void execute(
    const char *filename
);

#endif
