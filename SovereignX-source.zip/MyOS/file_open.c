#include "file_open.h"
#include "fat_lookup.h"
#include "fat12.h"


int open_file(
    const char *name,
    unsigned char *buffer
)
{

    unsigned short cluster;


    cluster =
        fat_find_file(name);


    if(cluster==0)
        return -1;


    fat12_read_file(
        cluster,
        buffer
    );


    return 0;
}
