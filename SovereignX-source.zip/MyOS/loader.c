#include "loader.h"


typedef void (*program_t)(void);



void load_program(
    unsigned char *program
)
{

    program_t entry;


    entry =
      (program_t)program;


    entry();

}
